package com.adblocker.mobile

import android.content.Context

/** Small settings shared by the screens, the VPN service and the boot receiver. */
object AppPrefs {
    private const val FILE = "settings"

    /**
     * How hard names that no list knows are hunted (read on every DNS lookup, so kept in memory):
     * 0 = lists only, 1 = Balanced (clear ad names), 2 = Strong (also trackers, learned patterns).
     */
    @Volatile
    private var chosenLevel: Int = 2

    /** Free: Off or Balanced only. Worked out on every read, so it drops by itself when a Pro key runs out. */
    val autoLevel: Int get() = if (License.isPro) chosenLevel else chosenLevel.coerceAtMost(1)

    /** Old name kept for the browser pane: true whenever any automatic detection is on. */
    val smartBlocking: Boolean get() = autoLevel > 0

    /**
     * Ask AdGuard DNS first (it blocks ad names that the downloaded lists miss and is updated
     * every day), then fall back to Cloudflare. Names on the allowlist always use Cloudflare.
     */
    @Volatile
    var filteringUpstream: Boolean = true
        private set

    // ---- UI-level switches (Settings screen) -------------------------------------------
    @Volatile var blockAds: Boolean = true; private set
    @Volatile var blockPopups: Boolean = true; private set
    @Volatile var blockTrackers: Boolean = true; private set
    @Volatile var blockAnnoying: Boolean = true; private set
    @Volatile var fasterBrowsing: Boolean = true; private set
    @Volatile var enhancedPrivacy: Boolean = true; private set
    @Volatile var notifications: Boolean = true; private set
    /** Phone-browser pop-up guard (accessibility service). Only acts once the user enables the service in Android settings. */
    @Volatile var browserGuard: Boolean = true; private set
    @Volatile var searchEngine: String = "google"; private set
    @Volatile var theme: String = "purple"; private set
    @Volatile var language: String = "en"; private set

    /** Whether blocking is switched on for one kind of request (see [EventKind]). */
    fun kindEnabled(kind: String): Boolean = when (kind) {
        EventKind.POPUP -> blockPopups
        EventKind.TRACKER -> blockTrackers
        EventKind.OTHER -> blockAnnoying
        else -> blockAds
    }

    fun onboardingDone(context: Context): Boolean = prefs(context).getBoolean("onboarding_done", false)
    fun setOnboardingDone(context: Context) {
        prefs(context).edit().putBoolean("onboarding_done", true).apply()
    }

    fun setFlag(context: Context, key: String, value: Boolean) {
        when (key) {
            "block_ads" -> blockAds = value
            "block_popups" -> blockPopups = value
            "block_trackers" -> blockTrackers = value
            "block_annoying" -> blockAnnoying = value
            "faster_browsing" -> fasterBrowsing = value
            "enhanced_privacy" -> enhancedPrivacy = value
            "notifications" -> notifications = value
            "browser_guard" -> browserGuard = value
        }
        prefs(context).edit().putBoolean(key, value).apply()
    }

    fun setText(context: Context, key: String, value: String) {
        when (key) {
            "search_engine" -> searchEngine = value
            "theme" -> theme = value
            "language" -> language = value
        }
        prefs(context).edit().putString(key, value).apply()
    }

    /** The pop-up guard needs the user's switch AND a Pro license. */
    val guardActive: Boolean get() = browserGuard && License.isPro

    fun load(context: Context) {
        License.load(context)
        val p = prefs(context)
        blockAds = p.getBoolean("block_ads", true)
        blockPopups = p.getBoolean("block_popups", true)
        blockTrackers = p.getBoolean("block_trackers", true)
        blockAnnoying = p.getBoolean("block_annoying", true)
        fasterBrowsing = p.getBoolean("faster_browsing", true)
        enhancedPrivacy = p.getBoolean("enhanced_privacy", true)
        notifications = p.getBoolean("notifications", true)
        browserGuard = p.getBoolean("browser_guard", true)
        searchEngine = p.getString("search_engine", "google") ?: "google"
        theme = p.getString("theme", "purple") ?: "purple"
        language = p.getString("language", "en") ?: "en"
        val storedLevel = if (p.contains("auto_level")) {
            p.getInt("auto_level", 2).coerceIn(0, 2)
        } else if (p.getBoolean("smart_blocking", true)) 2 else 0
        // The stored choice is kept, so Pro brings Strong back; [autoLevel] caps it while Free.
        chosenLevel = storedLevel
        filteringUpstream = p.getBoolean("filtering_upstream", true)
    }

    fun setAutoLevel(context: Context, value: Int) {
        val chosen = value.coerceIn(0, 2)
        chosenLevel = chosen
        prefs(context).edit().putInt("auto_level", chosen).apply()
    }

    fun setFilteringUpstream(context: Context, value: Boolean) {
        filteringUpstream = value
        prefs(context).edit().putBoolean("filtering_upstream", value).apply()
    }

    /** True while the user wants protection on (set by the power button, not by the system). */
    fun protectionWanted(context: Context): Boolean = prefs(context).getBoolean("protection_wanted", false)

    fun setProtectionWanted(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean("protection_wanted", value).apply()
    }

    fun startOnBoot(context: Context): Boolean = prefs(context).getBoolean("start_on_boot", true)

    fun setStartOnBoot(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean("start_on_boot", value).apply()
    }

    /** How many pop-up / redirect tabs the browser guard has closed so far. */
    fun guardClosed(context: Context): Int = prefs(context).getInt("guard_closed", 0)

    fun addGuardClosed(context: Context) {
        val p = prefs(context)
        p.edit().putInt("guard_closed", p.getInt("guard_closed", 0) + 1).apply()
    }

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)
}
