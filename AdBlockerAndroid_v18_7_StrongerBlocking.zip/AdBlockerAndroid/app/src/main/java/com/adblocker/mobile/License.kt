package com.adblocker.mobile

import android.content.Context
import android.provider.Settings
import androidx.compose.runtime.mutableIntStateOf
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit
import java.math.BigInteger
import java.security.MessageDigest
import java.time.LocalDate
import java.time.ZoneOffset
import java.time.temporal.ChronoUnit
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * Free / Pro switch. A Pro key is tied to one phone:
 *   device ID = first 10 bytes of SHA-256("adblocker-device-v1:" + ANDROID_ID), shown as XXXX-XXXX-XXXX-XXXX
 *   Pro key   = 80 bits shown as XXXX-XXXX-XXXX-XXXX:
 *                 15 bits expiry day (days since 2026-01-01 UTC, last valid day; 0 = lifetime)
 *                 65 bits HMAC-SHA256(SECRET, "pro:" + device ID + ":" + expiry day)
 * The KeyGenerator app uses the same SECRET and the same steps. Keep that app (and this SECRET) private.
 *
 * This is an offline check: it stops casual sharing of keys, not a determined person who patches the APK.
 */
object License {
    /** Must be identical to SECRET in the KeyGenerator app. Change both before you hand out the APK. */
    private const val SECRET = "79cae8039088f8269dfd93dd01027849"
    private const val ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    private const val PREF_KEY = "pro_key"

    private val EPOCH: LocalDate = LocalDate.of(2026, 1, 1)
    private val MASK65: BigInteger = BigInteger.ONE.shiftLeft(65).subtract(BigInteger.ONE)

    /** -1 = no valid key, 0 = lifetime, otherwise the last valid day (days since 2026-01-01 UTC). */
    @Volatile private var proExpiry: Long = -1L

    /** Goes up every time Pro switches on or off, so open screens redraw at once. */
    val changeTick = mutableIntStateOf(0)

    private const val WORK_PERIODIC = "adblocker_license_check"
    private const val WORK_AT_EXPIRY = "adblocker_license_expiry"

    /** Pro is on while a valid key is saved and its last day has not passed (checked on every read). */
    val isPro: Boolean
        get() {
            val e = proExpiry
            return when {
                e < 0L -> false
                e == 0L -> true
                else -> today() <= e
            }
        }

    /** Short text for the Pro screen: "Lifetime" or "Valid until 2026-12-17", null when not Pro. */
    fun expiryLabel(): String? {
        val e = proExpiry
        return when {
            e < 0L -> null
            e == 0L -> "Lifetime"
            else -> "Valid until " + EPOCH.plusDays(e)
        }
    }

    /** Moment (UTC millis) when the saved key stops working, or null for lifetime / no key. */
    private fun expiryMillis(): Long? {
        val e = proExpiry
        if (e <= 0L) return null
        return EPOCH.plusDays(e + 1).atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
    }

    private fun today(): Long = ChronoUnit.DAYS.between(EPOCH, LocalDate.now(ZoneOffset.UTC))

    fun deviceId(context: Context): String {
        val androidId = Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"
        val digest = MessageDigest.getInstance("SHA-256").digest("adblocker-device-v1:$androidId".toByteArray())
        return group(encode(digest.copyOf(10)))
    }

    /** Top 65 bits of HMAC-SHA256(SECRET, "pro:" + deviceId + ":" + expiry). */
    private fun mac65(deviceId: String, expiry: Long): BigInteger {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(SECRET.toByteArray(), "HmacSHA256"))
        val out = mac.doFinal(("pro:" + normalize(deviceId) + ":" + expiry).toByteArray())
        return BigInteger(1, out.copyOf(9)).shiftRight(7)
    }

    /** The expiry stored in a key that was really made for [deviceId] (date NOT checked), or null if the key is wrong. */
    private fun decode(deviceId: String, key: String): Long? {
        val given = normalize(key)
        if (given.length != 16) return null
        var n = BigInteger.ZERO
        for (c in given) n = n.shiftLeft(5).or(BigInteger.valueOf(ALPHABET.indexOf(c).toLong()))
        val expiry = n.shiftRight(65).toLong()
        val macGiven = n.and(MASK65)
        val ok = MessageDigest.isEqual(
            macGiven.toString(16).toByteArray(),
            mac65(deviceId, expiry).toString(16).toByteArray()
        )
        return if (ok) expiry else null
    }

    /**
     * Checks [key] against [deviceId] and returns its expiry (0 = lifetime, otherwise last valid day),
     * or -1 when the key is wrong or its time has already run out.
     */
    private fun check(deviceId: String, key: String): Long {
        val expiry = decode(deviceId, key) ?: return -1L
        if (expiry != 0L && today() > expiry) return -1L
        return expiry
    }

    fun verify(deviceId: String, key: String): Boolean = check(deviceId, key) >= 0L

    /**
     * Re-reads the saved key and checks it against THIS phone, so a copied settings file is worthless.
     * If the saved key's time has run out, the phone goes back to Free right here: the key is
     * removed and the Pro filter lists are dropped. Every start-up path calls this (app, VPN
     * service, boot, list updates), so it also catches an expiry that passed while the app was unused.
     */
    @Synchronized
    fun load(context: Context) {
        val app = context.applicationContext
        val saved = try { prefs(app).getString(PREF_KEY, "") ?: "" } catch (e: Exception) { "" }
        if (saved.isEmpty()) {
            setExpiry(-1L)
            return
        }
        val expiry = try { decode(deviceId(app), saved) } catch (e: Exception) { return } // keep the old state on a glitch
        when {
            expiry == null || (expiry != 0L && today() > expiry) -> revertToFree(app)
            else -> setExpiry(expiry)
        }
    }

    /** Cheap re-check that can be called often (service timer, screen resume, background job). */
    fun enforce(context: Context) = load(context)

    /** True and remembered when [key] is valid for this phone. */
    @Synchronized
    fun activate(context: Context, key: String): Boolean {
        val expiry = check(deviceId(context), key)
        if (expiry < 0L) return false
        prefs(context).edit().putString(PREF_KEY, normalize(key)).apply()
        setExpiry(expiry)
        scheduleChecks(context)
        return true
    }

    /** Manual "remove key" from the Pro screen. */
    @Synchronized
    fun deactivate(context: Context) {
        revertToFree(context.applicationContext)
    }

    /** Free again: forget the key, stop the expiry jobs and remove what only Pro had added. */
    private fun revertToFree(app: Context) {
        prefs(app).edit().remove(PREF_KEY).apply()
        setExpiry(-1L)
        try { WorkManager.getInstance(app).cancelUniqueWork(WORK_AT_EXPIRY) } catch (e: Exception) { }
        Thread { try { FilterListUpdater(app).dropProLists() } catch (e: Exception) { } }.start()
    }

    private fun setExpiry(value: Long) {
        if (proExpiry != value) {
            proExpiry = value
            changeTick.intValue++
        }
    }

    /**
     * Makes sure the phone checks the key even when the app is never opened: a one-time job that
     * fires when the key runs out, plus a 6-hourly safety check. Both survive a restart.
     */
    fun scheduleChecks(context: Context) {
        try {
            val manager = WorkManager.getInstance(context.applicationContext)
            manager.enqueueUniquePeriodicWork(
                WORK_PERIODIC, ExistingPeriodicWorkPolicy.KEEP,
                PeriodicWorkRequestBuilder<LicenseCheckWorker>(6, TimeUnit.HOURS).build()
            )
            val at = expiryMillis()
            if (at != null) {
                val delay = (at - System.currentTimeMillis() + 1_000L).coerceAtLeast(1_000L)
                manager.enqueueUniqueWork(
                    WORK_AT_EXPIRY, ExistingWorkPolicy.REPLACE,
                    OneTimeWorkRequestBuilder<LicenseCheckWorker>().setInitialDelay(delay, TimeUnit.MILLISECONDS).build()
                )
            }
        } catch (e: Exception) {
            // Scheduling is a bonus; every Pro feature also checks the date live.
        }
    }

    private fun normalize(text: String): String = text.uppercase().filter { it in ALPHABET }

    private fun group(text: String): String = text.chunked(4).joinToString("-")

    /** 5 bits per character; 10 bytes = 80 bits = exactly 16 characters. */
    private fun encode(bytes: ByteArray): String {
        val sb = StringBuilder()
        var buffer = 0
        var bits = 0
        for (b in bytes) {
            buffer = (buffer shl 8) or (b.toInt() and 0xFF)
            bits += 8
            while (bits >= 5) {
                sb.append(ALPHABET[(buffer shr (bits - 5)) and 31])
                bits -= 5
            }
            buffer = buffer and ((1 shl bits) - 1)
        }
        if (bits > 0) sb.append(ALPHABET[(buffer shl (5 - bits)) and 31])
        return sb.toString()
    }

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences("settings", Context.MODE_PRIVATE)
}

/** Runs in the background (even when the app was never opened) and sends the phone back to Free once the key has run out. */
class LicenseCheckWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        License.enforce(applicationContext)
        return Result.success()
    }
}
