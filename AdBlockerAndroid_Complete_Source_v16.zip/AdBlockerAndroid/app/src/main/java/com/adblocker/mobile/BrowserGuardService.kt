package com.adblocker.mobile

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Pop-up / redirect guard for the PHONE'S OWN browsers (Chrome, Samsung Internet, Firefox, Brave ...).
 *
 * The DNS VPN can only refuse names. When an ad tab or a redirect lands on an address the blocker
 * already refuses (filter lists, your own rules, learned rules, ad-looking names) the browser is
 * left on an error page. This service notices that address in the browser's address bar and
 * presses Back, which closes the pop-up tab (or returns to the page the redirect came from).
 *
 * Privacy: it only reads the text of the address bar of the browsers listed below, only in memory,
 * and never stores or sends it. It does not read page content, passwords or other apps.
 *
 * Safety rails: nothing happens while you are editing the address bar (or for 10 s after), a
 * closed page is given 1.5 s to settle, and more than 3 closes within 15 s pause the guard for
 * 30 s so a redirect loop can never trap the browser.
 */
class BrowserGuardService : AccessibilityService() {

    companion object {
        /** Keep in sync with android:packageNames in res/xml/browser_guard_config.xml. */
        val BROWSERS: Set<String> = setOf(
            "com.android.chrome", "com.chrome.beta", "com.chrome.dev", "com.chrome.canary",
            "com.sec.android.app.sbrowser", "com.sec.android.app.sbrowser.beta",
            "org.mozilla.firefox", "org.mozilla.firefox_beta", "org.mozilla.fenix",
            "com.brave.browser", "com.brave.browser_beta",
            "com.microsoft.emmx", "com.opera.browser", "com.opera.mini.native",
            "com.duckduckgo.mobile.android", "com.kiwibrowser.browser", "com.vivaldi.browser"
        )

        /** Resource ids (without the package) of the address bar in those browsers. */
        private val URL_BAR_IDS = listOf(
            "url_bar", "url_field", "location_bar_edit_text",
            "mozac_browser_toolbar_url_view", "omnibarTextInput"
        )

        private const val CHECK_DELAY_MS = 500L
        private const val EDIT_GRACE_MS = 10_000L
        private const val SETTLE_MS = 1_500L
        private const val MAX_CLOSES = 3
        private const val LOOP_WINDOW_MS = 15_000L
        private const val PAUSE_MS = 30_000L

        /** True when the user has switched this service on in Android's Accessibility settings. */
        fun isEnabled(context: Context): Boolean {
            return try {
                val me = ComponentName(context, BrowserGuardService::class.java)
                val list = Settings.Secure.getString(
                    context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
                ) ?: return false
                list.split(':').any { ComponentName.unflattenFromString(it) == me }
            } catch (e: Exception) {
                false
            }
        }

        /** "https://www.Example.com/path?x" -> "example.com". Null for hints, titles and non-addresses. */
        fun hostOf(raw: String?): String? {
            var t = raw?.trim()?.lowercase() ?: return null
            if (t.isEmpty() || t.contains(' ')) return null
            t = t.removePrefix("https://").removePrefix("http://").removePrefix("www.")
            t = t.substringBefore('/').substringBefore('?').substringBefore('#').substringBefore(':').trim('.')
            return if (DomainUtil.validDomain(t)) t else null
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private var thread: HandlerThread? = null
    private var worker: Handler? = null
    private var database: AdBlockerDatabase? = null
    private val scheduled = AtomicBoolean(false)

    // Only touched on the worker thread.
    private var lastUrlFocus = 0L
    private var ignoreUntil = 0L
    private var pausedUntil = 0L
    private val closeTimes = ArrayDeque<Long>()

    override fun onServiceConnected() {
        super.onServiceConnected()
        AppPrefs.load(this)
        database = AdBlockerDatabase.get(this)
        val t = HandlerThread("BrowserGuard").also { it.start() }
        thread = t
        worker = Handler(t.looper)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val e = event ?: return
        val pkg = e.packageName?.toString() ?: return
        if (pkg !in BROWSERS || !AppPrefs.browserGuard) return
        when (e.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED,
            AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED -> schedule(pkg)
        }
    }

    override fun onInterrupt() {}

    /** At most one check per [CHECK_DELAY_MS]: busy pages fire hundreds of content events. */
    private fun schedule(pkg: String) {
        val handler = worker ?: return
        if (!scheduled.compareAndSet(false, true)) return
        handler.postDelayed({
            scheduled.set(false)
            check(pkg)
        }, CHECK_DELAY_MS)
    }

    private fun check(pkg: String) {
        try {
            if (!AppPrefs.browserGuard) return
            val now = System.currentTimeMillis()
            if (now < ignoreUntil || now < pausedUntil) return

            val root = rootInActiveWindow ?: return
            if (root.packageName?.toString() != pkg) return
            val bar = findAddressBar(root, pkg) ?: return

            // The user is typing an address: never interfere with that.
            if (bar.isFocused) { lastUrlFocus = now; return }
            if (now - lastUrlFocus < EDIT_GRACE_MS) return

            val host = hostOf(bar.text?.toString()) ?: return
            val db = database ?: return
            val bad = db.isKnownBadHost(host, AppPrefs.autoLevel) &&
                AppPrefs.kindEnabled(EventKind.classify(host))
            if (bad) closePage(host, now)
        } catch (e: Exception) {
            // A browser update can change its views; skip this round.
        }
    }

    private fun findAddressBar(root: AccessibilityNodeInfo, pkg: String): AccessibilityNodeInfo? {
        for (id in URL_BAR_IDS) {
            val found = root.findAccessibilityNodeInfosByViewId("$pkg:id/$id")
            if (!found.isNullOrEmpty()) return found[0]
        }
        return null
    }

    private fun closePage(host: String, now: Long) {
        while (closeTimes.isNotEmpty() && now - closeTimes.first() > LOOP_WINDOW_MS) closeTimes.removeFirst()
        if (closeTimes.size >= MAX_CLOSES) {
            // Looks like a redirect loop: stop pressing Back for a while.
            closeTimes.clear()
            pausedUntil = now + PAUSE_MS
            toast(
                if (AppPrefs.language == "si") "පොප්-අප් ආරක්ෂකය තත්පර 30කට නතර කළා (නැවත නැවත redirect වෙනවා)"
                else "Pop-up guard paused for 30 s (page keeps redirecting)"
            )
            return
        }
        closeTimes.addLast(now)
        ignoreUntil = now + SETTLE_MS
        performGlobalAction(GLOBAL_ACTION_BACK)
        AppPrefs.addGuardClosed(this)
        // Shows up in History > Pop-ups (the DNS lookup of the same name is logged separately).
        database?.addBlockedEvent(host, EventKind.GUARD_CATEGORY)
        toast(
            if (AppPrefs.language == "si") "දැන්වීම් පිටුවක් වැසුවා: $host"
            else "Closed an ad page: $host"
        )
    }

    private fun toast(message: String) {
        main.post {
            try { Toast.makeText(applicationContext, message, Toast.LENGTH_SHORT).show() } catch (e: Exception) { }
        }
    }

    override fun onDestroy() {
        worker?.removeCallbacksAndMessages(null)
        thread?.quitSafely()
        thread = null
        worker = null
        super.onDestroy()
    }
}
