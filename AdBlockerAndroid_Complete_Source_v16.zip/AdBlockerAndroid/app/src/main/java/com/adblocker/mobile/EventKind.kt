package com.adblocker.mobile

/**
 * Sorts a blocked domain into one of the four groups shown in History and Stats.
 * A DNS blocker only sees names, so this is a best-effort guess from the words in the name.
 */
object EventKind {
    const val AD = "ad"
    const val POPUP = "popup"
    const val TRACKER = "tracker"
    const val OTHER = "other"

    /** Category stored with an event when the phone-browser guard closed an ad tab (see BrowserGuardService). */
    const val GUARD_CATEGORY = "Popup"

    /**
     * Pop-up / pop-under / redirect networks. Their names rarely contain "popup", so the word
     * check below would file them under plain ads. A listed domain also covers its subdomains.
     */
    private val popupNetworks = setOf(
        "monetag.com", "profitablecpmrate.com", "profitablegatecpm.com", "effectivegatecpm.com",
        "highperformanceformat.com", "popcash.net", "popads.net", "onclickads.net", "onclkds.com",
        "tsyndicate.com", "adcash.com", "admaven.com", "ad-maven.com", "adtng.com", "juicyads.me",
        "ero-advertising.com", "trafficfactory.biz", "clkmg.com", "oclasrv.com", "ocmtag.com",
        "adsco.re", "bidvertiser.com", "revenuehits.com", "zeropark.com", "popmyads.com",
        "popunderjs.com", "hilltopads.net", "hilltopads.com", "adspyglass.com", "adsterra.com",
        "propellerads.com", "exoclick.com", "clickadu.com", "trafficjunky.com"
    )

    private val popupWords = listOf(
        "popad", "popcash", "popunder", "popup", "pop-up", "clickadu", "propeller", "onclick",
        "clickunder", "adsterra", "exoclick", "juicyads", "trafficjunky", "richpush", "pushwoosh",
        "interstitial", "redirect", "landing", "offer"
    )
    private val trackerWords = listOf(
        "track", "analytic", "telemetry", "metric", "beacon", "pixel", "insight", "measure",
        "scorecard", "segment", "mixpanel", "hotjar", "amplitude", "crashlytics", "appsflyer",
        "adjust", "kochava", "singular", "omtrdc", "quantserve", "comscore", "chartbeat",
        "newrelic", "bugsnag", "flurry", "clarity", "stats", "statcounter", "sentry", "heap"
    )
    private val otherWords = listOf(
        "script", "sdk", "widget", "overlay", "consent", "cookie", "gdpr", "notice", "banner-js",
        "tag", "cdn", "loader", "bundle"
    )

    /** Kind of a stored event: a guard-closed page is always a pop-up, everything else goes by name. */
    fun of(domain: String, category: String): String =
        if (category == GUARD_CATEGORY) POPUP else classify(domain)

    private fun isPopupNetwork(d: String): Boolean {
        var candidate = d
        while (candidate.contains('.')) {
            if (candidate in popupNetworks) return true
            candidate = candidate.substringAfter('.')
        }
        return false
    }

    fun classify(domain: String): String {
        val d = domain.lowercase()
        if (isPopupNetwork(d)) return POPUP
        if (popupWords.any { d.contains(it) }) return POPUP
        if (trackerWords.any { d.contains(it) }) return TRACKER
        if (otherWords.any { d.contains(it) }) return OTHER
        return AD
    }

    // Average size / time of a blocked request, used for the "Data saved" and "Time saved"
    // estimates (the phone cannot see what a blocked request would have downloaded).
    const val AVG_BYTES = 42_000L
    const val AVG_MILLIS = 870L
}
