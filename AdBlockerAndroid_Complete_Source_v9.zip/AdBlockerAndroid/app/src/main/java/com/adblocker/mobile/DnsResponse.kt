package com.adblocker.mobile

/** Reads DNS answers (no Android dependencies). */
object DnsResponse {
    /**
     * Names that an answer points to through CNAME records. A tracker hidden behind a harmless
     * looking sub-domain of the site ("CNAME cloaking") shows up here even though the name that
     * was asked for is not on any list.
     */
    fun cnameTargets(m: ByteArray): List<String> {
        val out = ArrayList<String>()
        try {
            if (m.size < 12 || (PacketUtil.u16(m, 2) and 0x8000) == 0) return out
            val questions = PacketUtil.u16(m, 4)
            val answers = minOf(PacketUtil.u16(m, 6), 32)
            var pos = 12
            repeat(questions) { pos = skipName(m, pos) + 4 }
            repeat(answers) {
                pos = skipName(m, pos)
                if (pos + 10 > m.size) return out
                val type = PacketUtil.u16(m, pos)
                val length = PacketUtil.u16(m, pos + 8)
                val start = pos + 10
                if (start + length > m.size) return out
                if (type == 5) readName(m, start)?.let { out.add(it) }
                pos = start + length
            }
        } catch (e: Exception) {
            // Malformed answer: ignore, the request is simply not inspected further.
        }
        return out
    }

    private fun skipName(m: ByteArray, start: Int): Int {
        var pos = start
        while (true) {
            if (pos >= m.size) throw IllegalArgumentException("truncated")
            val len = m[pos].toInt() and 0xFF
            if (len == 0) return pos + 1
            if ((len and 0xC0) == 0xC0) return pos + 2
            pos += len + 1
        }
    }

    private fun readName(m: ByteArray, start: Int): String? {
        val labels = ArrayList<String>()
        var pos = start
        var jumps = 0
        while (true) {
            if (pos >= m.size) return null
            val len = m[pos].toInt() and 0xFF
            if (len == 0) break
            if ((len and 0xC0) == 0xC0) {
                if (pos + 1 >= m.size || ++jumps > 10) return null
                pos = ((len and 0x3F) shl 8) or (m[pos + 1].toInt() and 0xFF)
                continue
            }
            if (len > 63 || pos + 1 + len > m.size) return null
            labels.add(String(m, pos + 1, len, Charsets.US_ASCII))
            pos += len + 1
        }
        return if (labels.isEmpty()) null else labels.joinToString(".").lowercase()
    }
}
