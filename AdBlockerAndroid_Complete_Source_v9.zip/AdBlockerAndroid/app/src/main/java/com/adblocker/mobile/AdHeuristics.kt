package com.adblocker.mobile

/**
 * "Smart detection": catches ad servers that no list knows yet by their naming habits,
 * e.g. ads.example.com, adserver3.example.net, pagead2.example.org, x.banners.example.com.
 * Only the names in front of the registrable domain (the last two labels) are inspected, so
 * ordinary sites whose own name merely starts with "ad" are never touched.
 */
object AdHeuristics {
    private val adLabel = Regex(
        "^(ads?|adx|adv|adserver\\w*|adservice\\w*|adsystem\\w*|adtech\\w*|adnet\\w*|adsrv\\w*|" +
            "adsdk\\w*|adview\\w*|adclick\\w*|adlog\\w*|adtrack\\w*|adimg\\w*|advert\\w*|banners?|" +
            "pagead\\d*|adsense\\w*|adserving)(-?\\d{1,3})?$"
    )

    fun looksLikeAd(host: String): Boolean {
        val labels = host.split('.')
        if (labels.size < 3) return false
        for (i in 0 until labels.size - 2) {
            if (adLabel.matches(labels[i])) return true
        }
        return false
    }
}
