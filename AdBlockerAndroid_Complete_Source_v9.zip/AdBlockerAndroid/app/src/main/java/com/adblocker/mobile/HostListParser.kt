package com.adblocker.mobile

/** Host-name helpers shared by the database, the DNS service and the list parser. */
object DomainUtil {
    private val ipv4 = Regex("^\\d{1,3}(\\.\\d{1,3}){3}$")

    fun normalizeHost(value: String): String =
        value.trim().lowercase().removePrefix("https://").removePrefix("http://")
            .substringBefore('/').substringBefore(':').trim('.')

    fun validDomain(host: String): Boolean {
        if (host.length !in 1..253 || !host.contains('.')) return false
        return host.split('.').all { label ->
            label.length in 1..63 && label.first().isLetterOrDigit() &&
                label.last().isLetterOrDigit() && label.all { it.isLetterOrDigit() || it == '-' }
        }
    }

    fun isIpv4(host: String): Boolean = ipv4.matches(host)

    private val sharedSuffixes = setOf("co", "com", "org", "net", "gov", "edu", "ac", "or", "ne", "go")

    /**
     * The host and its parent domains, longest first, for "block this or everything under its
     * parent" choices. Bare public suffixes such as co.uk are left out on purpose: blocking one
     * would cut off every site below it.
     */
    fun blockChoices(host: String): List<String> {
        val out = ArrayList<String>()
        var candidate = normalizeHost(host)
        while (candidate.contains('.')) {
            val labels = candidate.split('.')
            val bareSuffix = labels.size == 2 && labels[0] in sharedSuffixes && labels[1].length == 2
            if (!bareSuffix && validDomain(candidate)) out.add(candidate)
            candidate = candidate.substringAfter('.')
        }
        return out
    }
}

/**
 * Reads one line at a time from the supported filter-list formats and collects the domains:
 *  - hosts files:        `0.0.0.0 ads.example.com`
 *  - plain domain lists: `ads.example.com`
 *  - AdGuard DNS syntax: `||ads.example.com^`  (exceptions, wildcards, regex and rules with
 *    other modifiers are skipped because a plain DNS blocker cannot apply them)
 */
object HostListParser {
    private val sinks = setOf("0.0.0.0", "127.0.0.1", "::", "::1")
    private val whitespace = Regex("\\s+")

    fun parseLine(raw: String, out: MutableCollection<String>) {
        val line = raw.trim()
        if (line.isEmpty()) return
        when (line[0]) {
            '!', '[', '/' -> return          // AdGuard/Adblock comments, headers and regex rules
            '#' -> return                    // hosts comment
            '@' -> return                    // @@ exception rules
        }
        if (line.startsWith("||")) {
            addAdGuardRule(line.substring(2), out)
        } else if (line[0] == '.' && line.endsWith("^")) {
            addAdGuardRule(line.substring(1), out)
        } else {
            addHostsLine(line.substringBefore('#').trim(), out)
        }
    }

    private fun addAdGuardRule(rule: String, out: MutableCollection<String>) {
        val caret = rule.indexOf('^')
        if (caret <= 0) return
        val modifiers = rule.substring(caret + 1)
        if (modifiers.isNotEmpty() && modifiers != "\$important") return
        val domain = rule.substring(0, caret)
        if ('*' in domain || '/' in domain) return
        addDomain(domain, out)
    }

    private fun addHostsLine(line: String, out: MutableCollection<String>) {
        if (line.isEmpty()) return
        val fields = line.split(whitespace)
        if (fields[0] in sinks) {
            for (i in 1 until fields.size) addDomain(fields[i], out)
        } else if (fields.size == 1) {
            addDomain(fields[0], out)
        }
    }

    private fun addDomain(candidate: String, out: MutableCollection<String>) {
        val host = DomainUtil.normalizeHost(candidate)
        if (host == "localhost" || DomainUtil.isIpv4(host)) return
        if (DomainUtil.validDomain(host)) out.add(host)
    }
}
