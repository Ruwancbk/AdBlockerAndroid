package com.adblocker.mobile

import android.content.Context

/** Small settings shared by the screens, the VPN service and the boot receiver. */
object AppPrefs {
    private const val FILE = "settings"

    /** Read on every DNS lookup, so it is kept in memory. */
    @Volatile
    var smartBlocking: Boolean = true
        private set

    fun load(context: Context) {
        smartBlocking = prefs(context).getBoolean("smart_blocking", true)
    }

    fun setSmartBlocking(context: Context, value: Boolean) {
        smartBlocking = value
        prefs(context).edit().putBoolean("smart_blocking", value).apply()
    }

    /** True while the user wants protection on (set by the power button, not by the system). */
    fun protectionWanted(context: Context): Boolean = prefs(context).getBoolean("protection_wanted", false)

    fun setProtectionWanted(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean("protection_wanted", value).apply()
    }

    fun startOnBoot(context: Context): Boolean = prefs(context).getBoolean("start_on_boot", true)

    fun setStartOnBoot(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean("start_on_boot", value).apply()
    }

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)
}
