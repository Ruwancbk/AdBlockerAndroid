# Ad Blocker Android (v9)

Android Studio project (Kotlin, Jetpack Compose, package `com.adblocker.mobile`):
Home, Browser, Stats, History, Tools, Settings, Allowlist and a Premium preview screen.

## How it works
- `DnsVpnService` is a DNS-only local VPN. Only the synthetic resolver `10.10.10.1` is routed
  through the TUN interface. Domains in the downloaded filter list get an NXDOMAIN answer;
  everything else is forwarded to Cloudflare (`1.1.1.1`, then `1.0.0.1`) over IPv4 UDP.
- The filter lists are StevenBlack hosts and the AdGuard DNS filter (about 200,000 domains
  together), downloaded over HTTPS (size-limited and validated) and stored in SQLite. A listed
  domain also blocks all its subdomains. The download starts as soon as Ad Blocking is turned
  ON with no list present; after that it refreshes about every 24 hours (WorkManager) or
  manually from Settings.
- The built-in browser (WebView) filters requests with the same list. JavaScript is off by
  default and can be enabled in Settings.

## Build
- Android Studio: open the folder, use JDK 17 and SDK Platform 35, sync, then
  Build > Build APK(s).
- GitHub: push to GitHub, open Actions > **Build Ad Blocker APK** > Run workflow, then download
  the `AdBlocker-debug-apk` artifact. The workflow installs Gradle 8.10.2 itself, so no Gradle
  wrapper is needed. The APK is debug-signed (for testing; Play Store needs a release key).

## Changes in v9
- DNS Log & Rules (Tools, or tap the "DNS lookups seen" card on Home): every lookup as it
  happens, grouped by app where Android reports the owner. Play an ad, find its domain in the
  log and block it (or its parent domain) with one tap. Your rules survive list updates. The
  log is kept in memory only.
- Smart ad detection (Settings, on by default): blocks names like ads.*, adserver*, pagead*,
  banners.* that no list knows yet. Only labels in front of the registrable domain are checked.
- More resolvers are intercepted (Cloudflare/Quad9/OpenDNS/AdGuard variants and Chinese
  "HTTPDNS" services that apps use to skip system DNS).
- Protection restarts after a reboot and after the app is updated (Settings: "Start protection
  when the phone restarts").
- Every blocked lookup records why (list name, Custom, Smart detection, CNAME of ...).

## Changes in v8
- Fixed signing key (`app/adblocker.keystore`) is used for every build, so a new APK installs
  over the previous one (keeps settings and allowlist). Builds from before v8 used a random
  key per build: uninstall that copy once, later updates install over it. Keep the keystore
  file when you rebuild, and use a higher `versionCode` each time.
- Five filter lists (StevenBlack, AdGuard DNS, AdAway, AdServers, GoodbyeAds) plus a built-in
  list of ad-SDK domains (AppLovin, Unity Ads, ironSource, Vungle, Mintegral, Pangle, ...) and
  SHAREit's own servers. The built-in list works even before the first download.
- CNAME-cloaking check: a harmless-looking name that is an alias of a listed tracker is blocked.
- New logo and launcher icon.

## Changes in v7
- Apps that hard-code a public DNS server (8.8.8.8, 1.1.1.1, 9.9.9.9, OpenDNS, AdGuard, ...) are
  now filtered too: those addresses are routed into the tunnel. Encrypted-DNS attempts to them
  (TCP) are refused with a reset so the app falls back to normal DNS.
- Home shows live "DNS lookups seen / blocked" counters; if "seen" stays 0 while browsing, the
  phone is sending DNS around the blocker.
- "Test ad blocking" now says exactly where the test lookup ended up.

## Changes in v6 (ads still showing)
- Filter list is downloaded immediately when protection is turned ON (before, an empty list
  blocked nothing until a background job ran).
- Second list added (AdGuard DNS filter) and subdomain matching enabled, so far more ad
  domains are caught. Database upgraded to v3 (the old list is replaced automatically).
- TUN interface is now blocking, so DNS replies are no longer delayed by polling.
- Home screen warns when strict Private DNS is bypassing the blocker.
- Tools > "Test ad blocking" checks that an ad domain really is blocked on the phone.

## Changes in v5
- Fixed compile errors: missing `AdDomainFilter` and the nested `Result` type in the updater.
- Fixed CI: Gradle version is pinned (AGP 8.7.3 needs Gradle 8.9+).
- DNS queries are handled on a thread pool; one slow lookup no longer stalls the phone.
- Single shared database in WAL mode; filter import uses a prepared statement; blocked events
  are queued and written in batches, history is capped at the latest 1000 events.
- NXDOMAIN replies no longer carry leftover EDNS bytes.
- `onRevoke()` handled; the power button reflects the real VPN state; notification permission
  requested on Android 13+.
- Browser: no longer reloads on every keystroke or refresh; JavaScript and browser blocking are
  real, saved settings. The non-functional toggles were removed.
- Blocklist matching is exact (hosts-file semantics); allowlist entries also cover subdomains.
- Database reads for the UI run off the main thread.

## Known limits
- IPv4 UDP DNS only. Private DNS, DNS-over-HTTPS/TLS, DNS over TCP, IPv6, hard-coded IPs and
  apps with their own encrypted resolver bypass the filter.
- DNS blocking cannot separate ads served from the same domain as content (many video ads).
- Community lists can block legitimate sites; use Allowed Websites to add exceptions.
- Premium is a UI preview, billing is not connected. Speed test is a placeholder.
- Not yet tested on real devices. Before any Play Store release: test on several Android
  versions, add DNS protocol tests, and review Google Play VPN and foreground-service policies.

## Privacy
Allowed DNS queries go to Cloudflare. Blocked domains are stored locally for the History screen.
No analytics and no account.
