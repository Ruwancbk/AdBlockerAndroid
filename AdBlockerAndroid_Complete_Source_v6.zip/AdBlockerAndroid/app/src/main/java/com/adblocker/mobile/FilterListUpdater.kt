package com.adblocker.mobile

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.TimeUnit

class FilterListUpdater(private val context: Context) {
    private class FilterSource(val id: String, val url: String)

    companion object {
        private const val MAX_BYTES = 20L * 1024 * 1024
        private const val MIN_DOMAINS = 100

        /** Both lists are merged; a domain in either one is blocked. */
        private val SOURCES = listOf(
            FilterSource("StevenBlack", "https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts"),
            FilterSource("AdGuard DNS", "https://raw.githubusercontent.com/AdguardTeam/AdGuardSDNSFilter/gh-pages/Filters/filter.txt")
        )
    }

    /** Runs the download on a background thread and reports on the main thread. */
    fun update(onComplete: (kotlin.Result<Int>) -> Unit) {
        Thread {
            val result = downloadAndSave()
            Handler(Looper.getMainLooper()).post { onComplete(result) }
        }.start()
    }

    /** Daily refresh, plus a one-time first download when no list exists yet. */
    fun scheduleDailyUpdates() {
        val constraints = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
        val periodic = PeriodicWorkRequestBuilder<FilterUpdateWorker>(24, TimeUnit.HOURS)
            .setConstraints(constraints)
            .build()
        val manager = WorkManager.getInstance(context)
        manager.enqueueUniquePeriodicWork(
            "adblocker_filter_update", ExistingPeriodicWorkPolicy.KEEP, periodic
        )
        Thread {
            try {
                if (AdBlockerDatabase.get(context).lastUpdateMillis() == 0L) {
                    val once = OneTimeWorkRequestBuilder<FilterUpdateWorker>()
                        .setConstraints(constraints)
                        .build()
                    manager.enqueueUniqueWork("adblocker_filter_initial", ExistingWorkPolicy.KEEP, once)
                }
            } catch (ignored: Exception) {
            }
        }.start()
    }

    fun updateNow(): kotlin.Result<Int> = downloadAndSave()

    /** Updates every list. Succeeds if at least one list was refreshed. */
    private fun downloadAndSave(): kotlin.Result<Int> = runCatching {
        val db = AdBlockerDatabase.get(context)
        val failures = ArrayList<String>()
        var updated = 0
        for (source in SOURCES) {
            try {
                val domains = download(source)
                require(domains.size >= MIN_DOMAINS) { "list looks empty or invalid" }
                db.replaceRemoteDomains(domains, source.id)
                updated++
            } catch (e: Exception) {
                failures.add("${source.id}: ${e.message ?: e.javaClass.simpleName}")
            }
        }
        if (updated == 0) error("Update failed (" + failures.joinToString("; ") + ")")
        db.filterCount()
    }

    /** Streams the list line by line, so large files never have to fit in memory as one string. */
    private fun download(source: FilterSource): Set<String> {
        val connection = (URL(source.url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout = 30_000
            requestMethod = "GET"
            setRequestProperty("User-Agent", "AdBlockerAndroid/1.0")
        }
        try {
            if (connection.responseCode !in 200..299) error("server error ${connection.responseCode}")
            val domains = HashSet<String>()
            LimitedInputStream(connection.inputStream, MAX_BYTES)
                .bufferedReader(Charsets.UTF_8)
                .useLines { lines -> lines.forEach { HostListParser.parseLine(it, domains) } }
            return domains
        } finally {
            connection.disconnect()
        }
    }

    private class LimitedInputStream(input: InputStream, private val limit: Long) : FilterInputStream(input) {
        private var count = 0L

        override fun read(): Int {
            val b = super.read()
            if (b >= 0) add(1)
            return b
        }

        override fun read(b: ByteArray, off: Int, len: Int): Int {
            val n = super.read(b, off, len)
            if (n > 0) add(n)
            return n
        }

        private fun add(n: Int) {
            count += n
            if (count > limit) throw IOException("file exceeds size limit")
        }
    }
}

class FilterUpdateWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        val update = FilterListUpdater(applicationContext).updateNow()
        return if (update.isSuccess) Result.success()
        else if (runAttemptCount < 3) Result.retry() else Result.failure()
    }
}
