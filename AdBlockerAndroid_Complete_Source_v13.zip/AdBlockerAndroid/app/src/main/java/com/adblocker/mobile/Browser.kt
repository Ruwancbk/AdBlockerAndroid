package com.adblocker.mobile

import android.content.Intent
import android.net.Uri
import android.os.Message
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature

fun toBrowserUrl(input: String): String {
    val value = input.trim()
    return when {
        value.startsWith("http://") || value.startsWith("https://") -> value
        value.contains('.') && !value.contains(' ') -> "https://$value"
        else -> SearchEngines.url(AppPrefs.searchEngine) + java.net.URLEncoder.encode(value, "UTF-8")
    }
}

private const val HIDE_ANNOYING_JS =
    "(function(){var s=document.createElement('style');" +
        "s.textContent='[id*=\"cookie\" i],[class*=\"cookie\" i],[id*=\"consent\" i],[class*=\"consent\" i]," +
        "[id*=\"gdpr\" i],[class*=\"gdpr\" i],[class*=\"newsletter-popup\" i],[class*=\"modal-backdrop\" i]" +
        "{display:none !important}body{overflow:auto !important}';document.head.appendChild(s);})();"

@Composable
fun BrowserScreen(
    db: AdBlockerDatabase,
    urlInput: String,
    browserUrl: String,
    onInput: (String) -> Unit,
    onGo: (String) -> Unit,
    javaScript: Boolean,
    blockAds: Boolean,
    onPro: () -> Unit,
    onSettings: () -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        BrandHeader(onPro = onPro) { RoundIconButton(Icons.Default.Settings, "Settings", onSettings) }
        Column(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 14.dp)) {
            OutlinedTextField(
                value = urlInput, onValueChange = onInput,
                modifier = Modifier.fillMaxWidth(),
                label = { Text(tr("Search or enter website URL", "සොයන්න හෝ වෙබ් URL එක ඇතුළත් කරන්න")) },
                trailingIcon = {
                    IconButton(onClick = { onGo(toBrowserUrl(urlInput)) }) { Icon(Icons.Default.Search, contentDescription = "Go") }
                },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { onGo(toBrowserUrl(urlInput)) }),
                singleLine = true, shape = RoundedCornerShape(50)
            )
            Spacer(Modifier.height(8.dp))
            SoftCard(Modifier.weight(1f).fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
                BrowserPane(browserUrl, db, javaScript, blockAds, Modifier.fillMaxSize())
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

/** Registrable domain of a host (a.b.example.com -> example.com), used to tell "same site" from "other site". */
private fun siteOf(host: String?): String {
    val h = host?.lowercase()?.trim('.') ?: return ""
    if (DomainUtil.isIpv4(h)) return h
    val labels = h.split('.')
    if (labels.size < 2) return h
    val keep = DomainUtil.registrableLabelCount(labels)
    return labels.takeLast(minOf(keep, labels.size)).joinToString(".")
}

/** Typical file / path names of pop-under and click-under scripts. Only used for third-party requests. */
private val AD_URL_PARTS = listOf(
    "popunder", "pop-under", "clickunder", "click-under", "popads", "popcash", "/pop.js", "/popup.js",
    "/popunder", "/pu.js", "/adsbygoogle", "/pagead/", "/adserver", "/ad-provider", "/adframe",
    "/prebid", "/direct-link", "/smartlink", "/clickadu", "onclick-ad", "/onclickads"
)

private fun looksLikeAdUrl(url: String): Boolean {
    val u = url.lowercase()
    return AD_URL_PARTS.any { u.contains(it) }
}

private fun hostOf(url: String?): String? =
    url?.let { runCatching { Uri.parse(it).host }.getOrNull() }

private val EMPTY_BYTES = ByteArray(0)
private fun emptyResponse() = WebResourceResponse("text/plain", "utf-8", java.io.ByteArrayInputStream(EMPTY_BYTES))

/**
 * Runs at the very start of every page (before the site's own scripts):
 *  - window.open() gives the page a dead fake window instead of opening an ad tab or replacing the page;
 *  - invisible full-screen layers that catch every tap and fire an ad (the classic torrent-site
 *    "first click opens an ad" trick) are removed.
 */
private const val SHIELD_JS = """
(function(){
  if (window.__abShield) return; window.__abShield = true;
  function off(){ try { return !AdShieldBridge.popupsBlocked(); } catch(e) { return false; } }
  function report(u){ try { AdShieldBridge.popupBlocked(String(u||'')); } catch(e) {} }
  var n = function(){};
  function fakeWindow(){
    return { closed:true, focus:n, blur:n, close:n, postMessage:n, addEventListener:n,
             document:{ write:n, writeln:n, open:n, close:n }, location:{ href:'', assign:n, replace:n } };
  }
  try {
    var realOpen = window.open;
    window.open = function(u){
      if (off()) return realOpen.apply(window, arguments);
      report(u); return fakeWindow();
    };
  } catch(e) {}
  function sweep(){
    try {
      if (off() || !document.body) return;
      var w = window.innerWidth, h = window.innerHeight;
      var list = document.body.querySelectorAll('div,a,span,ins,iframe');
      var max = Math.min(list.length, 1500);
      for (var i = 0; i < max; i++) {
        var el = list[i];
        var cs = getComputedStyle(el);
        if (cs.position !== 'fixed' && cs.position !== 'absolute') continue;
        var r = el.getBoundingClientRect();
        if (r.width < w * 0.8 || r.height < h * 0.8) continue;
        var z = parseInt(cs.zIndex, 10) || 0;
        if (z < 50) continue;
        var clear = parseFloat(cs.opacity) < 0.05 ||
          (/rgba\(\s*0,\s*0,\s*0,\s*0\s*\)|transparent/.test(cs.backgroundColor) &&
           cs.backgroundImage === 'none');
        var empty = !(el.innerText || '').trim() &&
          !el.querySelector('video,img,input,button,form,canvas,select,textarea,svg');
        if (clear && empty) { report('overlay'); el.remove(); }
      }
    } catch(e) {}
  }
  var runs = 0;
  var timer = setInterval(function(){ sweep(); if (++runs > 60) clearInterval(timer); }, 1000);
  document.addEventListener('DOMContentLoaded', sweep);
  window.addEventListener('load', sweep);
})();
"""

/** Lets the injected script above ask for the current setting and report what it stopped. */
private class ShieldBridge(private val db: AdBlockerDatabase) {
    @JavascriptInterface
    fun popupsBlocked(): Boolean = AppPrefs.blockPopups

    @JavascriptInterface
    fun popupBlocked(url: String) {
        if (!AppPrefs.blockPopups) return
        val host = runCatching { Uri.parse(url).host }.getOrNull()?.lowercase()
        db.addBlockedEvent(if (host.isNullOrBlank()) "popup.window" else host, "Browser")
    }
}

@Composable
private fun BrowserPane(url: String, db: AdBlockerDatabase, javaScript: Boolean, blockAds: Boolean, modifier: Modifier = Modifier) {
    val blockState = rememberUpdatedState(blockAds)
    // Remembers what was last loaded so recompositions never reload the page.
    val lastLoaded = remember { arrayOfNulls<String>(1) }
    AndroidView(
        modifier = modifier,
        factory = { context ->
            WebView(context).apply {
                settings.domStorageEnabled = false
                addJavascriptInterface(ShieldBridge(db), "AdShieldBridge")
                if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
                    WebViewCompat.addDocumentStartJavaScript(this, SHIELD_JS, setOf("*"))
                }

                // Every window.open() / target=_blank from a page ends up here. Without this the
                // WebView loads the pop-up address INSIDE the current page, which is the "I clicked
                // and it jumped to another site" problem. We hand the page a throw-away window,
                // note where it wanted to go and never show it.
                webChromeClient = object : WebChromeClient() {
                    override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message?): Boolean {
                        val parent = view ?: return false
                        val msg = resultMsg ?: return false
                        val transport = msg.obj as? WebView.WebViewTransport ?: return false
                        if (!AppPrefs.blockPopups) return false
                        val temp = WebView(parent.context)
                        temp.settings.javaScriptEnabled = false
                        temp.webViewClient = object : WebViewClient() {
                            private var done = false
                            private fun finish(target: Uri?) {
                                if (done) return
                                done = true
                                val h = target?.host?.lowercase()
                                db.addBlockedEvent(if (h.isNullOrBlank()) "popup.window" else h, "Browser")
                                parent.post { runCatching { temp.stopLoading(); temp.destroy() } }
                            }
                            override fun shouldOverrideUrlLoading(v: WebView?, request: WebResourceRequest?): Boolean {
                                finish(request?.url); return true
                            }
                            override fun shouldInterceptRequest(v: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                                if (request?.isForMainFrame == true) finish(request.url)
                                return emptyResponse()
                            }
                        }
                        transport.webView = temp
                        msg.sendToTarget()
                        return true
                    }
                }

                webViewClient = object : WebViewClient() {
                    override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                        if (!blockState.value) return null
                        val uri = request?.url ?: return null
                        val host = uri.host?.lowercase() ?: return null
                        if (db.isDomainBlocked(host)) {
                            db.addBlockedEvent(host, "Browser")
                            return emptyResponse()
                        }
                        // Ad servers change names daily; known pop-under script names are caught on the path as well.
                        val pageSite = siteOf(hostOf(view?.url))
                        if (AppPrefs.blockPopups && pageSite.isNotEmpty() && siteOf(host) != pageSite &&
                            looksLikeAdUrl(uri.toString())
                        ) {
                            db.addBlockedEvent(host, "Browser")
                            return emptyResponse()
                        }
                        return null
                    }

                    // Every link, redirect and script navigation of the page passes here first.
                    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                        val req = request ?: return false
                        val uri = req.url ?: return false
                        val scheme = uri.scheme?.lowercase() ?: ""
                        val host = uri.host?.lowercase() ?: ""

                        // Torrent sites: a tapped magnet link goes to the torrent app; nothing else may leave the browser.
                        if (scheme == "magnet") {
                            if (req.hasGesture()) {
                                runCatching {
                                    view?.context?.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                                }
                            }
                            return true
                        }
                        if (scheme != "http" && scheme != "https") {
                            // intent://, market://, app deep links, data: and javascript: jumps opened by ads.
                            if (!req.isForMainFrame) return false
                            if (AppPrefs.blockPopups) { db.addBlockedEvent(if (host.isEmpty()) "popup.window" else host, "Browser"); return true }
                            return false
                        }
                        if (host.isNotEmpty() && blockState.value && db.isDomainBlocked(host)) {
                            db.addBlockedEvent(host, "Browser")
                            return true
                        }
                        if (!AppPrefs.blockPopups || !req.isForMainFrame) return false

                        // A script (no tap behind it) sending the page to another site is an ad redirect.
                        // Real server redirects (isRedirect) are left alone unless the target is a known ad name above.
                        val current = siteOf(hostOf(view?.url))
                        val target = siteOf(host)
                        if (!req.hasGesture() && !req.isRedirect && current.isNotEmpty() && target != current) {
                            db.addBlockedEvent(host, "Browser")
                            return true
                        }
                        // A tap that jumps straight to an address that looks like a pop-under / smart-link.
                        if (target != current && looksLikeAdUrl(uri.toString())) {
                            db.addBlockedEvent(host, "Browser")
                            return true
                        }
                        return false
                    }

                    override fun onPageFinished(view: WebView?, pageUrl: String?) {
                        // Cosmetic hiding needs JavaScript; with it off, the network blocking above still applies.
                        if (AppPrefs.blockAnnoying) {
                            view?.let { if (it.settings.javaScriptEnabled) it.evaluateJavascript(HIDE_ANNOYING_JS, null) }
                        }
                    }
                }
            }
        },
        update = { web ->
            web.settings.javaScriptEnabled = javaScript
            // Pop-ups: no window may be opened by scripts while "Block Pop-ups" is on, and the
            // ones that are requested are caught by onCreateWindow (needs multiple windows).
            web.settings.javaScriptCanOpenWindowsAutomatically = !AppPrefs.blockPopups
            web.settings.setSupportMultipleWindows(AppPrefs.blockPopups)
            // Faster Browsing: reuse cached pages and files whenever possible.
            web.settings.cacheMode = if (AppPrefs.fasterBrowsing) WebSettings.LOAD_CACHE_ELSE_NETWORK else WebSettings.LOAD_DEFAULT
            // Enhanced Privacy: no third-party cookies and no location sharing.
            CookieManager.getInstance().setAcceptThirdPartyCookies(web, !AppPrefs.enhancedPrivacy)
            web.settings.setGeolocationEnabled(!AppPrefs.enhancedPrivacy)
            val target = url.trim()
            if (target.isNotBlank() && lastLoaded[0] != target) {
                lastLoaded[0] = target
                web.loadUrl(target)
            }
        }
    )
}
