package com.adblocker.mobile

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Universal best-effort pop-up guard for third-party apps.
 *
 * Supported browsers: checks the address bar and backs out of known blocked ad/redirect hosts.
 * Other apps: looks only for visible, clickable controls that clearly dismiss advertisements.
 * Generic labels such as "Close" or "Skip" are considered only when an ad/sponsored marker is
 * also visible in the same UI tree.
 *
 * Accessibility is an opt-in, powerful permission. Visible UI labels are inspected in memory
 * only; this service does not save or send UI text and never reads password fields intentionally.
 *
 * Some ads cannot be detected: image-only/Canvas/Surface ads, unlabeled close icons, and protected
 * system overlays may not expose accessible controls. This is best-effort, not a guarantee.
 */

class BrowserGuardService : AccessibilityService() {

    companion object {
        /** Keep in sync with android:packageNames in res/xml/browser_guard_config.xml. */
        val BROWSERS: Set<String> = setOf(
            "com.android.chrome", "com.chrome.beta", "com.chrome.dev", "com.chrome.canary",
            "com.sec.android.app.sbrowser", "com.sec.android.app.sbrowser.beta",
            "org.mozilla.firefox", "org.mozilla.firefox_beta", "org.mozilla.fenix",
            "com.brave.browser", "com.brave.browser_beta",
            "com.microsoft.emmx", "com.opera.browser", "com.opera.mini.native",
            "com.duckduckgo.mobile.android", "com.kiwibrowser.browser", "com.vivaldi.browser"
        )

        /** System, keyboard, launcher and own-app packages are never scanned. */
        private val IGNORED_PACKAGE_PREFIXES = listOf(
            "android", "com.android.systemui", "com.android.launcher",
            "com.google.android.inputmethod", "com.samsung.android.honeyboard",
            "com.adblocker.mobile"
        )

        /** Resource ids (without the package) of the address bar in those browsers. */
        private val URL_BAR_IDS = listOf(
            "url_bar", "url_field", "location_bar_edit_text",
            "mozac_browser_toolbar_url_view", "omnibarTextInput"
        )

        private const val CHECK_DELAY_MS = 500L
        private const val EDIT_GRACE_MS = 10_000L
        private const val SETTLE_MS = 1_500L
        private const val MAX_CLOSES = 3
        private const val LOOP_WINDOW_MS = 15_000L
        private const val PAUSE_MS = 30_000L

        /** True when the user has switched this service on in Android's Accessibility settings. */
        fun isEnabled(context: Context): Boolean {
            return try {
                val me = ComponentName(context, BrowserGuardService::class.java)
                val list = Settings.Secure.getString(
                    context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
                ) ?: return false
                list.split(':').any { ComponentName.unflattenFromString(it) == me }
            } catch (e: Exception) {
                false
            }
        }

        /** "https://www.Example.com/path?x" -> "example.com". Null for hints, titles and non-addresses. */
        fun hostOf(raw: String?): String? {
            var t = raw?.trim()?.lowercase() ?: return null
            if (t.isEmpty() || t.contains(' ')) return null
            t = t.removePrefix("https://").removePrefix("http://").removePrefix("www.")
            t = t.substringBefore('/').substringBefore('?').substringBefore('#').substringBefore(':').trim('.')
            return if (DomainUtil.validDomain(t)) t else null
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private var thread: HandlerThread? = null
    private var worker: Handler? = null
    private var database: AdBlockerDatabase? = null
    private val scheduled = AtomicBoolean(false)

    // Only touched on the worker thread.
    private var lastUrlFocus = 0L
    private var ignoreUntil = 0L
    private var pausedUntil = 0L
    private val closeTimes = ArrayDeque<Long>()

    override fun onServiceConnected() {
        super.onServiceConnected()
        AppPrefs.load(this)
        database = AdBlockerDatabase.get(this)
        val t = HandlerThread("BrowserGuard").also { it.start() }
        thread = t
        worker = Handler(t.looper)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val e = event ?: return
        val pkg = e.packageName?.toString() ?: return
        if (!AppPrefs.guardActive || shouldIgnorePackage(pkg)) return
        when (e.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED,
            AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED -> schedule(pkg)
        }
    }

    override fun onInterrupt() {}

    /** At most one check per [CHECK_DELAY_MS]: busy pages fire hundreds of content events. */
    private fun schedule(pkg: String) {
        val handler = worker ?: return
        if (!scheduled.compareAndSet(false, true)) return
        handler.postDelayed({
            scheduled.set(false)
            check(pkg)
        }, CHECK_DELAY_MS)
    }

    private fun check(pkg: String) {
        try {
            if (!AppPrefs.guardActive) return
            val now = System.currentTimeMillis()
            if (now < ignoreUntil || now < pausedUntil) return

            val root = rootInActiveWindow ?: return
            if (root.packageName?.toString() != pkg) return

            // App-independent check: only explicit ad-dismiss controls are eligible.
            if (dismissUniversalAdControl(root, now)) return

            // Browser redirect guard is an additional browser-only fallback.
            if (pkg !in BROWSERS) return
            val bar = findAddressBar(root, pkg) ?: return

            // The user is typing an address: never interfere with that.
            if (bar.isFocused) { lastUrlFocus = now; return }
            if (now - lastUrlFocus < EDIT_GRACE_MS) return

            val host = hostOf(bar.text?.toString()) ?: return
            val db = database ?: return
            val bad = db.isKnownBadHost(host, AppPrefs.autoLevel) &&
                AppPrefs.kindEnabled(EventKind.classify(host))
            if (bad) closePage(host, now)
        } catch (e: Exception) {
            // A browser update can change its views; skip this round.
        }
    }


    private fun shouldIgnorePackage(pkg: String): Boolean =
        IGNORED_PACKAGE_PREFIXES.any { prefix -> pkg == prefix || pkg.startsWith("$prefix.") }

    /**
     * Searches visible UI labels in any third-party app. It never clicks an arbitrary
     * "X" or generic "Close" unless an ad/sponsored marker is also visible.
     */
    private fun dismissUniversalAdControl(root: AccessibilityNodeInfo, now: Long): Boolean {
        val explicitAdLabels = listOf(
            "close ad", "close advertisement", "dismiss ad", "skip ad",
            "skip advertisement", "hide ad", "hide advertisement",
            "දැන්වීම වසන්න", "දැන්වීම මඟහරින්න"
        )
        val genericDismissLabels = setOf(
            "close", "dismiss", "skip", "not now", "no thanks", "×", "✕"
        )
        val adMarkers = listOf(
            "advertisement", "advertising", "sponsored", "sponsored content",
            "promoted", "promoted content", "ad choices", "about this ad",
            "why this ad", "paid promotion", "දැන්වීම", "දැන්වීම්",
            "ප්‍රචාරක දැන්වීම", "प्रायोजित", "publicité", "anuncio", "patrocinado"
        )
        val adCloseIdHints = listOf(
            "ad_close", "close_ad", "adclose", "closead", "skip_ad", "skipad",
            "dismiss_ad", "dismissad", "hide_ad", "hidead"
        )

        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        val visibleNodes = ArrayList<AccessibilityNodeInfo>(96)
        var visited = 0
        var hasAdMarker = false

        while (queue.isNotEmpty() && visited < 450) {
            val node = queue.removeFirst()
            visited++
            try {
                if (node.isVisibleToUser) {
                    visibleNodes.add(node)
                    // Never inspect password-entry nodes.
                    if (!node.isPassword) {
                        val text = node.text?.toString()?.trim()?.lowercase().orEmpty()
                        val desc = node.contentDescription?.toString()?.trim()?.lowercase().orEmpty()
                        if (adMarkers.any { text.contains(it) || desc.contains(it) }) hasAdMarker = true
                    }
                }
                for (i in 0 until node.childCount) node.getChild(i)?.let(queue::add)
            } catch (_: Exception) {
                // The window may change while traversing it.
            }
        }

        for (node in visibleNodes) {
            try {
                if (node.isPassword) continue
                val text = node.text?.toString()?.trim()?.lowercase().orEmpty()
                val desc = node.contentDescription?.toString()?.trim()?.lowercase().orEmpty()
                val viewId = node.viewIdResourceName?.lowercase().orEmpty()

                val explicitLabel = explicitAdLabels.any {
                    text == it || desc == it || text.contains(it) || desc.contains(it)
                }
                val adSpecificId = adCloseIdHints.any { viewId.contains(it) }
                val genericLabel = text in genericDismissLabels || desc in genericDismissLabels

                if (!explicitLabel && !adSpecificId && !(genericLabel && hasAdMarker)) continue

                var target: AccessibilityNodeInfo? = node
                var depth = 0
                while (target != null && depth < 5) {
                    if (target.isVisibleToUser && target.isClickable &&
                        target.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                        ignoreUntil = now + SETTLE_MS
                        closeTimes.clear()
                        AppPrefs.addGuardClosed(this)
                        toast(
                            if (AppPrefs.language == "si") "දැන්වීම් pop-up එකක් වසා දැමුවා"
                            else "Dismissed an ad pop-up"
                        )
                        return true
                    }
                    target = target.parent
                    depth++
                }
            } catch (_: Exception) {
                // Never fall back to tapping screen coordinates.
            }
        }
        return false
    }

    private fun findAddressBar(root: AccessibilityNodeInfo, pkg: String): AccessibilityNodeInfo? {
        for (id in URL_BAR_IDS) {
            val found = root.findAccessibilityNodeInfosByViewId("$pkg:id/$id")
            if (!found.isNullOrEmpty()) return found[0]
        }
        return null
    }

    private fun closePage(host: String, now: Long) {
        while (closeTimes.isNotEmpty() && now - closeTimes.first() > LOOP_WINDOW_MS) closeTimes.removeFirst()
        if (closeTimes.size >= MAX_CLOSES) {
            // Looks like a redirect loop: stop pressing Back for a while.
            closeTimes.clear()
            pausedUntil = now + PAUSE_MS
            toast(
                if (AppPrefs.language == "si") "පොප්-අප් ආරක්ෂකය තත්පර 30කට නතර කළා (නැවත නැවත redirect වෙනවා)"
                else "Pop-up guard paused for 30 s (page keeps redirecting)"
            )
            return
        }
        closeTimes.addLast(now)
        ignoreUntil = now + SETTLE_MS
        performGlobalAction(GLOBAL_ACTION_BACK)
        AppPrefs.addGuardClosed(this)
        // Shows up in History > Pop-ups (the DNS lookup of the same name is logged separately).
        database?.addBlockedEvent(host, EventKind.GUARD_CATEGORY)
        toast(
            if (AppPrefs.language == "si") "දැන්වීම් පිටුවක් වැසුවා: $host"
            else "Closed an ad page: $host"
        )
    }

    private fun toast(message: String) {
        main.post {
            try { Toast.makeText(applicationContext, message, Toast.LENGTH_SHORT).show() } catch (e: Exception) { }
        }
    }

    override fun onDestroy() {
        worker?.removeCallbacksAndMessages(null)
        thread?.quitSafely()
        thread = null
        worker = null
        super.onDestroy()
    }
}
