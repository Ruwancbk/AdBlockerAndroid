package com.adblocker.mobile

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.compose.runtime.mutableStateOf
import androidx.core.app.NotificationCompat
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

/**
 * DNS-only local VPN:
 * - Routes only the synthetic DNS server address (10.10.10.1) through the TUN interface.
 * - Answers NXDOMAIN for domains in the downloaded filter list (unless allowlisted).
 * - Forwards everything else to Cloudflare (1.1.1.1 / 1.0.0.1) over IPv4 UDP.
 *
 * Queries are handled on a small thread pool so one slow upstream lookup cannot stall
 * every other DNS request on the phone.
 */
class DnsVpnService : VpnService() {
    companion object {
        const val ACTION_START = "com.adblocker.mobile.START"
        const val ACTION_STOP = "com.adblocker.mobile.STOP"
        private const val CHANNEL = "adblocker_vpn"
        private const val NOTIFICATION_ID = 42
        private val UPSTREAM = arrayOf("1.1.1.1", "1.0.0.1")

        /**
         * Well-known public resolvers. Apps and games that hard-code one of these would skip our
         * DNS server, so these addresses are routed into the tunnel too: plain DNS sent to them is
         * filtered, and encrypted-DNS attempts are refused so the app falls back to normal DNS.
         */
        private val PUBLIC_RESOLVERS = arrayOf(
            "8.8.8.8", "8.8.4.4", "1.1.1.1", "1.0.0.1", "9.9.9.9", "149.112.112.112",
            "208.67.222.222", "208.67.220.220", "94.140.14.14", "94.140.15.15",
            "185.228.168.9", "185.228.169.9"
        )

        /** Observed by the UI so the power button always reflects the real VPN state. */
        val active = mutableStateOf(false)
    }

    private var tun: ParcelFileDescriptor? = null
    private val running = AtomicBoolean(false)
    private var database: AdBlockerDatabase? = null
    private var workers: ThreadPoolExecutor? = null
    private var flusher: ScheduledExecutorService? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopVpn()
            else -> startVpn()
        }
        return START_STICKY
    }

    private fun startVpn() {
        if (running.get()) return
        val db = AdBlockerDatabase.get(this)
        database = db
        createChannel()
        startForeground(NOTIFICATION_ID, notification())

        val descriptor = try {
            Builder()
                .setSession("Ad Blocker DNS")
                .setMtu(1500)
                .setBlocking(true)
                .addAddress("10.10.10.2", 32)
                .addDnsServer("10.10.10.1")
                .addRoute("10.10.10.1", 32)
                .also { builder ->
                    for (resolver in PUBLIC_RESOLVERS) {
                        try { builder.addRoute(resolver, 32) } catch (e: Exception) { }
                    }
                }
                .establish()
        } catch (e: Exception) {
            null
        }
        if (descriptor == null) {
            stopVpn()
            return
        }

        tun = descriptor
        val pool = ThreadPoolExecutor(
            8, 8, 30L, TimeUnit.SECONDS,
            ArrayBlockingQueue<Runnable>(256),
            ThreadPoolExecutor.DiscardPolicy()
        )
        workers = pool
        flusher = Executors.newSingleThreadScheduledExecutor().also { scheduler ->
            scheduler.scheduleWithFixedDelay({
                try { db.flushEvents() } catch (e: Exception) { }
            }, 3, 3, TimeUnit.SECONDS)
        }
        DnsActivity.reset()
        running.set(true)
        active.value = true
        thread(name = "AdBlockerDnsTun") { packetLoop(descriptor, pool, db) }
        refreshFilterListIfNeeded(db)
    }

    /**
     * An empty filter list blocks nothing, so download it right away when protection is turned
     * on for the first time (or when the list is more than a day old) instead of waiting for
     * the background job.
     */
    private fun refreshFilterListIfNeeded(db: AdBlockerDatabase) {
        val appContext = applicationContext
        thread(name = "AdBlockerFilterRefresh") {
            try {
                val updater = FilterListUpdater(appContext)
                updater.ensureBuiltIn()
                val last = db.lastUpdateMillis()
                val stale = System.currentTimeMillis() - last > TimeUnit.HOURS.toMillis(72)
                if (last == 0L || stale) updater.updateNow()
            } catch (e: Exception) {
                // The scheduled job will retry later.
            }
        }
    }

    private fun packetLoop(descriptor: ParcelFileDescriptor, pool: ThreadPoolExecutor, db: AdBlockerDatabase) {
        val input = FileInputStream(descriptor.fileDescriptor)
        val output = FileOutputStream(descriptor.fileDescriptor)
        val buffer = ByteArray(32767)
        while (running.get()) {
            try {
                val length = input.read(buffer)
                if (length < 0) break
                if (length == 0) continue
                val packet = buffer.copyOf(length)
                pool.execute { handlePacket(packet, output, db) }
            } catch (e: Exception) {
                if (!running.get()) break
                try { Thread.sleep(20) } catch (interrupted: InterruptedException) { break }
            }
        }
    }

    private fun handlePacket(packet: ByteArray, output: FileOutputStream, db: AdBlockerDatabase) {
        try {
            val parsed = parseDnsPacket(packet)
            if (parsed == null) {
                // Not plain DNS. Refuse TCP (DoT/DoH/DNS-over-TCP) quickly; drop everything else.
                PacketUtil.buildTcpReset(packet)?.let { reset -> synchronized(output) { output.write(reset) } }
                return
            }
            val query = parsed.dns
            val question = DnsName.readQuestion(query)
            val blocked = question != null && db.isDomainBlocked(question.name)
            if (question != null) DnsActivity.note(question.name, blocked)
            val response: ByteArray = if (question != null && blocked) {
                db.addBlockedEvent(question.name, "DNS")
                makeNxDomain(query, question.end)
            } else {
                val upstream = forwardDns(query) ?: return
                // CNAME cloaking: the name looks harmless but is an alias of a listed tracker.
                if (question != null && DnsResponse.cnameTargets(upstream).any { db.isDomainBlocked(it) }) {
                    DnsActivity.blocked.incrementAndGet()
                    db.addBlockedEvent(question.name, "CNAME")
                    makeNxDomain(query, question.end)
                } else {
                    upstream
                }
            }
            val reply = buildIpv4UdpReply(packet, parsed.ipHeaderLength, response)
            synchronized(output) { output.write(reply) }
        } catch (e: Exception) {
            // Drop this one query; the client will retry.
        }
    }

    private class Parsed(val ipHeaderLength: Int, val dns: ByteArray)

    private fun parseDnsPacket(packet: ByteArray): Parsed? {
        if (packet.size < 28) return null
        val version = (packet[0].toInt() ushr 4) and 0xF
        if (version != 4) return null
        val ihl = (packet[0].toInt() and 0xF) * 4
        if (ihl < 20 || packet.size < ihl + 8) return null
        if (packet[9].toInt() != 17) return null // UDP only
        val destPort = u16(packet, ihl + 2)
        if (destPort != 53) return null
        val udpLen = u16(packet, ihl + 4)
        if (udpLen < 8 + 12 || ihl + udpLen > packet.size) return null
        return Parsed(ihl, packet.copyOfRange(ihl + 8, ihl + udpLen))
    }

    private fun forwardDns(query: ByteArray): ByteArray? {
        for (server in UPSTREAM) {
            try {
                DatagramSocket().use { socket ->
                    protect(socket)
                    socket.soTimeout = 2000
                    val address = InetAddress.getByName(server)
                    socket.send(DatagramPacket(query, query.size, address, 53))
                    val data = ByteArray(4096)
                    val response = DatagramPacket(data, data.size)
                    socket.receive(response)
                    if (response.length >= 12 && data[0] == query[0] && data[1] == query[1]) {
                        return data.copyOf(response.length)
                    }
                }
            } catch (e: Exception) {
                // Try the next upstream server.
            }
        }
        return null
    }

    /** NXDOMAIN reply that contains only the header and the question (no EDNS leftovers). */
    private fun makeNxDomain(query: ByteArray, questionEnd: Int): ByteArray {
        val out = query.copyOf(questionEnd)
        // Keep opcode + RD from the query; set QR, RA and RCODE=3 (NXDOMAIN).
        val flags = (u16(out, 2) and 0x7900) or 0x8000 or 0x0080 or 0x0003
        put16(out, 2, flags)
        put16(out, 4, 1)
        put16(out, 6, 0)
        put16(out, 8, 0)
        put16(out, 10, 0)
        return out
    }

    private fun buildIpv4UdpReply(original: ByteArray, ihl: Int, dns: ByteArray): ByteArray {
        val udpLength = 8 + dns.size
        val totalLength = ihl + udpLength
        val out = ByteArray(totalLength)
        System.arraycopy(original, 0, out, 0, ihl)
        // Swap IPv4 source and destination.
        for (i in 0..3) {
            out[12 + i] = original[16 + i]
            out[16 + i] = original[12 + i]
        }
        put16(out, 2, totalLength)
        out[8] = 64.toByte()
        out[10] = 0; out[11] = 0
        put16(out, 10, checksum(out, 0, ihl))
        val udp = ihl
        put16(out, udp, 53)
        put16(out, udp + 2, u16(original, ihl))
        put16(out, udp + 4, udpLength)
        put16(out, udp + 6, 0)
        System.arraycopy(dns, 0, out, udp + 8, dns.size)
        return out
    }

    private fun checksum(data: ByteArray, offset: Int, length: Int): Int {
        var sum = 0L
        var i = offset
        while (i < offset + length) {
            val high = data[i].toInt() and 0xFF
            val low = if (i + 1 < offset + length) data[i + 1].toInt() and 0xFF else 0
            sum += (high shl 8) or low
            i += 2
        }
        while ((sum shr 16) != 0L) sum = (sum and 0xFFFF) + (sum shr 16)
        return sum.inv().toInt() and 0xFFFF
    }

    private fun u16(data: ByteArray, offset: Int): Int =
        ((data[offset].toInt() and 0xFF) shl 8) or (data[offset + 1].toInt() and 0xFF)

    private fun put16(data: ByteArray, offset: Int, value: Int) {
        data[offset] = (value shr 8).toByte()
        data[offset + 1] = value.toByte()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL, "Ad Blocker VPN", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun notification(): Notification =
        NotificationCompat.Builder(this, CHANNEL)
            .setContentTitle("Ad Blocker is active")
            .setContentText("Filtering known ad and tracker domains")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setOngoing(true)
            .build()

    private fun stopVpn() {
        running.set(false)
        active.value = false
        database?.let { db ->
            thread(name = "AdBlockerFlush") {
                try { db.flushEvents() } catch (e: Exception) { }
            }
        }
        flusher?.shutdownNow()
        flusher = null
        workers?.shutdownNow()
        workers = null
        try { tun?.close() } catch (e: Exception) { }
        tun = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    /** Called when the user revokes VPN permission or another VPN app takes over. */
    override fun onRevoke() {
        stopVpn()
        super.onRevoke()
    }

    override fun onDestroy() {
        stopVpn()
        super.onDestroy()
    }
}

private class Question(val name: String, val end: Int)

private object DnsName {
    /** Parses the single question of a standard query. Returns null if it can't be parsed safely. */
    fun readQuestion(message: ByteArray): Question? {
        if (message.size < 17) return null
        val flags = ((message[2].toInt() and 0xFF) shl 8) or (message[3].toInt() and 0xFF)
        if ((flags and 0x8000) != 0) return null // a response, not a query
        val questions = ((message[4].toInt() and 0xFF) shl 8) or (message[5].toInt() and 0xFF)
        if (questions != 1) return null

        val labels = ArrayList<String>()
        var pos = 12
        while (true) {
            if (pos >= message.size) return null
            val length = message[pos].toInt() and 0xFF
            if (length == 0) { pos += 1; break }
            // > 63 also rules out compression pointers, which never appear in a question.
            if (length > 63 || pos + 1 + length > message.size) return null
            labels.add(String(message, pos + 1, length, Charsets.US_ASCII))
            pos += length + 1
        }
        val end = pos + 4 // QTYPE + QCLASS
        if (end > message.size) return null
        val name = labels.joinToString(".").lowercase()
        return if (name.isBlank()) null else Question(name, end)
    }
}
