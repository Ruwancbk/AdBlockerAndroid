package com.adblocker.mobile

import java.util.concurrent.atomic.AtomicLong

/** Live counters so the app can show whether lookups really reach the blocker. */
object DnsActivity {
    val seen = AtomicLong(0)
    val blocked = AtomicLong(0)
    private val recentSeen = java.util.ArrayDeque<String>()
    private val recentBlocked = java.util.ArrayDeque<String>()

    fun note(name: String, wasBlocked: Boolean) {
        seen.incrementAndGet()
        remember(recentSeen, name)
        if (wasBlocked) {
            blocked.incrementAndGet()
            remember(recentBlocked, name)
        }
    }

    fun reset() {
        seen.set(0)
        blocked.set(0)
        synchronized(recentSeen) { recentSeen.clear() }
        synchronized(recentBlocked) { recentBlocked.clear() }
    }

    fun wasSeen(name: String): Boolean = synchronized(recentSeen) { recentSeen.contains(name) }
    fun wasBlocked(name: String): Boolean = synchronized(recentBlocked) { recentBlocked.contains(name) }

    private fun remember(queue: java.util.ArrayDeque<String>, name: String) {
        synchronized(queue) {
            queue.addLast(name)
            while (queue.size > 128) queue.removeFirst()
        }
    }
}

object PacketUtil {
    fun u16(data: ByteArray, offset: Int): Int =
        ((data[offset].toInt() and 0xFF) shl 8) or (data[offset + 1].toInt() and 0xFF)

    fun u32(data: ByteArray, offset: Int): Long =
        (u16(data, offset).toLong() shl 16) or u16(data, offset + 2).toLong()

    fun put16(data: ByteArray, offset: Int, value: Int) {
        data[offset] = (value shr 8).toByte()
        data[offset + 1] = value.toByte()
    }

    fun put32(data: ByteArray, offset: Int, value: Long) {
        put16(data, offset, ((value shr 16) and 0xFFFF).toInt())
        put16(data, offset + 2, (value and 0xFFFF).toInt())
    }

    fun checksum(data: ByteArray, offset: Int, length: Int): Int {
        var sum = 0L
        var i = offset
        while (i < offset + length) {
            val high = data[i].toInt() and 0xFF
            val low = if (i + 1 < offset + length) data[i + 1].toInt() and 0xFF else 0
            sum += (high shl 8) or low
            i += 2
        }
        while ((sum shr 16) != 0L) sum = (sum and 0xFFFF) + (sum shr 16)
        return sum.inv().toInt() and 0xFFFF
    }

    /**
     * Answers an IPv4 TCP packet with a reset. Encrypted-DNS clients (DNS-over-TLS/HTTPS to a
     * public resolver, Private DNS probes) then fail immediately and fall back to the normal
     * DNS path that the blocker filters, instead of hanging until a timeout.
     */
    fun buildTcpReset(p: ByteArray): ByteArray? {
        if (p.size < 40) return null
        if (((p[0].toInt() ushr 4) and 0xF) != 4) return null
        val ihl = (p[0].toInt() and 0xF) * 4
        if (ihl < 20 || p.size < ihl + 20) return null
        if (p[9].toInt() != 6) return null
        val flags = p[ihl + 13].toInt() and 0xFF
        if ((flags and 0x04) != 0) return null // never answer a reset with a reset

        val seq = u32(p, ihl + 4)
        val ack = u32(p, ihl + 8)
        val dataOffset = ((p[ihl + 12].toInt() and 0xFF) ushr 4) * 4
        val totalLength = minOf(u16(p, 2), p.size)
        val payload = maxOf(0, totalLength - ihl - dataOffset)

        val out = ByteArray(40)
        out[0] = 0x45
        out[8] = 64
        out[9] = 6
        for (i in 0..3) {
            out[12 + i] = p[16 + i]
            out[16 + i] = p[12 + i]
        }
        put16(out, 2, 40)
        put16(out, 10, checksum(out, 0, 20))

        put16(out, 20, u16(p, ihl + 2))
        put16(out, 22, u16(p, ihl))
        out[32] = 0x50
        if ((flags and 0x10) != 0) {
            put32(out, 24, ack)
            out[33] = 0x04 // RST
        } else {
            var next = seq + payload
            if ((flags and 0x02) != 0) next += 1 // SYN
            if ((flags and 0x01) != 0) next += 1 // FIN
            put32(out, 28, next and 0xFFFFFFFFL)
            out[33] = 0x14 // RST + ACK
        }

        val pseudo = ByteArray(32)
        System.arraycopy(out, 12, pseudo, 0, 8)
        pseudo[9] = 6
        put16(pseudo, 10, 20)
        System.arraycopy(out, 20, pseudo, 12, 20)
        put16(out, 36, checksum(pseudo, 0, 32))
        return out
    }
}
