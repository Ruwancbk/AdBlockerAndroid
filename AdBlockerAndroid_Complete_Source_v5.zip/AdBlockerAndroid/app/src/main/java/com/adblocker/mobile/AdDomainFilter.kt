package com.adblocker.mobile

/**
 * Small emergency starter list used before the online filter list is downloaded.
 * The maintained hosts list is stored in SQLite and checked separately.
 */
object AdDomainFilter {
    private val blockedDomains = setOf(
        "doubleclick.net",
        "googlesyndication.com",
        "googleadservices.com",
        "adservice.google.com",
        "adnxs.com",
        "taboola.com",
        "outbrain.com",
        "criteo.com",
        "scorecardresearch.com"
    )

    fun isBlocked(host: String): Boolean {
        val normalized = host.trim('.').lowercase()
        return blockedDomains.any { normalized == it || normalized.endsWith(".$it") }
    }
}
