package com.adblocker.mobile

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.TimeUnit

class FilterListUpdater(private val context: Context) {
    companion object {
        const val FILTER_URL = "https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts"
        const val SOURCE_ID = "stevenblack_hosts"
        private const val MAX_BYTES = 15 * 1024 * 1024
    }

    /** Runs the download on a background thread and reports on the main thread. */
    fun update(onComplete: (kotlin.Result<Int>) -> Unit) {
        Thread {
            val result = downloadAndSave()
            Handler(Looper.getMainLooper()).post { onComplete(result) }
        }.start()
    }

    /** Daily refresh, plus a one-time first download when no list exists yet. */
    fun scheduleDailyUpdates() {
        val constraints = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
        val periodic = PeriodicWorkRequestBuilder<FilterUpdateWorker>(24, TimeUnit.HOURS)
            .setConstraints(constraints)
            .build()
        val manager = WorkManager.getInstance(context)
        manager.enqueueUniquePeriodicWork(
            "adblocker_filter_update", ExistingPeriodicWorkPolicy.KEEP, periodic
        )
        Thread {
            try {
                if (AdBlockerDatabase.get(context).lastUpdateMillis() == 0L) {
                    val once = OneTimeWorkRequestBuilder<FilterUpdateWorker>()
                        .setConstraints(constraints)
                        .build()
                    manager.enqueueUniqueWork("adblocker_filter_initial", ExistingWorkPolicy.KEEP, once)
                }
            } catch (ignored: Exception) {
            }
        }.start()
    }

    fun updateNow(): kotlin.Result<Int> = downloadAndSave()

    private fun downloadAndSave(): kotlin.Result<Int> = runCatching {
        val connection = (URL(FILTER_URL).openConnection() as HttpURLConnection).apply {
            connectTimeout = 12_000
            readTimeout = 20_000
            requestMethod = "GET"
            setRequestProperty("User-Agent", "AdBlockerAndroid/1.0")
        }
        val body = try {
            if (connection.responseCode !in 200..299) error("Filter server error: ${connection.responseCode}")
            connection.inputStream.use { input ->
                val out = java.io.ByteArrayOutputStream()
                val buffer = ByteArray(8192)
                var total = 0
                while (true) {
                    val n = input.read(buffer)
                    if (n < 0) break
                    total += n
                    require(total <= MAX_BYTES) { "Filter file exceeds size limit" }
                    out.write(buffer, 0, n)
                }
                out.toString("UTF-8")
            }
        } finally { connection.disconnect() }

        val domains = parseHosts(body)
        require(domains.size >= 100) { "Filter list validation failed" }
        AdBlockerDatabase.get(context).replaceRemoteDomains(domains, SOURCE_ID)
        domains.size
    }

    private fun parseHosts(text: String): Set<String> {
        val result = LinkedHashSet<String>()
        val sinks = setOf("0.0.0.0", "127.0.0.1", "::", "::1")
        text.lineSequence().forEach { raw ->
            val line = raw.substringBefore('#').trim()
            if (line.isEmpty()) return@forEach
            val fields = line.split(Regex("\\s+"))
            if (fields.size < 2) return@forEach
            if (fields[0] !in sinks) return@forEach
            fields.drop(1).forEach { rawHost ->
                val host = AdBlockerDatabase.normalizeHost(rawHost)
                if (AdBlockerDatabase.validDomain(host) && host != "localhost") result.add(host)
            }
        }
        return result
    }
}

class FilterUpdateWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        val update = FilterListUpdater(applicationContext).updateNow()
        return if (update.isSuccess) Result.success()
        else if (runAttemptCount < 3) Result.retry() else Result.failure()
    }
}
