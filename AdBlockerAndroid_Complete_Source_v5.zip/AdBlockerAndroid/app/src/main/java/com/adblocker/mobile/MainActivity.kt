package com.adblocker.mobile

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.webkit.*
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import java.text.DateFormat
import java.util.Date
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Purple = Color(0xFF6514D5)
private val Pale = Color(0xFFF5F0FF)
private val Ink = Color(0xFF171331)
private val Green = Color(0xFF16B84A)

class MainActivity : ComponentActivity() {

    private val vpnPermission = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) startVpn()
    }

    // The notification permission is optional: the VPN works either way, but without it
    // Android 13+ hides the "Ad Blocker is active" notification.
    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { requestVpnPermission() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FilterListUpdater(this).scheduleDailyUpdates()
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(
                primary = Purple, secondary = Color(0xFF8C42F5),
                background = Pale, surface = Color.White
            )) {
                AdBlockerApp(
                    onEnableVpn = { enableVpn() },
                    onDisableVpn = {
                        startService(Intent(this, DnsVpnService::class.java).setAction(DnsVpnService.ACTION_STOP))
                    }
                )
            }
        }
    }

    private fun enableVpn() {
        val needsNotificationPermission = Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        if (needsNotificationPermission) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            requestVpnPermission()
        }
    }

    private fun requestVpnPermission() {
        val intent = VpnService.prepare(this)
        if (intent == null) startVpn() else vpnPermission.launch(intent)
    }

    private fun startVpn() {
        ContextCompat.startForegroundService(
            this, Intent(this, DnsVpnService::class.java).setAction(DnsVpnService.ACTION_START)
        )
    }
}

private enum class Screen(val label: String) {
    HOME("Home"), BROWSER("Browser"), STATS("Stats"), HISTORY("History"),
    TOOLS("Tools"), SETTINGS("Settings"), WHITELIST("Whitelist"), PREMIUM("Premium")
}

private data class Stats(
    val events: Long = 0L,
    val filters: Int = 0,
    val allowed: Int = 0,
    val source: String = "Not configured",
    val lastUpdate: Long = 0L
)

private fun formatTime(millis: Long): String = DateFormat.getDateTimeInstance().format(Date(millis))

private fun toBrowserUrl(input: String): String {
    val value = input.trim()
    return when {
        value.startsWith("http://") || value.startsWith("https://") -> value
        value.contains('.') && !value.contains(' ') -> "https://$value"
        else -> "https://www.google.com/search?q=${java.net.URLEncoder.encode(value, "UTF-8")}"
    }
}

@Composable
private fun AdBlockerApp(onEnableVpn: () -> Unit, onDisableVpn: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val db = remember { AdBlockerDatabase.get(context) }
    val prefs = remember { context.getSharedPreferences("settings", Context.MODE_PRIVATE) }
    val updater = remember { FilterListUpdater(context) }

    var screen by remember { mutableStateOf(Screen.HOME) }
    val vpnOn by DnsVpnService.active
    var jsEnabled by remember { mutableStateOf(prefs.getBoolean("js", false)) }
    var browserBlock by remember { mutableStateOf(prefs.getBoolean("browser_block", true)) }
    var urlInput by remember { mutableStateOf("https://example.com") }
    var browserUrl by remember { mutableStateOf("https://example.com") }
    var allowInput by remember { mutableStateOf("") }
    var statusOverride by remember { mutableStateOf<String?>(null) }
    var updating by remember { mutableStateOf(false) }
    var refresh by remember { mutableIntStateOf(0) }

    // All database reads happen off the main thread.
    val stats by produceState(Stats(), refresh) {
        value = withContext(Dispatchers.IO) {
            db.flushEvents()
            Stats(db.eventCount(), db.filterCount(), db.allowedDomains().size,
                db.filterSource(), db.lastUpdateMillis())
        }
    }
    val events by produceState(emptyList<BlockedEvent>(), refresh) {
        value = withContext(Dispatchers.IO) { db.flushEvents(); db.recentEvents(200) }
    }
    val allowed by produceState(emptyList<String>(), refresh) {
        value = withContext(Dispatchers.IO) { db.allowedDomains() }
    }

    // While protection is on, refresh the counters every few seconds.
    LaunchedEffect(vpnOn) {
        while (vpnOn) {
            delay(3000)
            refresh++
        }
    }

    val filterStatus = statusOverride
        ?: if (stats.lastUpdate > 0L) "${stats.filters} domains • updated ${formatTime(stats.lastUpdate)}"
        else "No filter list downloaded yet"

    Scaffold(
        containerColor = Pale,
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                listOf(Screen.HOME, Screen.BROWSER, Screen.STATS, Screen.TOOLS, Screen.SETTINGS).forEach { item ->
                    NavigationBarItem(
                        selected = screen == item,
                        onClick = { screen = item; refresh++ },
                        icon = {
                            Icon(when (item) {
                                Screen.HOME -> Icons.Default.Home
                                Screen.BROWSER -> Icons.Default.Language
                                Screen.STATS -> Icons.Default.BarChart
                                Screen.TOOLS -> Icons.Default.Build
                                else -> Icons.Default.Settings
                            }, contentDescription = item.label)
                        },
                        label = { Text(item.label) }
                    )
                }
            }
        }
    ) { padding ->
        when (screen) {
            Screen.HOME -> LazyColumn(
                Modifier.fillMaxSize().padding(padding).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item { AppHeader(onPro = { screen = Screen.PREMIUM }) }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(28.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Button(
                                // The button state follows the real service state, so denying the
                                // VPN permission dialog leaves it OFF.
                                onClick = { if (vpnOn) onDisableVpn() else onEnableVpn() },
                                modifier = Modifier.size(142.dp),
                                shape = RoundedCornerShape(100.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = if (vpnOn) Green else Purple)
                            ) { Icon(Icons.Default.PowerSettingsNew, null, modifier = Modifier.size(64.dp)) }
                            Spacer(Modifier.height(12.dp))
                            Text(if (vpnOn) "Ad Blocking is ON" else "Ad Blocking is OFF", fontSize = 23.sp, color = Ink)
                            Text(if (vpnOn) "DNS protection enabled" else "Tap to enable system-wide protection", color = Color.Gray)
                        }
                    }
                }
                if (stats.filters == 0) {
                    item {
                        MenuRow("Filter list not downloaded yet", "Tap to open Settings and update it") { screen = Screen.SETTINGS }
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Metric("Blocked", stats.events.toString(), Modifier.weight(1f))
                        Metric("Filter domains", stats.filters.toString(), Modifier.weight(1f))
                        Metric("Whitelist", stats.allowed.toString(), Modifier.weight(1f))
                    }
                }
                item { MenuRow("Blocked Items History", "Review recently blocked domains") { screen = Screen.HISTORY } }
                item { MenuRow("Allowed Websites", "Choose sites that should never be blocked") { screen = Screen.WHITELIST } }
                item { MenuRow("Usage Statistics", "See your protection activity") { screen = Screen.STATS } }
                item { MenuRow("Ad Blocker Pro", "Explore premium features") { screen = Screen.PREMIUM } }
                item { Text("DNS filtering cannot remove every ad. Ads served from the same domain as content may still appear.", color = Color.Gray, fontSize = 12.sp) }
            }

            Screen.BROWSER -> Column(Modifier.fillMaxSize().padding(padding).padding(12.dp)) {
                AppHeader(onPro = { screen = Screen.PREMIUM })
                OutlinedTextField(
                    value = urlInput, onValueChange = { urlInput = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Search or enter website URL") },
                    trailingIcon = {
                        IconButton(onClick = { browserUrl = toBrowserUrl(urlInput) }) {
                            Icon(Icons.Default.Search, contentDescription = "Go")
                        }
                    },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = { browserUrl = toBrowserUrl(urlInput) }),
                    singleLine = true
                )
                Spacer(Modifier.height(8.dp))
                BrowserPane(browserUrl, db, jsEnabled, browserBlock, modifier = Modifier.weight(1f))
            }

            Screen.STATS -> LazyColumn(Modifier.fillMaxSize().padding(padding).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item { AppHeader(onPro = { screen = Screen.PREMIUM }) }
                item { Text("Usage Statistics", fontSize = 28.sp, color = Ink) }
                item { Metric("Blocked events", stats.events.toString(), Modifier.fillMaxWidth()) }
                item { Metric("Domains in filter list", stats.filters.toString(), Modifier.fillMaxWidth()) }
                item { Metric("Allowed websites", stats.allowed.toString(), Modifier.fillMaxWidth()) }
                item { MenuRow("Filter list source", stats.source) {} }
                item { MenuRow("Last filter update", if (stats.lastUpdate > 0L) formatTime(stats.lastUpdate) else "Never") {} }
                item { Text("Data and time-saved estimates are not reported until measured reliably; this build does not invent those values.", color = Color.Gray, fontSize = 12.sp) }
            }

            Screen.HISTORY -> Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Blocked Items History", fontSize = 23.sp, color = Ink, modifier = Modifier.weight(1f))
                    TextButton(onClick = {
                        scope.launch {
                            withContext(Dispatchers.IO) { db.clearHistory() }
                            refresh++
                        }
                    }) { Text("Clear") }
                }
                Text("Showing the latest 200 blocked requests.", color = Color.Gray, fontSize = 12.sp)
                if (events.isEmpty()) Text("No blocked events recorded yet.", color = Color.Gray)
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(events) { event ->
                        MenuRow(event.domain, "${event.category} • ${formatTime(event.timestamp)}") {}
                    }
                }
            }

            Screen.WHITELIST -> Column(Modifier.fillMaxSize().padding(padding).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Allowed Websites", fontSize = 26.sp, color = Ink)
                Text("Domains added here (and their subdomains) are never blocked.", color = Color.Gray)
                OutlinedTextField(
                    value = allowInput, onValueChange = { allowInput = it },
                    modifier = Modifier.fillMaxWidth(), label = { Text("example.com") },
                    singleLine = true
                )
                Button(onClick = {
                    val domain = AdBlockerDatabase.normalizeHost(allowInput)
                    if (AdBlockerDatabase.validDomain(domain)) {
                        scope.launch {
                            withContext(Dispatchers.IO) { db.addAllowedDomain(domain) }
                            allowInput = ""
                            refresh++
                        }
                    } else {
                        android.widget.Toast.makeText(context, "Enter a valid domain such as example.com", android.widget.Toast.LENGTH_LONG).show()
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text("Add to Allowlist") }
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(allowed) { domain ->
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(domain, modifier = Modifier.weight(1f), color = Ink)
                                TextButton(onClick = {
                                    scope.launch {
                                        withContext(Dispatchers.IO) { db.removeAllowedDomain(domain) }
                                        refresh++
                                    }
                                }) { Text("Remove") }
                            }
                        }
                    }
                }
            }

            Screen.TOOLS -> LazyColumn(Modifier.fillMaxSize().padding(padding).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item { AppHeader(onPro = { screen = Screen.PREMIUM }) }
                item { Text("Tools", fontSize = 28.sp, color = Ink) }
                item { MenuRow("Privacy Check", "Review tracker filtering status") { screen = Screen.SETTINGS } }
                item { MenuRow("Filter List Manager", "Update and inspect domain filters") { screen = Screen.SETTINGS } }
                item { MenuRow("Download Manager", "Downloads are managed by Android WebView") {} }
                item { MenuRow("Speed Test", "Not included in this build") {} }
            }

            Screen.SETTINGS -> Column(
                Modifier.fillMaxSize().padding(padding).padding(16.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                AppHeader(onPro = { screen = Screen.PREMIUM })
                Text("Settings", fontSize = 28.sp, color = Ink)
                ToggleRow("Block ads & trackers in browser", browserBlock) {
                    browserBlock = it
                    prefs.edit().putBoolean("browser_block", it).apply()
                }
                ToggleRow("Enable JavaScript in browser", jsEnabled) {
                    jsEnabled = it
                    prefs.edit().putBoolean("js", it).apply()
                }
                Text("JavaScript is off by default for safer browsing. Many sites need it to display correctly.", color = Color.Gray, fontSize = 12.sp)
                MenuRow("Allowed Websites", "Manage exceptions") { screen = Screen.WHITELIST }
                MenuRow("Filter list", filterStatus) {}
                Button(
                    onClick = {
                        updating = true
                        statusOverride = "Downloading and validating filter list…"
                        updater.update { result ->
                            updating = false
                            statusOverride = result.fold(
                                { count -> "$count domains • updated ${formatTime(System.currentTimeMillis())}" },
                                { error -> "Update failed: ${error.message ?: "unknown error"}" }
                            )
                            refresh++
                        }
                    },
                    enabled = !updating,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (updating) CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                    else Icon(Icons.Default.Refresh, null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (updating) "Updating…" else "Update Filter List Now")
                }
                Text("Automatic updates are scheduled approximately every 24 hours when a network is available.", color = Color.Gray, fontSize = 12.sp)
                MenuRow("About Ad Blocker", "Version 1.0.1 • DNS filtering prototype") {}
            }

            Screen.PREMIUM -> Column(
                Modifier.fillMaxSize().padding(padding).padding(18.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp), horizontalAlignment = Alignment.CenterHorizontally
            ) {
                AppHeader(onPro = { screen = Screen.PREMIUM })
                Text("Ad Blocker Pro", fontSize = 30.sp, color = Purple)
                Text("More privacy. Cleaner browsing.", color = Ink)
                listOf("Advanced filter lists", "Custom allowlist controls", "Priority filter updates", "Premium support").forEach {
                    MenuRow(it, "Premium feature preview") {}
                }
                Text("Subscription and payment processing are not connected in this source build.", color = Color.Gray, fontSize = 12.sp)
                Button(onClick = { screen = Screen.HOME }) { Text("Back to Home") }
            }
        }
    }
}

@Composable
private fun AppHeader(onPro: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Surface(color = Purple, shape = RoundedCornerShape(12.dp)) {
            Text("AD", color = Color.White, modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp))
        }
        Spacer(Modifier.width(10.dp))
        Text("Ad Blocker", fontSize = 23.sp, color = Ink, modifier = Modifier.weight(1f))
        TextButton(onClick = onPro) { Text("👑 PRO", color = Purple) }
    }
}

@Composable
private fun Metric(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, color = Purple, fontSize = 21.sp)
            Text(title, color = Ink, fontSize = 11.sp)
        }
    }
}

@Composable
private fun MenuRow(title: String, subtitle: String, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = Ink, fontSize = 16.sp)
                Text(subtitle, color = Color.Gray, fontSize = 12.sp)
            }
            Icon(Icons.Default.ChevronRight, null, tint = Purple)
        }
    }
}

@Composable
private fun ToggleRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = Ink, modifier = Modifier.weight(1f))
            Switch(checked = checked, onCheckedChange = onChange)
        }
    }
}

@Composable
private fun BrowserPane(
    url: String,
    db: AdBlockerDatabase,
    javaScript: Boolean,
    blockAds: Boolean,
    modifier: Modifier = Modifier
) {
    val blockState = rememberUpdatedState(blockAds)
    // Remembers what was last loaded so recompositions never reload the page.
    val lastLoaded = remember { arrayOfNulls<String>(1) }
    AndroidView(
        modifier = modifier.fillMaxWidth(),
        factory = { context ->
            WebView(context).apply {
                settings.javaScriptEnabled = javaScript
                settings.domStorageEnabled = false
                settings.javaScriptCanOpenWindowsAutomatically = false
                webViewClient = object : WebViewClient() {
                    override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                        if (!blockState.value) return null
                        val host = request?.url?.host?.lowercase() ?: return null
                        if (db.isDomainBlocked(host)) {
                            db.addBlockedEvent(host, "Browser")
                            return WebResourceResponse(
                                "text/plain", "utf-8", java.io.ByteArrayInputStream(ByteArray(0))
                            )
                        }
                        return null
                    }
                }
            }
        },
        update = { web ->
            web.settings.javaScriptEnabled = javaScript
            val target = url.trim()
            if (target.isNotBlank() && lastLoaded[0] != target) {
                lastLoaded[0] = target
                web.loadUrl(target)
            }
        }
    )
}
