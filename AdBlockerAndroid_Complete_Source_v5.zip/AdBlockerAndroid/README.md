# Ad Blocker Android (v5)

Android Studio project (Kotlin, Jetpack Compose, package `com.adblocker.mobile`):
Home, Browser, Stats, History, Tools, Settings, Allowlist and a Premium preview screen.

## How it works
- `DnsVpnService` is a DNS-only local VPN. Only the synthetic resolver `10.10.10.1` is routed
  through the TUN interface. Domains in the downloaded filter list get an NXDOMAIN answer;
  everything else is forwarded to Cloudflare (`1.1.1.1`, then `1.0.0.1`) over IPv4 UDP.
- The filter list is the StevenBlack hosts list, downloaded over HTTPS (size-limited and
  validated) and stored in SQLite. The first download starts automatically on first launch;
  after that it refreshes about every 24 hours (WorkManager) or manually from Settings.
- The built-in browser (WebView) filters requests with the same list. JavaScript is off by
  default and can be enabled in Settings.

## Build
- Android Studio: open the folder, use JDK 17 and SDK Platform 35, sync, then
  Build > Build APK(s).
- GitHub: push to GitHub, open Actions > **Build Ad Blocker APK** > Run workflow, then download
  the `AdBlocker-debug-apk` artifact. The workflow installs Gradle 8.10.2 itself, so no Gradle
  wrapper is needed. The APK is debug-signed (for testing; Play Store needs a release key).

## Changes in v5
- Fixed compile errors: missing `AdDomainFilter` and the nested `Result` type in the updater.
- Fixed CI: Gradle version is pinned (AGP 8.7.3 needs Gradle 8.9+).
- DNS queries are handled on a thread pool; one slow lookup no longer stalls the phone.
- Single shared database in WAL mode; filter import uses a prepared statement; blocked events
  are queued and written in batches, history is capped at the latest 1000 events.
- NXDOMAIN replies no longer carry leftover EDNS bytes.
- `onRevoke()` handled; the power button reflects the real VPN state; notification permission
  requested on Android 13+.
- Browser: no longer reloads on every keystroke or refresh; JavaScript and browser blocking are
  real, saved settings. The non-functional toggles were removed.
- Blocklist matching is exact (hosts-file semantics); allowlist entries also cover subdomains.
- Database reads for the UI run off the main thread.

## Known limits
- IPv4 UDP DNS only. Private DNS, DNS-over-HTTPS/TLS, DNS over TCP, IPv6, hard-coded IPs and
  apps with their own encrypted resolver bypass the filter.
- DNS blocking cannot separate ads served from the same domain as content (many video ads).
- Community lists can block legitimate sites; use Allowed Websites to add exceptions.
- Premium is a UI preview, billing is not connected. Speed test is a placeholder.
- Not yet tested on real devices. Before any Play Store release: test on several Android
  versions, add DNS protocol tests, and review Google Play VPN and foreground-service policies.

## Privacy
Allowed DNS queries go to Cloudflare. Blocked domains are stored locally for the History screen.
No analytics and no account.
