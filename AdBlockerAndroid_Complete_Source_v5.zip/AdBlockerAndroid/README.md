# Ad Blocker Android — starter project

Android Studio project for a purple/white ad blocker prototype with:
- Compose dashboard, browser, statistics and settings screens
- Android `VpnService` with a DNS-only TUN route
- Built-in WebView request filtering
- GitHub Actions workflow to build a debug APK

## Build
1. Open this folder in Android Studio (Giraffe or newer).
2. Install Android SDK Platform 35 and JDK 17.
3. Allow Gradle sync.
4. Run on a physical Android device.
5. On Home, tap the power button and approve Android's VPN permission dialog.

Or push the project to GitHub. The included workflow builds `app-debug.apk` on every push.

## Important technical limits
- The VPN implementation routes only the synthetic DNS resolver `10.10.10.1` through the TUN interface. It filters IPv4 UDP DNS queries; it is not a full traffic-inspection VPN.
- Android Private DNS, DNS-over-HTTPS, hard-coded IP connections, IPv6 DNS, and apps using their own encrypted resolvers can bypass this starter filter.
- The bundled domain list is a small demonstration list, not a maintained production filter list.
- Ads served from the same first-party domains as app content (including many video ads) cannot reliably be separated by DNS blocking.
- Browser request interception is a starter implementation. JavaScript is disabled by default for safer browsing; some sites may not work until the user enables it deliberately.
- Statistics shown in this starter are session/demo counters, not a complete device-wide measurement.
- Before public release, add robust DNS parsing, IPv6 support, filter-list updates, DNS cache, exception handling, privacy disclosures, tests, battery/network testing, and Play policy review.

## Package
`com.adblocker.mobile`

## Privacy
DNS queries for allowed domains are forwarded to Cloudflare DNS (`1.1.1.1`). No app analytics or user account is included.


## Added in source update
- SQLite database for downloaded blocked domains, update metadata, and blocked DNS events.
- HTTPS downloader for the StevenBlack hosts list with size limits and basic validation.
- Settings action to manually update the filter list.
- DNS VPN checks the persisted filter database and records blocked DNS domains.

The filter list is a third-party community list. Its contents can block legitimate domains;
users need a way to disable protection or allowlist sites before a public release. Automatic
background updates, allowlisting UI, list signatures, IPv6 handling, and comprehensive tests
are not included yet.


## Full app source package (v3)
Includes Home, Browser, Stats, History, Tools, Settings, Premium preview, and Allowlist screens.
The app persists allowlisted domains and blocked events in SQLite, downloads a community hosts
filter over HTTPS, and schedules periodic updates with WorkManager.

Build with Android Studio and JDK 17. Install Android SDK Platform 35. Open the project folder,
sync Gradle, then Build > Build Bundle(s) / APK(s) > Build APK(s).

## Limitations before release
This is a complete source project for a functional prototype, not a certified production VPN.
The DNS tunnel currently handles IPv4 UDP DNS only. Private DNS/DoH, hard-coded IPs, IPv6,
QUIC and app-specific encrypted DNS can bypass it. DNS blocking cannot reliably distinguish
ads served from the same host as content. Browser JavaScript is disabled by default, so some
sites will not render correctly. Premium is a UI preview; billing is not connected. Tools such
as speed test are placeholders. Test packet handling on multiple physical Android versions,
add DNS protocol tests and a robust resolver, and review Google Play VPN and foreground-service
policies before publishing.


## Build APK from GitHub
Push this project to a GitHub repository, open Actions, choose **Build Ad Blocker APK**,
and select **Run workflow**. When the run succeeds, open its Artifacts section and download
`AdBlocker-debug-apk`. This is a debug-signed APK for device testing. A Play Store release
requires a private signing key and a separately configured release signing process.


## V5 compile fixes
- Added the missing `AdDomainFilter` implementation used by the DNS VPN service.
- Qualified the filter downloader callback as `kotlin.Result<Int>` to avoid a naming collision
  with WorkManager's `ListenableWorker.Result`.
