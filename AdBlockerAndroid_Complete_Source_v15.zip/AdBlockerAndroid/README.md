# Ad Blocker Android (v11 - purple redesign, versionName 2.3.0)

Android Studio project (Kotlin, Jetpack Compose, package `com.adblocker.mobile`):
Home, Browser, Stats, History, Tools, Settings, Allowlist and a Premium preview screen.

## Changes in v11 (versionName 2.3.0): new purple UI
- New look matching the design mockups: onboarding (language picker + Get Started), Home with the
  glowing power button, Usage Statistics (Today / 7 Days / 30 Days / All Time, 7-day bar chart,
  trend cards), Blocked Items History (All / Ads / Pop-ups / Trackers / Others, grouped by day),
  Settings (Ad Blocking, Browsing & Performance, Privacy & Security, General) and a floating pill
  bottom bar (Home, Browser, Stats, Premium). English and Sinhala (Settings > General > Language).
- New switches that really change behaviour: Block Ads / Pop-ups / Trackers / Annoying Elements
  (a name is sorted into one of these groups by `EventKind`; a switched-off group is let through),
  Faster Browsing (page cache), Enhanced Privacy (no third-party cookies in the browser), Clear
  Browsing Data, Default Search Engine, App Theme (Purple, Blue, Teal, Pink), Notifications.
- Everything from v10 (automatic blocking level, AdGuard upstream, DNS Log, filter updates, test) now
  lives under Settings > Advanced and Privacy Protection.
- Data saved / time saved are estimates (average 42 KB and 0.87 s per blocked request).
- Event history keeps up to 20,000 entries so the 30-day and All Time views have data.

## How it works
- `DnsVpnService` is a DNS-only local VPN. Only the synthetic resolver `10.10.10.1` is routed
  through the TUN interface. Domains in the downloaded filter list get an NXDOMAIN answer;
  everything else is forwarded over IPv4 UDP to AdGuard DNS (`94.140.14.14`, which refuses ad
  names too), then Cloudflare (`1.1.1.1`, `1.0.0.1`) as backup.
- The filter lists are StevenBlack hosts and the AdGuard DNS filter (about 200,000 domains
  together), downloaded over HTTPS (size-limited and validated) and stored in SQLite. A listed
  domain also blocks all its subdomains. The download starts as soon as Ad Blocking is turned
  ON with no list present; after that it refreshes about every 24 hours (WorkManager) or
  manually from Settings.
- The built-in browser (WebView) filters requests with the same list. JavaScript is off by
  default and can be enabled in Settings.

## Build
- Android Studio: open the folder, use JDK 17 and SDK Platform 35, sync, then
  Build > Build APK(s).
- GitHub: push to GitHub, open Actions > **Build Ad Blocker APK** > Run workflow, then download
  the `AdBlocker-debug-apk` artifact. The workflow installs Gradle 8.10.2 itself, so no Gradle
  wrapper is needed. The APK is debug-signed (for testing; Play Store needs a release key).

## Changes in v10 (versionName 1.0.6): automatic ad hunting
Order of checks for every lookup: allowlist (always wins) > filter lists > learned rules >
name detector > upstream resolver verdict > CNAME chain.

- **Automatic ad blocking level** (Settings): Off / Balanced / Strong (default Strong).
  - Detector (`AdHeuristics`): scores a name 0-100+ from words in front of the registrable
    domain (ads, adserver, pagead, banners, vast, rtb, ... and, at Strong, analytics, telemetry,
    metrics, beacon, pixel), from ~130 known ad-network / ad-SDK companies, and from ad compounds.
    Weak words (tracking, events, logs, tags) only add up, so parcel-tracking pages are safe.
  - Balanced blocks at score 100, Strong at 50. Allowed names scoring 25+ are shown as
    "Allowed - looks suspicious" in the DNS Log (new "Suspicious" filter + one-tap block all).
  - Big sites (google.com, facebook.com, tiktok.com, microsoft.com, ...) are never guessed at, so
    advertiser dashboards (ads.google.com, adsmanager.facebook.com, ads.tiktok.com) keep working.
    Names on a real filter list are still blocked.
  - "Ad burst" signal (Strong): a suspicious name looked up right after two ad lookups from the
    same app gets +25.
- **Learned rules** (DNS Log > Auto-blocked): everything the detector or the CNAME check blocks is
  remembered (database v4, up to 4000 names) so the next lookup is answered from memory. Each
  entry shows why and has an Allow button.
- **CNAME uncloaking is stronger**: every alias in the answer chain gets the full check (lists,
  learned rules, detector), the cloaked name is learned, and an allowlisted name is no longer
  overridden by the CNAME check (it was before).
- **AdGuard DNS as first upstream** (Settings toggle): its REFUSED / 0.0.0.0 answers count as
  "Blocked by AdGuard DNS filter". Allowlisted names skip it and use Cloudflare.
- **DNS Log**: "Copy log" button (paste the log into a chat to tune the rules), Suspicious filter.
- Built-in list +40 ad/SDK domains (Samsung ad hub, Moloco, Liftoff, ...), and
  `use-application-dns.net` so Firefox does not switch to DNS-over-HTTPS behind the blocker.
- 30 more public resolver addresses are routed into the tunnel (and TCP-reset).

### Bypass audit (what still gets around a DNS-only blocker)
1. Ads served from the same name as the content (YouTube, Facebook/Instagram feed, in-app video
   ads from the app's own server). DNS cannot tell them apart.
2. Apps that connect to a hard-coded IP address, or to a resolver that is not in
   `PUBLIC_RESOLVERS`. Only a full-tunnel VPN with SNI inspection could stop these.
3. Private DNS set to a host name (Settings > Connections > More connection settings > Private
   DNS must be Off or Automatic) and browsers with their own DNS-over-HTTPS (Chrome "Secure DNS",
   Firefox) pointed at an IP that is not routed into the tunnel.
4. Android battery optimisation stopping the service: set the app to "Unrestricted" / "Never
   sleeping apps" (Samsung: Settings > Battery > Background usage limits).

## Changes in v9
- DNS Log & Rules (Tools, or tap the "DNS lookups seen" card on Home): every lookup as it
  happens, grouped by app where Android reports the owner. Play an ad, find its domain in the
  log and block it (or its parent domain) with one tap. Your rules survive list updates. The
  log is kept in memory only.
- Smart ad detection (Settings, on by default): blocks names like ads.*, adserver*, pagead*,
  banners.* that no list knows yet. Only labels in front of the registrable domain are checked.
- More resolvers are intercepted (Cloudflare/Quad9/OpenDNS/AdGuard variants and Chinese
  "HTTPDNS" services that apps use to skip system DNS).
- Protection restarts after a reboot and after the app is updated (Settings: "Start protection
  when the phone restarts").
- Every blocked lookup records why (list name, Custom, Smart detection, CNAME of ...).

## Changes in v8
- Fixed signing key (`app/adblocker.keystore`) is used for every build, so a new APK installs
  over the previous one (keeps settings and allowlist). Builds from before v8 used a random
  key per build: uninstall that copy once, later updates install over it. Keep the keystore
  file when you rebuild, and use a higher `versionCode` each time.
- Five filter lists (StevenBlack, AdGuard DNS, AdAway, AdServers, GoodbyeAds) plus a built-in
  list of ad-SDK domains (AppLovin, Unity Ads, ironSource, Vungle, Mintegral, Pangle, ...) and
  SHAREit's own servers. The built-in list works even before the first download.
- CNAME-cloaking check: a harmless-looking name that is an alias of a listed tracker is blocked.
- New logo and launcher icon.

## Changes in v7
- Apps that hard-code a public DNS server (8.8.8.8, 1.1.1.1, 9.9.9.9, OpenDNS, AdGuard, ...) are
  now filtered too: those addresses are routed into the tunnel. Encrypted-DNS attempts to them
  (TCP) are refused with a reset so the app falls back to normal DNS.
- Home shows live "DNS lookups seen / blocked" counters; if "seen" stays 0 while browsing, the
  phone is sending DNS around the blocker.
- "Test ad blocking" now says exactly where the test lookup ended up.

## Changes in v6 (ads still showing)
- Filter list is downloaded immediately when protection is turned ON (before, an empty list
  blocked nothing until a background job ran).
- Second list added (AdGuard DNS filter) and subdomain matching enabled, so far more ad
  domains are caught. Database upgraded to v3 (the old list is replaced automatically).
- TUN interface is now blocking, so DNS replies are no longer delayed by polling.
- Home screen warns when strict Private DNS is bypassing the blocker.
- Tools > "Test ad blocking" checks that an ad domain really is blocked on the phone.

## Changes in v5
- Fixed compile errors: missing `AdDomainFilter` and the nested `Result` type in the updater.
- Fixed CI: Gradle version is pinned (AGP 8.7.3 needs Gradle 8.9+).
- DNS queries are handled on a thread pool; one slow lookup no longer stalls the phone.
- Single shared database in WAL mode; filter import uses a prepared statement; blocked events
  are queued and written in batches, history is capped at the latest 1000 events.
- NXDOMAIN replies no longer carry leftover EDNS bytes.
- `onRevoke()` handled; the power button reflects the real VPN state; notification permission
  requested on Android 13+.
- Browser: no longer reloads on every keystroke or refresh; JavaScript and browser blocking are
  real, saved settings. The non-functional toggles were removed.
- Blocklist matching is exact (hosts-file semantics); allowlist entries also cover subdomains.
- Database reads for the UI run off the main thread.

## Known limits
- IPv4 UDP DNS only. Private DNS, DNS-over-HTTPS/TLS, DNS over TCP, IPv6, hard-coded IPs and
  apps with their own encrypted resolver bypass the filter (see the bypass audit above).
- Name guessing can block a legitimate name now and then; use Allow in the DNS Log.
- v10 was written without a device or Android SDK: the detection logic was unit-tested on the
  JVM, the rest needs a normal build and a test on the phone.
- DNS blocking cannot separate ads served from the same domain as content (many video ads).
- Community lists can block legitimate sites; use Allowed Websites to add exceptions.
- Premium is a UI preview, billing is not connected. Speed test is a placeholder.
- Not yet tested on real devices. Before any Play Store release: test on several Android
  versions, add DNS protocol tests, and review Google Play VPN and foreground-service policies.

## Privacy
Allowed DNS queries go to AdGuard DNS first (if the Settings toggle is on), then Cloudflare. Blocked domains are stored locally for the History screen.
No analytics and no account.

## 2.3.1 – Browser pop-up / redirect fix
- New windows (`window.open`, `target=_blank`) are no longer loaded inside the current page; they are caught in `onCreateWindow` and thrown away (Settings > Block Pop-ups).
- Script-made jumps to another site without a tap, and `intent://`, `market://`, `data:` jumps, are blocked. Tapped `magnet:` links open the torrent app.
- A script injected before the page starts replaces `window.open` and removes invisible full-screen tap-catcher layers.
- Third-party requests with typical pop-under script names (`popunder`, `popads`, `/pop.js`, ...) are blocked.

## 2.3.2 – Pop-up / redirect networks for every browser
- Three more filter lists (Hagezi Pop-up Ads, Hagezi Pro, Peter Lowe) and about 30 built-in pop-under / redirect network domains. These work in Chrome and every other app through the VPN.
- A DNS blocker only sees names: a pop-up opened by the site's own domain cannot be stopped this way. Use the in-app browser, or Firefox + uBlock Origin / Brave for that.

## 2.3.3 – Strict redirect rule in the in-app browser
- A page may leave its own site only after a real tap on a visible link to that site, or an address typed in the bar. Script jumps, timers, meta-refresh, hidden/full-screen links, ad iframes and scripted link clicks are blocked.
- Server redirects are followed only as part of a jump that was allowed.
- `window.open` is locked so scripts cannot restore it; links with `target=_blank` are cancelled.

## 2.4.0 – Pop-up / redirect guard for the phone's own browsers (Chrome, Samsung Internet, Firefox, Brave ...)
- New `BrowserGuardService` (Accessibility service, off until you enable it: Settings > Phone Browser Pop-ups > Turn on in Accessibility settings).
- When an ad tab or redirect ends on an address the blocker already refuses (filter lists, your own rules, learned rules, ad-looking names), the guard presses Back: a pop-up tab closes, or you return to the page you were on. Nothing is learned from the pages you visit (`AdBlockerDatabase.isKnownBadHost` is read-only).
- Reads only the address bar of the listed browsers, in memory. Nothing is stored or sent. Does not touch page content or other apps.
- Safety rails: no action while you edit the address bar (or 10 s after); 1.5 s settle time after a close; more than 3 closes in 15 s pause the guard for 30 s (redirect-loop protection). Names on the Allowlist are never closed.
- Android 13+: because the APK is installed outside the Play Store, first open Settings > Apps > Ad Blocker > ⋮ > Allow restricted settings, then enable the service under Accessibility.
- Limit: only addresses the blocker knows are closed. A pop-up to a new, unlisted address looks the same as a normal link and is not closed. Also set Chrome > Settings > Site settings > Pop-ups and redirects to Blocked.
- Not compiled or run on a device in the environment where this was written. Build, then test in Chrome: open a pop-up test page, check the toast "Closed an ad page: ...".
