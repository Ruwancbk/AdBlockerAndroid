package com.adblocker.mobile

import android.content.Context

/** Small settings shared by the screens, the VPN service and the boot receiver. */
object AppPrefs {
    private const val FILE = "settings"

    /**
     * How hard names that no list knows are hunted (read on every DNS lookup, so kept in memory):
     * 0 = lists only, 1 = Balanced (clear ad names), 2 = Strong (also trackers, learned patterns).
     */
    @Volatile
    var autoLevel: Int = 2
        private set

    /** Old name kept for the browser pane: true whenever any automatic detection is on. */
    val smartBlocking: Boolean get() = autoLevel > 0

    /**
     * Ask AdGuard DNS first (it blocks ad names that the downloaded lists miss and is updated
     * every day), then fall back to Cloudflare. Names on the allowlist always use Cloudflare.
     */
    @Volatile
    var filteringUpstream: Boolean = true
        private set

    fun load(context: Context) {
        val p = prefs(context)
        autoLevel = if (p.contains("auto_level")) {
            p.getInt("auto_level", 2).coerceIn(0, 2)
        } else if (p.getBoolean("smart_blocking", true)) 2 else 0
        filteringUpstream = p.getBoolean("filtering_upstream", true)
    }

    fun setAutoLevel(context: Context, value: Int) {
        autoLevel = value.coerceIn(0, 2)
        prefs(context).edit().putInt("auto_level", autoLevel).apply()
    }

    fun setFilteringUpstream(context: Context, value: Boolean) {
        filteringUpstream = value
        prefs(context).edit().putBoolean("filtering_upstream", value).apply()
    }

    /** True while the user wants protection on (set by the power button, not by the system). */
    fun protectionWanted(context: Context): Boolean = prefs(context).getBoolean("protection_wanted", false)

    fun setProtectionWanted(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean("protection_wanted", value).apply()
    }

    fun startOnBoot(context: Context): Boolean = prefs(context).getBoolean("start_on_boot", true)

    fun setStartOnBoot(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean("start_on_boot", value).apply()
    }

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)
}
