# Ad Blocker Android — v2.5.2 (versionCode 16)

Android Studio project (Kotlin, Jetpack Compose), package `com.adblocker.mobile`.

## What is included

- DNS-only local VPN with block/allow rules, downloaded host lists, learned rules and name heuristics.
- Built-in browser (WebView), browsing history, DNS log, statistics, settings and Sinhala/English UI.
- Optional phone-browser pop-up guard using Android Accessibility Services. It is off unless the user explicitly enables it in Android settings.
- Free/Pro feature switches. Premium activation is currently an offline device-key check; it is not Google Play Billing.

## Important DNS/VPN behavior

The VPN routes only the synthetic DNS endpoint `10.10.10.1/32` into its TUN interface. It does **not** route public resolver IP addresses into the VPN. This is deliberate: routing an entire resolver IP can also capture normal HTTPS/TCP connections to that same IP and break unrelated apps.

Allowed DNS questions are forwarded through a protected socket to AdGuard DNS first when enabled, then to Cloudflare. Upstream replies are checked for source, transaction ID, response flag, opcode and matching question. Truncated UDP replies are retried over TCP.

### Known limits

- The current TUN parser handles IPv4 UDP DNS. It does not implement IPv6 DNS, fragmented DNS reassembly, or DNS-over-TCP from applications.
- Hard-coded external DNS servers, DNS-over-HTTPS, DNS-over-TLS/Private DNS and app-specific encrypted resolvers may bypass this DNS-only blocker. Do not enable strict Private DNS or browser Secure DNS if you expect system DNS filtering to apply.
- Ads served from the same domain as the content cannot reliably be distinguished by DNS filtering.
- Community filter lists and heuristic detection can cause false positives. Use the Allowlist to recover a site.
- The phone-browser pop-up guard relies on Accessibility Services and browser address-bar view IDs. Browser updates can change those IDs; test it on each supported browser.
- The Pro key verification secret is embedded in the APK for offline validation. This discourages casual key sharing but is not tamper-proof; a determined attacker can extract it or patch the client. Use a server-side licensing service or Play Billing for commercial distribution.
- Premium billing is not connected to Google Play Billing.

## Build

Requirements: JDK 17, Android SDK Platform 35, Android Gradle Plugin 8.7.3, Gradle 8.10.2.

- Android Studio: open this folder and sync Gradle.
- Command line: run `gradle assembleDebug assembleRelease` with Gradle 8.10.2.
- GitHub Actions: push to `main`/`master`, or run the **Build Ad Blocker APKs** workflow manually. It builds debug and release APKs and uploads them as `AdBlocker-v2.5.1-apks`.

The same `app/adblocker.keystore` is configured for both build types to preserve update signing compatibility. **Treat this ZIP and the keystore password as secrets. Never commit this project to a public repository or share the keystore/password.** If the keystore is lost, future APKs cannot normally update installations signed with it.

## Changes in v2.5.1

- Kept the original signing keystore and alias so existing installations can receive signed updates.
- Stopped routing public resolver IPs into the VPN, preventing unrelated TCP/HTTPS traffic to those IPs from being captured and reset. Hard-coded DNS to those IPs is now a documented bypass.
- Validated upstream DNS response source, transaction ID, response bit, opcode and question section.
- Added DNS-over-TCP fallback when an upstream UDP response is truncated.
- Tightened IPv4/UDP packet length and fragment checks.
- Changed the DNS worker pool to apply back-pressure instead of silently discarding packets when its queue is full.
- Made explicit VPN stop non-sticky so Android does not restart a service the user stopped.
- Made blocked-event queue capacity atomic and re-queue events if a database flush fails.
- Prevented overlapping filter downloads and only advances the global filter freshness timestamp after every applicable list succeeds.
- Added JVM tests for host-list parsing and domain utilities.
- Updated GitHub Actions to build both debug and release APKs.

## Testing status

Source-level changes and the original keystore fingerprint were checked. The original keystore fingerprint matches the one in the supplied v9 and v10 archives. The Android Gradle build and on-device VPN tests could not be run in this environment (Android SDK/Gradle are not installed here). Run the GitHub Actions workflow, install the debug APK for testing, and verify DNS behavior, app connectivity, VPN stop/restart, filter updates and upgrade installation on a real phone before distributing the release APK.

## Privacy

DNS requests that are not blocked are sent to the configured upstream DNS provider(s). Blocked event history and settings are stored locally. The browser pop-up guard reads the address bar of explicitly supported browser apps only while the user has enabled the Accessibility service. No analytics backend is included.
\n\n## v2.5.2 compile fix\n- Fixed the About dialog dismiss button composable lambda so the optional copy-and-clear button is conditionally rendered inside a valid composable slot.\n