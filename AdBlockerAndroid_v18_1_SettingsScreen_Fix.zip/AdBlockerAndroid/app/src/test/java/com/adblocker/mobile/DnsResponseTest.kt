package com.adblocker.mobile

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DnsResponseTest {
    @Test
    fun recognizesResolverSinkholeAddress() {
        val question = byteArrayOf(
            3, 'a'.code.toByte(), 'd'.code.toByte(), 's'.code.toByte(),
            7, 'e'.code.toByte(), 'x'.code.toByte(), 'a'.code.toByte(), 'm'.code.toByte(),
            'p'.code.toByte(), 'l'.code.toByte(), 'e'.code.toByte(),
            3, 'c'.code.toByte(), 'o'.code.toByte(), 'm'.code.toByte(), 0,
            0, 1, 0, 1
        )
        val response = byteArrayOf(
            0x12, 0x34, 0x81.toByte(), 0x80.toByte(), 0, 1, 0, 1, 0, 0, 0, 0
        ) + question + byteArrayOf(
            0xC0.toByte(), 0x0C, 0, 1, 0, 1,
            0, 0, 0, 60, 0, 4, 0, 0, 0, 0
        )

        assertTrue(DnsResponse.isSinkhole(response))
        assertTrue(DnsResponse.blockedByResolver(response))
    }

    @Test
    fun ignoresMalformedOrNonResponseMessages() {
        assertFalse(DnsResponse.isSinkhole(byteArrayOf(1, 2, 3)))
        val query = ByteArray(12)
        assertFalse(DnsResponse.isSinkhole(query))
    }
}
