package com.adblocker.mobile

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class HostListParserTest {
    @Test
    fun parsesHostsAndAdGuardRulesAndSkipsExceptions() {
        val domains = linkedSetOf<String>()
        HostListParser.parseLine("0.0.0.0 Ads.Example.com www.example.net # comment", domains)
        HostListParser.parseLine("||tracker.example.org^", domains)
        HostListParser.parseLine("@@||allowed.example.org^", domains)
        HostListParser.parseLine("||*.wild.example.org^", domains)

        assertEquals(
            linkedSetOf("ads.example.com", "www.example.net", "tracker.example.org"),
            domains
        )
    }

    @Test
    fun rejectsMalformedHostNames() {
        assertTrue(DomainUtil.validDomain("sub.example.com"))
        assertFalse(DomainUtil.validDomain("-bad.example.com"))
        assertFalse(DomainUtil.validDomain("bad..example.com"))
        assertFalse(DomainUtil.validDomain("example.com/path"))
        assertFalse(DomainUtil.validDomain("127.0.0.1"))
        assertFalse(DomainUtil.isIpv4("999.999.999.999"))
    }

    @Test
    fun allowlistAndBlockChoicesUseDomainBoundaries() {
        assertEquals("example.co.uk", DomainUtil.registrableDomain("a.b.example.co.uk"))
        assertEquals(
            listOf("a.example.com", "example.com"),
            DomainUtil.blockChoices("a.example.com")
        )
    }
}
