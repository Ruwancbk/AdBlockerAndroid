package com.adblocker.mobile

import android.content.Context
import android.provider.Settings
import java.security.MessageDigest
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * Free / Pro switch. A Pro key is tied to one phone:
 *   device ID = first 10 bytes of SHA-256("adblocker-device-v1:" + ANDROID_ID), shown as XXXX-XXXX-XXXX-XXXX
 *   Pro key   = first 10 bytes of HMAC-SHA256(SECRET, "pro:" + device ID),     shown the same way
 * The KeyGenerator app uses the same SECRET and the same steps. Keep that app (and this SECRET) private.
 *
 * This is an offline check: it stops casual sharing of keys, not a determined person who patches the APK.
 */
object License {
    /** Must be identical to SECRET in the KeyGenerator app. Change both before you hand out the APK. */
    private const val SECRET = "79cae8039088f8269dfd93dd01027849"
    private const val ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    private const val PREF_KEY = "pro_key"

    @Volatile var isPro: Boolean = false
        private set

    fun deviceId(context: Context): String {
        val androidId = Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"
        val digest = MessageDigest.getInstance("SHA-256").digest("adblocker-device-v1:$androidId".toByteArray())
        return group(encode(digest.copyOf(10)))
    }

    /** Key that belongs to [deviceId]. */
    fun keyFor(deviceId: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(SECRET.toByteArray(), "HmacSHA256"))
        val out = mac.doFinal(("pro:" + normalize(deviceId)).toByteArray())
        return group(encode(out.copyOf(10)))
    }

    fun verify(deviceId: String, key: String): Boolean {
        val given = normalize(key)
        if (given.length != 16) return false
        return MessageDigest.isEqual(given.toByteArray(), normalize(keyFor(deviceId)).toByteArray())
    }

    /** Re-reads the saved key and checks it against THIS phone, so a copied settings file is worthless. */
    fun load(context: Context) {
        isPro = try {
            val saved = prefs(context).getString(PREF_KEY, "") ?: ""
            saved.isNotEmpty() && verify(deviceId(context), saved)
        } catch (e: Exception) {
            false
        }
    }

    /** True and remembered when [key] is valid for this phone. */
    fun activate(context: Context, key: String): Boolean {
        if (!verify(deviceId(context), key)) return false
        prefs(context).edit().putString(PREF_KEY, normalize(key)).apply()
        isPro = true
        return true
    }

    fun deactivate(context: Context) {
        prefs(context).edit().remove(PREF_KEY).apply()
        isPro = false
    }

    private fun normalize(text: String): String = text.uppercase().filter { it in ALPHABET }

    private fun group(text: String): String = text.chunked(4).joinToString("-")

    /** 5 bits per character; 10 bytes = 80 bits = exactly 16 characters. */
    private fun encode(bytes: ByteArray): String {
        val sb = StringBuilder()
        var buffer = 0
        var bits = 0
        for (b in bytes) {
            buffer = (buffer shl 8) or (b.toInt() and 0xFF)
            bits += 8
            while (bits >= 5) {
                sb.append(ALPHABET[(buffer shr (bits - 5)) and 31])
                bits -= 5
            }
            buffer = buffer and ((1 shl bits) - 1)
        }
        if (bits > 0) sb.append(ALPHABET[(buffer shl (5 - bits)) and 31])
        return sb.toString()
    }

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences("settings", Context.MODE_PRIVATE)
}
