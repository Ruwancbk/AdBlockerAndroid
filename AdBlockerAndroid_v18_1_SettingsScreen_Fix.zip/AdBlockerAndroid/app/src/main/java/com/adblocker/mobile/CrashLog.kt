package com.adblocker.mobile

import android.content.Context
import android.util.Log
import java.io.File
import java.util.Date

/**
 * Keeps the last crash (or WebView failure) in a small file so it can be read in Settings > About
 * and pasted into a chat. Nothing is sent anywhere.
 */
object CrashLog {
    private const val FILE = "last_problem.txt"
    @Volatile private var installed = false

    fun install(context: Context) {
        if (installed) return
        installed = true
        val app = context.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            note(app, "CRASH on thread '${thread.name}'\n" + Log.getStackTraceString(error))
            previous?.uncaughtException(thread, error)
        }
    }

    fun note(context: Context, text: String) {
        try {
            File(context.applicationContext.filesDir, FILE).writeText("${Date()}\n$text".take(6000))
        } catch (e: Exception) { }
    }

    fun read(context: Context): String? = try {
        val f = File(context.applicationContext.filesDir, FILE)
        if (f.exists()) f.readText().ifBlank { null } else null
    } catch (e: Exception) { null }

    fun clear(context: Context) {
        try { File(context.applicationContext.filesDir, FILE).delete() } catch (e: Exception) { }
    }
}
