package com.adblocker.mobile

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.TimeUnit

class FilterListUpdater(private val context: Context) {
    private class FilterSource(val id: String, val url: String, val pro: Boolean = false)

    companion object {
        private const val MAX_BYTES = 20L * 1024 * 1024
        private const val MIN_DOMAINS = 100
        private val updateLock = Any()

        /** All lists are merged; a domain in any one of them is blocked. */
        private val SOURCES = listOf(
            FilterSource("StevenBlack", "https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts"),
            FilterSource("AdGuard DNS", "https://raw.githubusercontent.com/AdguardTeam/AdGuardSDNSFilter/gh-pages/Filters/filter.txt"),
            FilterSource("AdAway", "https://raw.githubusercontent.com/AdAway/adaway.github.io/master/hosts.txt"),
            FilterSource("AdServers", "https://raw.githubusercontent.com/anudeepND/blacklist/master/adservers.txt"),
            FilterSource("GoodbyeAds", "https://raw.githubusercontent.com/jerryn70/GoodbyeAds/master/Hosts/GoodbyeAds.txt"),
            // Pop-up / pop-under / redirect ad networks (the kind torrent and streaming sites use).
            FilterSource("Pop-up Ads", "https://raw.githubusercontent.com/hagezi/dns-blocklists/main/domains/popupads.txt", pro = true),
            FilterSource("Hagezi Pro", "https://raw.githubusercontent.com/hagezi/dns-blocklists/main/domains/pro.txt", pro = true),
            FilterSource("Peter Lowe", "https://pgl.yoyo.org/adservers/serverlist.php?hostformat=hosts&showintro=0&mimetype=plaintext", pro = true)
        )
    }

    /** Runs the download on a background thread and reports on the main thread. */
    fun update(onComplete: (kotlin.Result<Int>) -> Unit) {
        Thread {
            val result = downloadAndSave()
            Handler(Looper.getMainLooper()).post { onComplete(result) }
        }.start()
    }

    /** Refresh every 3 days (the lists are large), plus a one-time first download. */
    fun scheduleDailyUpdates() {
        val constraints = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
        val periodic = PeriodicWorkRequestBuilder<FilterUpdateWorker>(72, TimeUnit.HOURS)
            .setConstraints(constraints)
            .build()
        val manager = WorkManager.getInstance(context)
        manager.enqueueUniquePeriodicWork(
            "adblocker_filter_update_v2", ExistingPeriodicWorkPolicy.KEEP, periodic
        )
        Thread {
            try {
                if (AdBlockerDatabase.get(context).lastUpdateMillis() == 0L) {
                    val once = OneTimeWorkRequestBuilder<FilterUpdateWorker>()
                        .setConstraints(constraints)
                        .build()
                    manager.enqueueUniqueWork("adblocker_filter_initial", ExistingWorkPolicy.KEEP, once)
                }
            } catch (ignored: Exception) {
            }
        }.start()
    }

    fun updateNow(): kotlin.Result<Int> = downloadAndSave()

    /**
     * Installs the domains that ship inside the app. It does not touch the "last updated" time,
     * so the first full download still happens.
     */
    fun ensureBuiltIn() {
        val db = AdBlockerDatabase.get(context)
        if (db.getMetadata("builtin_version") == BuiltInFilters.VERSION) return
        db.replaceRemoteDomains(BuiltInFilters.DOMAINS, BuiltInFilters.SOURCE, markUpdated = false)
        db.setMetadata("builtin_version", BuiltInFilters.VERSION)
    }

    /** Updates every applicable list. The global freshness timestamp advances only on a full pass. */
    private fun downloadAndSave(): kotlin.Result<Int> = runCatching {
        synchronized(updateLock) {
            val db = AdBlockerDatabase.get(context)
            License.load(context)
            ensureBuiltIn()
            val failures = ArrayList<String>()
            var updated = 0
            val applicable = SOURCES.filter { !it.pro || License.isPro }
            for (source in SOURCES) {
                if (source.pro && !License.isPro) {
                    // Free version: remove what an earlier Pro period (or an older build) left behind.
                    try {
                        if (db.hasSource(source.id)) {
                            db.replaceRemoteDomains(emptySet(), source.id, markUpdated = false)
                        }
                    } catch (e: Exception) {
                        failures.add("${source.id}: ${e.message ?: e.javaClass.simpleName}")
                    }
                    continue
                }
                try {
                    val domains = download(source)
                    require(domains.size >= MIN_DOMAINS) { "list looks empty or invalid" }
                    // Commit each list atomically, but do not mark the whole refresh complete yet.
                    db.replaceRemoteDomains(domains, source.id, markUpdated = false)
                    updated++
                } catch (e: Exception) {
                    failures.add("${source.id}: ${e.message ?: e.javaClass.simpleName}")
                }
            }
            if (failures.isNotEmpty()) {
                error("Partial filter update ($updated/${applicable.size} lists): " +
                    failures.joinToString("; "))
            }
            if (updated == 0) error("No filter lists were refreshed")
            db.setMetadata("last_filter_update", System.currentTimeMillis().toString())
            db.filterCount()
        }
    }

    /** Streams the list line by line, so large files never have to fit in memory as one string. */
    private fun download(source: FilterSource): Set<String> {
        val connection = (URL(source.url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout = 30_000
            requestMethod = "GET"
            setRequestProperty("User-Agent", "AdBlockerAndroid/1.0")
        }
        try {
            if (connection.responseCode !in 200..299) error("server error ${connection.responseCode}")
            val domains = HashSet<String>()
            LimitedInputStream(connection.inputStream, MAX_BYTES)
                .bufferedReader(Charsets.UTF_8)
                .useLines { lines -> lines.forEach { HostListParser.parseLine(it, domains) } }
            return domains
        } finally {
            connection.disconnect()
        }
    }

    private class LimitedInputStream(input: InputStream, private val limit: Long) : FilterInputStream(input) {
        private var count = 0L

        override fun read(): Int {
            val b = super.read()
            if (b >= 0) add(1)
            return b
        }

        override fun read(b: ByteArray, off: Int, len: Int): Int {
            val n = super.read(b, off, len)
            if (n > 0) add(n)
            return n
        }

        private fun add(n: Int) {
            count += n
            if (count > limit) throw IOException("file exceeds size limit")
        }
    }
}

class FilterUpdateWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        val update = FilterListUpdater(applicationContext).updateNow()
        return if (update.isSuccess) Result.success()
        else if (runAttemptCount < 3) Result.retry() else Result.failure()
    }
}
