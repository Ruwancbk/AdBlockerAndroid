package com.adblocker.mobile

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ---- Privacy Protection ------------------------------------------------------------------------

@Composable
fun PrivacyScreen(db: AdBlockerDatabase, vpnOn: Boolean, onBack: () -> Unit, onPro: () -> Unit, onOpen: (Screen) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val pal = LocalPalette.current
    val tick = rememberTick()
    var blockTrackers by remember { mutableStateOf(AppPrefs.blockTrackers) }
    var privacy by remember { mutableStateOf(AppPrefs.enhancedPrivacy) }
    var confirmClear by remember { mutableStateOf(false) }
    var testResult by remember { mutableStateOf<String?>(null) }
    var testing by remember { mutableStateOf(false) }
    val filters by produceState(0, tick) { value = withContext(Dispatchers.IO) { db.filterCount() } }
    val clearedMsg = tr("Browsing data cleared", "බ්‍රවුස් දත්ත මකා දැමුවා")

    Column(Modifier.fillMaxSize()) {
        SubHeader(tr("Privacy Protection", "පෞද්ගලිකත්ව ආරක්ෂාව"), onBack) { ProPill(onPro) }
        Column(
            Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            SoftCard(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconBubble(56.dp) { Icon(Icons.Default.VerifiedUser, null, tint = if (vpnOn) OkGreen else pal.primary, modifier = Modifier.size(32.dp)) }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            if (vpnOn) tr("Your privacy is protected", "ඔබේ පෞද්ගලිකත්වය ආරක්ෂිතයි")
                            else tr("Protection is off", "ආරක්ෂාව අක්‍රියයි"),
                            color = Ink, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp
                        )
                        Text(
                            if (vpnOn && strictPrivateDns(context))
                                tr("Private DNS is bypassing the blocker. Settings > Network > Private DNS: choose Off or Automatic.",
                                    "Private DNS මගින් අවහිර කරන්නා මඟ හැරේ. Settings > Network > Private DNS: Off හෝ Automatic තෝරන්න.")
                            else if (vpnOn) tr("Tracker lookups are being stopped on this phone.", "ට්‍රැකර් ඉල්ලීම් මෙම දුරකථනයේදී නවත්වනු ලැබේ.")
                            else tr("Turn Ad Blocking ON on the Home screen.", "මුල් පිටුවේ Ad Blocking ON කරන්න."),
                            color = Muted, fontSize = 13.sp
                        )
                    }
                }
            }
            SectionCard(Icons.Default.Lock, tr("Privacy controls", "පෞද්ගලිකත්ව පාලන")) {
                ToggleItem({ Icon(Icons.Default.GpsFixed, null, tint = pal.primary, modifier = Modifier.size(28.dp)) },
                    tr("Block Trackers", "ට්‍රැකර් අවහිර කරන්න"),
                    tr("Prevent websites from tracking you", "වෙබ් අඩවි ඔබව ට්‍රැක් කිරීම වළක්වන්න"), blockTrackers) {
                    blockTrackers = it; AppPrefs.setFlag(context, "block_trackers", it)
                }
                SoftDivider(Modifier.padding(horizontal = 14.dp))
                ToggleItem({ Icon(Icons.Default.VerifiedUser, null, tint = pal.primary, modifier = Modifier.size(28.dp)) },
                    tr("Enhanced Privacy", "වැඩිදියුණු කළ පෞද්ගලිකත්වය"),
                    tr("Blocks third-party cookies in the built-in browser", "ඇතුළත් බ්‍රවුසරයේ තෙවන පාර්ශ්ව cookies අවහිර කරයි"), privacy) {
                    privacy = it; AppPrefs.setFlag(context, "enhanced_privacy", it)
                }
                SoftDivider(Modifier.padding(horizontal = 14.dp))
                LinkItem({ Icon(Icons.Default.Delete, null, tint = pal.primary, modifier = Modifier.size(28.dp)) },
                    tr("Clear Browsing Data", "බ්‍රවුස් දත්ත මකන්න"),
                    tr("History, cookies, cache and site data", "ඉතිහාසය, cookies, cache සහ අඩවි දත්ත")
                ) { confirmClear = true }
            }
            SectionCard(Icons.Default.VerifiedUser, tr("Check your protection", "ඔබේ ආරක්ෂාව පරීක්ෂා කරන්න")) {
                LinkItem({ Icon(Icons.Default.VerifiedUser, null, tint = pal.primary, modifier = Modifier.size(28.dp)) },
                    if (testing) tr("Testing...", "පරීක්ෂා කරමින්...") else tr("Test ad blocking", "දැන්වීම් අවහිර කිරීම පරීක්ෂා කරන්න"),
                    testResult ?: tr("Checks that ad domains are really being blocked on this phone", "මෙම දුරකථනයේ දැන්වීම් domain සැබෑවටම අවහිර වේදැයි පරීක්ෂා කරයි")
                ) {
                    if (!testing) {
                        testing = true
                        scope.launch {
                            testResult = withContext(Dispatchers.IO) { runBlockingTest(vpnOn, filters) }
                            testing = false
                        }
                    }
                }
                SoftDivider(Modifier.padding(horizontal = 14.dp))
                LinkItem({ Icon(Icons.Default.Layers, null, tint = pal.primary, modifier = Modifier.size(28.dp)) },
                    tr("DNS Log & Rules", "DNS Log සහ නීති"),
                    tr("See what each app contacts and block ad domains yourself", "එක් එක් යෙදුම සම්බන්ධ වන දේ බලා ඔබම දැන්වීම් domain අවහිර කරන්න")
                ) { onOpen(Screen.LOG) }
            }
            Spacer(Modifier.height(10.dp))
        }
    }
    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text(tr("Clear Browsing Data", "බ්‍රවුස් දත්ත මකන්න")) },
            text = { Text(tr("History, cookies, cache and site data of the built-in browser will be deleted.", "ඇතුළත් බ්‍රවුසරයේ ඉතිහාසය, cookies, cache සහ අඩවි දත්ත මැකෙනු ඇත.")) },
            confirmButton = {
                TextButton(onClick = {
                    clearBrowsingData(context)
                    Toast.makeText(context, clearedMsg, Toast.LENGTH_SHORT).show()
                    confirmClear = false
                }) { Text(tr("Clear", "මකන්න")) }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text(tr("Cancel", "අවලංගු")) } }
        )
    }
}

// ---- Allowed Websites --------------------------------------------------------------------------

@Composable
fun WhitelistScreen(db: AdBlockerDatabase, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val pal = LocalPalette.current
    var input by remember { mutableStateOf("") }
    var refresh by remember { mutableIntStateOf(0) }
    val allowed by produceState(emptyList<String>(), refresh) {
        value = withContext(Dispatchers.IO) { db.allowedDomains() }
    }
    val invalidMsg = tr("Enter a valid domain such as example.com", "example.com වැනි වලංගු domain එකක් ඇතුළත් කරන්න")

    Column(Modifier.fillMaxSize()) {
        SubHeader(tr("Allowed Websites", "ඉඩ දුන් වෙබ් අඩවි"), onBack)
        Column(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(
                tr("Domains added here (and their subdomains) are never blocked.", "මෙහි එක් කරන domains (සහ ඒවායේ subdomains) කිසිවිටෙක අවහිර නොවේ."),
                color = Muted, fontSize = 14.sp
            )
            SoftCard(Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = input, onValueChange = { input = it },
                        modifier = Modifier.fillMaxWidth(), label = { Text("example.com") },
                        singleLine = true, shape = RoundedCornerShape(16.dp)
                    )
                    GradientButton(tr("Add to Allowlist", "ඉඩ දුන් ලැයිස්තුවට එක් කරන්න"), Modifier.fillMaxWidth()) {
                        val domain = AdBlockerDatabase.normalizeHost(input)
                        if (AdBlockerDatabase.validDomain(domain)) {
                            scope.launch {
                                withContext(Dispatchers.IO) { db.addAllowedDomain(domain) }
                                input = ""
                                refresh++
                            }
                        } else {
                            Toast.makeText(context, invalidMsg, Toast.LENGTH_LONG).show()
                        }
                    }
                }
            }
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(allowed) { domain ->
                    SoftCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
                        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 6.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(domain, color = Ink, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.weight(1f))
                            TextButton(onClick = {
                                scope.launch {
                                    withContext(Dispatchers.IO) { db.removeAllowedDomain(domain) }
                                    refresh++
                                }
                            }) { Text(tr("Remove", "ඉවත් කරන්න"), color = DangerRed) }
                        }
                    }
                }
                item { Spacer(Modifier.height(12.dp)) }
            }
        }
    }
}

// ---- Premium ---------------------------------------------------------------------------------

@Composable
private fun GradientButton(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    val pal = LocalPalette.current
    val shape = RoundedCornerShape(50)
    Box(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.horizontalGradient(listOf(pal.primary, pal.dark)), alpha = if (enabled) 1f else 0.4f)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(vertical = 13.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp) }
}

/** Free vs Pro, the phone's device ID, and key entry. The key comes from the KeyGenerator app. */
@Composable
fun PremiumScreen(onPro: () -> Unit) {
    val pal = LocalPalette.current
    val context = LocalContext.current
    var pro by remember { mutableStateOf(License.isPro) }
    var keyInput by remember { mutableStateOf("") }
    val deviceId = remember { License.deviceId(context) }
    val okMsg = tr("Pro activated. Thank you!", "Pro සක්‍රීය කළා. ස්තූතියි!")
    val badMsg = tr("This key is not valid for this phone", "මෙම key එක මෙම දුරකථනයට වලංගු නැත")
    val copiedMsg = tr("Device ID copied", "Device ID පිටපත් කළා")
    val freeMsg = tr("Back to the free version", "නොමිලේ අනුවාදයට ආපසු")
    val shareText = tr("My Ad Blocker device ID: $deviceId", "මගේ Ad Blocker device ID: $deviceId")

    Column(Modifier.fillMaxSize()) {
        BrandHeader(onPro = onPro) { Spacer(Modifier.size(42.dp)) }
        Column(
            Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Spacer(Modifier.height(4.dp))
            ShieldLogo(96.dp)
            Text("Ad Blocker Pro", color = Ink, fontWeight = FontWeight.ExtraBold, fontSize = 28.sp)
            Text(
                if (pro) tr("Pro is active on this phone", "මෙම දුරකථනයේ Pro සක්‍රියයි")
                else tr("You are using the free version", "ඔබ භාවිතා කරන්නේ නොමිලේ අනුවාදයයි"),
                color = if (pro) pal.primary else Muted, fontWeight = FontWeight.Bold, fontSize = 15.sp
            )
            SoftCard(Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    listOf(
                        tr("Pop-up Guard for phone browsers", "ෆෝන් බ්‍රවුසර් සඳහා Pop-up ආරක්ෂකය") to
                            tr("Free: not available", "Free: නැත"),
                        tr("Strong automatic ad blocking", "ශක්තිමත් ස්වයංක්‍රීය දැන්වීම් අවහිර කිරීම") to
                            tr("Free: Balanced only", "Free: සමතුලිත පමණි"),
                        tr("Advanced filter lists (Hagezi Pop-up Ads, Hagezi Pro, Peter Lowe)", "උසස් filter lists (Hagezi Pop-up Ads, Hagezi Pro, Peter Lowe)") to
                            tr("Free: 5 core lists + built-in list", "Free: මූලික lists 5ක් + built-in list")
                    ).forEachIndexed { i, (text, freeNote) ->
                        if (i > 0) SoftDivider(Modifier.padding(horizontal = 14.dp))
                        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(30.dp).clip(CircleShape).background(pal.primary), contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(18.dp))
                            }
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text(text, color = Ink, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                                Text(freeNote, color = Muted, fontSize = 12.5.sp)
                            }
                        }
                    }
                }
            }
            if (!pro) {
                SoftCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(tr("1. Send this device ID to get your key", "1. ඔබේ key එක ලබාගැනීමට මෙම device ID එක එවන්න"), color = Ink, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                        Text(
                            deviceId, color = pal.primary, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp,
                            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                            modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
                        )
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                            TextButton(onClick = {
                                (context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                                    .setPrimaryClip(ClipData.newPlainText("device id", deviceId))
                                Toast.makeText(context, copiedMsg, Toast.LENGTH_SHORT).show()
                            }) { Text(tr("Copy", "පිටපත් කරන්න")) }
                            TextButton(onClick = {
                                try {
                                    context.startActivity(
                                        Intent.createChooser(
                                            Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, shareText), null
                                        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    )
                                } catch (e: Exception) { }
                            }) { Text(tr("Share", "බෙදාගන්න")) }
                        }
                        SoftDivider()
                        Text(tr("2. Enter the key you received", "2. ලැබුණු key එක ඇතුළත් කරන්න"), color = Ink, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                        OutlinedTextField(
                            value = keyInput, onValueChange = { keyInput = it.uppercase().take(24) },
                            modifier = Modifier.fillMaxWidth(), singleLine = true,
                            label = { Text("XXXX-XXXX-XXXX-XXXX") }, shape = RoundedCornerShape(16.dp)
                        )
                        GradientButton(tr("Activate Pro", "Pro සක්‍රීය කරන්න"), keyInput.isNotBlank()) {
                            if (License.activate(context, keyInput)) {
                                AppPrefs.load(context)
                                FilterListUpdater(context).update { }
                                pro = true
                                keyInput = ""
                                Toast.makeText(context, okMsg, Toast.LENGTH_LONG).show()
                            } else {
                                Toast.makeText(context, badMsg, Toast.LENGTH_LONG).show()
                            }
                        }
                    }
                }
            } else {
                TextButton(onClick = {
                    License.deactivate(context)
                    AppPrefs.load(context)
                    FilterListUpdater(context).update { }
                    pro = false
                    Toast.makeText(context, freeMsg, Toast.LENGTH_SHORT).show()
                }) { Text(tr("Remove Pro key from this phone", "මෙම දුරකථනයෙන් Pro key එක ඉවත් කරන්න"), color = Muted) }
            }
            Text(
                tr("Keys are made for one phone only. Payment is handled by the developer, not inside this app.",
                    "key එක නිකුත් කරන්නේ එක් දුරකථනයකට පමණි. ගෙවීම් කළමනාකරණය කරන්නේ developer විසින්, මෙම යෙදුම තුළ නොවේ."),
                color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(8.dp))
        }
    }
}
