package com.adblocker.mobile

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.ConnectivityManager
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.system.OsConstants
import androidx.compose.runtime.mutableStateOf
import androidx.core.app.NotificationCompat
import java.io.FileInputStream
import java.io.IOException
import java.io.FileOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

/**
 * DNS-only local VPN:
 * - Routes only the synthetic DNS server address (10.10.10.1) through the TUN interface.
 * - Answers NXDOMAIN for domains in the filter lists, for learned rules and for names that look like
 *   ad servers (unless allowlisted), and for aliases (CNAME) that lead to such names.
 * - Forwards everything else over IPv4 UDP to AdGuard DNS (which refuses ad names too), falling back
 *   to Cloudflare (1.1.1.1 / 1.0.0.1).
 *
 * Hard-coded external DNS and encrypted DNS are not intercepted; avoiding broad resolver routes
 * prevents unrelated HTTPS traffic from being captured or broken.
 * Queries are handled on a small thread pool so one slow upstream lookup cannot stall
 * every other DNS request on the phone.
 */
class DnsVpnService : VpnService() {
    companion object {
        const val ACTION_START = "com.adblocker.mobile.START"
        const val ACTION_STOP = "com.adblocker.mobile.STOP"
        private const val CHANNEL = "adblocker_vpn"
        private const val CHANNEL_QUIET = "adblocker_vpn_quiet"
        private const val NOTIFICATION_ID = 42
        /** Plain resolvers (no filtering of their own). */
        private val PLAIN_UPSTREAM = arrayOf("1.1.1.1", "1.0.0.1")

        /** AdGuard DNS: refuses or null-routes ad and tracker names, updated daily. Tried first when enabled. */
        private val FILTERING_UPSTREAM = arrayOf("94.140.14.14", "94.140.15.15")

        /** Observed by the UI so the power button always reflects the real VPN state. */
        val active = mutableStateOf(false)
    }

    private var tun: ParcelFileDescriptor? = null
    private val running = AtomicBoolean(false)
    private var database: AdBlockerDatabase? = null
    private var workers: ThreadPoolExecutor? = null
    private var flusher: ScheduledExecutorService? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return if (intent?.action == ACTION_STOP) {
            stopVpn()
            START_NOT_STICKY
        } else {
            startVpn()
            START_STICKY
        }
    }

    private fun startVpn() {
        if (running.get()) return
        AppPrefs.load(this)
        val db = AdBlockerDatabase.get(this)
        database = db
        createChannel()
        startForeground(NOTIFICATION_ID, notification())

        val descriptor = try {
            Builder()
                .setSession("Ad Blocker DNS")
                .setMtu(1500)
                .setBlocking(true)
                .addAddress("10.10.10.2", 32)
                .addDnsServer("10.10.10.1")
                // Route only the synthetic DNS endpoint. Routing public resolver IPs would
                // capture unrelated HTTPS/TCP traffic to those same IPs and break apps.
                .addRoute("10.10.10.1", 32)
                .establish()
        } catch (e: Exception) {
            null
        }
        if (descriptor == null) {
            stopVpn()
            return
        }

        tun = descriptor
        val pool = ThreadPoolExecutor(
            8, 8, 30L, TimeUnit.SECONDS,
            ArrayBlockingQueue<Runnable>(256),
            // Apply back-pressure rather than silently discarding DNS packets when busy.
            ThreadPoolExecutor.CallerRunsPolicy()
        )
        workers = pool
        flusher = Executors.newSingleThreadScheduledExecutor().also { scheduler ->
            scheduler.scheduleWithFixedDelay({
                try { db.flushEvents() } catch (e: Exception) { }
            }, 3, 3, TimeUnit.SECONDS)
        }
        AppPrefs.load(this)
        DnsActivity.reset()
        running.set(true)
        active.value = true
        thread(name = "AdBlockerDnsTun") { packetLoop(descriptor, pool, db) }
        refreshFilterListIfNeeded(db)
    }

    /**
     * An empty filter list blocks nothing, so download it right away when protection is turned
     * on for the first time (or when the list is more than a day old) instead of waiting for
     * the background job.
     */
    private fun refreshFilterListIfNeeded(db: AdBlockerDatabase) {
        val appContext = applicationContext
        thread(name = "AdBlockerFilterRefresh") {
            try {
                val updater = FilterListUpdater(appContext)
                updater.ensureBuiltIn()
                val last = db.lastUpdateMillis()
                val stale = System.currentTimeMillis() - last > TimeUnit.HOURS.toMillis(72)
                if (last == 0L || stale) updater.updateNow()
            } catch (e: Exception) {
                // The scheduled job will retry later.
            }
        }
    }

    private fun packetLoop(descriptor: ParcelFileDescriptor, pool: ThreadPoolExecutor, db: AdBlockerDatabase) {
        val input = FileInputStream(descriptor.fileDescriptor)
        val output = FileOutputStream(descriptor.fileDescriptor)
        val buffer = ByteArray(32767)
        while (running.get()) {
            try {
                val length = input.read(buffer)
                if (length < 0) break
                if (length == 0) continue
                val packet = buffer.copyOf(length)
                pool.execute { handlePacket(packet, output, db) }
            } catch (e: Exception) {
                if (!running.get()) break
                try { Thread.sleep(20) } catch (interrupted: InterruptedException) { break }
            }
        }
    }

    private fun handlePacket(packet: ByteArray, output: FileOutputStream, db: AdBlockerDatabase) {
        try {
            val parsed = parseDnsPacket(packet)
            if (parsed == null) {
                // Not plain DNS. Refuse TCP (DoT/DoH/DNS-over-TCP) quickly; drop everything else.
                PacketUtil.buildTcpReset(packet)?.let { reset -> synchronized(output) { output.write(reset) } }
                return
            }
            val query = parsed.dns
            val question = DnsName.readQuestion(query)
            val app = if (question != null) resolveApp(packet, parsed.ipHeaderLength) else unknownApp
            val level = AppPrefs.autoLevel

            var reason: String? = null
            var category = "DNS"
            var score = 0
            if (question != null) {
                val verdict = db.judge(question.name, level, app.first, app.second)
                reason = verdict.reason
                category = verdict.category
                score = verdict.score
                // The Settings switches (ads / pop-ups / trackers / annoying elements) can let a kind through.
                if (reason != null && !AppPrefs.kindEnabled(EventKind.classify(question.name))) reason = null
            }

            var response: ByteArray? = null
            if (question != null && reason != null) {
                response = makeNxDomain(query, question.end)
            } else {
                val allowed = question != null && db.isDomainAllowed(question.name)
                // Names on the allowlist skip the filtering resolver so it cannot veto them.
                val upstream = forwardDns(query, AppPrefs.filteringUpstream && !allowed) ?: return
                if (question != null && upstream.filtered && DnsResponse.blockedByResolver(upstream.data) &&
                    AppPrefs.kindEnabled(EventKind.classify(question.name))
                ) {
                    reason = "Blocked by AdGuard DNS filter"
                    category = "DNS"
                    response = makeNxDomain(query, question.end)
                } else if (question != null && !allowed) {
                    // CNAME cloaking: the name looks harmless but is an alias of an ad/tracker name.
                    // Every alias in the chain gets the full check (lists, learned rules, detector).
                    var cloakedBy: String? = null
                    for (target in DnsResponse.cnameTargets(upstream.data)) {
                        if (db.judge(target, level, app.first, app.second).reason != null &&
                            AppPrefs.kindEnabled(EventKind.classify(target))
                        ) {
                            cloakedBy = target
                            break
                        }
                    }
                    if (cloakedBy != null) {
                        reason = "CNAME of $cloakedBy"
                        category = "CNAME"
                        if (level > 0) {
                            db.learnBlock(question.name, 100, "CNAME-cloaked, alias of $cloakedBy", app.first, app.second)
                        }
                        response = makeNxDomain(query, question.end)
                    }
                }
                if (response == null) response = upstream.data
            }

            if (question != null) {
                DnsActivity.record(question.name, reason != null, reason ?: "", app.first, app.second, score)
                if (reason != null) {
                    db.addBlockedEvent(question.name, category)
                    AutoBlock.noteAdHit(app.first, System.currentTimeMillis())
                }
            }
            val reply = buildIpv4UdpReply(packet, parsed.ipHeaderLength, response ?: return)
            synchronized(output) { output.write(reply) }
        } catch (e: Exception) {
            // Drop this one query; the client will retry.
        }
    }

    private class Parsed(val ipHeaderLength: Int, val dns: ByteArray)

    private val appNames = ConcurrentHashMap<Int, Pair<String, String>>()
    private val unknownApp = Pair("", "Unknown app")

    /**
     * Best effort: asks Android which app owns the socket that sent this lookup (Android 10+).
     * Some phones attribute DNS to a system service instead; then the log says so.
     */
    private fun resolveApp(packet: ByteArray, ipHeaderLength: Int): Pair<String, String> {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return unknownApp
        return try {
            val source = InetSocketAddress(
                InetAddress.getByAddress(packet.copyOfRange(12, 16)), PacketUtil.u16(packet, ipHeaderLength)
            )
            val target = InetSocketAddress(
                InetAddress.getByAddress(packet.copyOfRange(16, 20)), PacketUtil.u16(packet, ipHeaderLength + 2)
            )
            val manager = getSystemService(ConnectivityManager::class.java)
            val uid = manager.getConnectionOwnerUid(OsConstants.IPPROTO_UDP, source, target)
            if (uid < 0) unknownApp else appNames.getOrPut(uid) { describeUid(uid) }
        } catch (e: Exception) {
            unknownApp
        }
    }

    private fun describeUid(uid: Int): Pair<String, String> {
        if (uid == 0) return Pair("root", "Android (root)")
        if (uid in 1000..9999) return Pair("uid:$uid", "Android system service")
        val pm = packageManager
        val packageName = pm.getPackagesForUid(uid)?.firstOrNull() ?: return Pair("uid:$uid", "App #$uid")
        val label = try {
            pm.getApplicationLabel(pm.getApplicationInfo(packageName, 0)).toString()
        } catch (e: Exception) {
            packageName
        }
        return Pair(packageName, label)
    }

    private fun parseDnsPacket(packet: ByteArray): Parsed? {
        if (packet.size < 28) return null
        val version = (packet[0].toInt() ushr 4) and 0xF
        if (version != 4) return null
        val ihl = (packet[0].toInt() and 0xF) * 4
        if (ihl < 20 || packet.size < ihl + 8) return null
        val ipLength = u16(packet, 2)
        if (ipLength < ihl + 8 || ipLength > packet.size) return null
        // Fragmented IPv4 datagrams need reassembly; reject rather than parse partial DNS.
        val fragment = u16(packet, 6)
        if ((fragment and 0x3FFF) != 0) return null
        if ((packet[9].toInt() and 0xFF) != 17) return null // UDP only
        val destPort = u16(packet, ihl + 2)
        if (destPort != 53) return null
        val udpLen = u16(packet, ihl + 4)
        if (udpLen < 8 + 12 || ihl + udpLen != ipLength) return null
        return Parsed(ihl, packet.copyOfRange(ihl + 8, ipLength))
    }

    private class Upstream(val data: ByteArray, val filtered: Boolean)

    /** Asks the filtering resolver first when [useFilter] is set, then the plain ones. */
    private fun forwardDns(query: ByteArray, useFilter: Boolean): Upstream? {
        val question = DnsName.readQuestion(query) ?: return null
        val servers = if (useFilter) FILTERING_UPSTREAM + PLAIN_UPSTREAM else PLAIN_UPSTREAM
        for (server in servers) {
            try {
                val address = InetAddress.getByName(server)
                val udpResponse = DatagramSocket().use { socket ->
                    if (!protect(socket)) throw IOException("Could not protect DNS socket from VPN")
                    socket.soTimeout = 2500
                    socket.connect(address, 53)
                    socket.send(DatagramPacket(query, query.size))
                    val data = ByteArray(4096)
                    val response = DatagramPacket(data, data.size)
                    socket.receive(response)
                    if (response.address != address || response.port != 53) null
                    else data.copyOf(response.length)
                } ?: continue

                if (!isMatchingDnsResponse(query, question.end, udpResponse)) continue
                // RFC 7766: a truncated UDP response must be retried over TCP.
                val complete = if ((PacketUtil.u16(udpResponse, 2) and 0x0200) != 0) {
                    dnsOverTcp(address, query) ?: continue
                } else udpResponse
                if (!isMatchingDnsResponse(query, question.end, complete)) continue
                if ((PacketUtil.u16(complete, 2) and 0x0200) != 0) continue
                return Upstream(complete, server in FILTERING_UPSTREAM)
            } catch (e: Exception) {
                // Try the next upstream server.
            }
        }
        return null
    }

    /** Checks transaction ID, response bit, opcode, one matching question and sane DNS length. */
    private fun isMatchingDnsResponse(query: ByteArray, questionEnd: Int, response: ByteArray): Boolean {
        if (response.size < questionEnd || response.size > 65535) return false
        if (PacketUtil.u16(response, 0) != PacketUtil.u16(query, 0)) return false
        val flags = PacketUtil.u16(response, 2)
        if ((flags and 0x8000) == 0) return false
        if ((flags and 0x7800) != (PacketUtil.u16(query, 2) and 0x7800)) return false
        if (PacketUtil.u16(response, 4) != 1) return false
        return response.copyOfRange(12, questionEnd)
            .contentEquals(query.copyOfRange(12, questionEnd))
    }

    /** Protected TCP fallback for DNS responses carrying the TC bit. */
    private fun dnsOverTcp(address: InetAddress, query: ByteArray): ByteArray? {
        return try {
            Socket().use { socket ->
                if (!protect(socket)) throw IOException("Could not protect DNS TCP socket from VPN")
                socket.connect(InetSocketAddress(address, 53), 2500)
                socket.soTimeout = 2500
                val output = DataOutputStream(socket.getOutputStream())
                output.writeShort(query.size)
                output.write(query)
                output.flush()
                val input = DataInputStream(socket.getInputStream())
                val length = input.readUnsignedShort()
                if (length < 12 || length > 4096) return null
                val response = ByteArray(length)
                input.readFully(response)
                response
            }
        } catch (e: Exception) {
            null
        }
    }

    /** NXDOMAIN reply that contains only the header and the question (no EDNS leftovers). */
    private fun makeNxDomain(query: ByteArray, questionEnd: Int): ByteArray {
        val out = query.copyOf(questionEnd)
        // Keep opcode + RD from the query; set QR, RA and RCODE=3 (NXDOMAIN).
        val flags = (u16(out, 2) and 0x7900) or 0x8000 or 0x0080 or 0x0003
        put16(out, 2, flags)
        put16(out, 4, 1)
        put16(out, 6, 0)
        put16(out, 8, 0)
        put16(out, 10, 0)
        return out
    }

    private fun buildIpv4UdpReply(original: ByteArray, ihl: Int, dns: ByteArray): ByteArray {
        val udpLength = 8 + dns.size
        val totalLength = ihl + udpLength
        val out = ByteArray(totalLength)
        System.arraycopy(original, 0, out, 0, ihl)
        // Swap IPv4 source and destination.
        for (i in 0..3) {
            out[12 + i] = original[16 + i]
            out[16 + i] = original[12 + i]
        }
        put16(out, 2, totalLength)
        out[8] = 64.toByte()
        out[10] = 0; out[11] = 0
        put16(out, 10, checksum(out, 0, ihl))
        val udp = ihl
        put16(out, udp, 53)
        put16(out, udp + 2, u16(original, ihl))
        put16(out, udp + 4, udpLength)
        put16(out, udp + 6, 0)
        System.arraycopy(dns, 0, out, udp + 8, dns.size)
        return out
    }

    private fun checksum(data: ByteArray, offset: Int, length: Int): Int {
        var sum = 0L
        var i = offset
        while (i < offset + length) {
            val high = data[i].toInt() and 0xFF
            val low = if (i + 1 < offset + length) data[i + 1].toInt() and 0xFF else 0
            sum += (high shl 8) or low
            i += 2
        }
        while ((sum shr 16) != 0L) sum = (sum and 0xFFFF) + (sum shr 16)
        return sum.inv().toInt() and 0xFFFF
    }

    private fun u16(data: ByteArray, offset: Int): Int =
        ((data[offset].toInt() and 0xFF) shl 8) or (data[offset + 1].toInt() and 0xFF)

    private fun put16(data: ByteArray, offset: Int, value: Int) {
        data[offset] = (value shr 8).toByte()
        data[offset + 1] = value.toByte()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL, "Ad Blocker VPN", NotificationManager.IMPORTANCE_LOW)
            )
            // Used when "Notifications" is off in Settings: Android still requires a notification for
            // a running VPN service, so it is shown without sound, badge or status-bar icon.
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_QUIET, "Ad Blocker (quiet)", NotificationManager.IMPORTANCE_MIN)
            )
        }
    }

    private fun notification(): Notification =
        NotificationCompat.Builder(this, if (AppPrefs.notifications) CHANNEL else CHANNEL_QUIET)
            .setContentTitle("Ad Blocker is active")
            .setContentText("Filtering known ad and tracker domains")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setOngoing(true)
            .build()

    private fun stopVpn() {
        running.set(false)
        active.value = false
        database?.let { db ->
            thread(name = "AdBlockerFlush") {
                try { db.flushEvents() } catch (e: Exception) { }
            }
        }
        flusher?.shutdownNow()
        flusher = null
        workers?.shutdownNow()
        workers = null
        try { tun?.close() } catch (e: Exception) { }
        tun = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    /** Called when the user revokes VPN permission or another VPN app takes over. */
    override fun onRevoke() {
        AppPrefs.setProtectionWanted(this, false)
        stopVpn()
        super.onRevoke()
    }

    override fun onDestroy() {
        stopVpn()
        super.onDestroy()
    }
}

private class Question(val name: String, val end: Int)

private object DnsName {
    /** Parses the single question of a standard query. Returns null if it can't be parsed safely. */
    fun readQuestion(message: ByteArray): Question? {
        if (message.size < 17) return null
        val flags = ((message[2].toInt() and 0xFF) shl 8) or (message[3].toInt() and 0xFF)
        if ((flags and 0x8000) != 0) return null // a response, not a query
        val questions = ((message[4].toInt() and 0xFF) shl 8) or (message[5].toInt() and 0xFF)
        if (questions != 1) return null

        val labels = ArrayList<String>()
        var pos = 12
        while (true) {
            if (pos >= message.size) return null
            val length = message[pos].toInt() and 0xFF
            if (length == 0) { pos += 1; break }
            // > 63 also rules out compression pointers, which never appear in a question.
            if (length > 63 || pos + 1 + length > message.size) return null
            labels.add(String(message, pos + 1, length, Charsets.US_ASCII))
            pos += length + 1
        }
        val end = pos + 4 // QTYPE + QCLASS
        if (end > message.size) return null
        val name = labels.joinToString(".").lowercase()
        // Reject malformed/oversized host labels before they reach database matching or heuristics.
        if (name.isBlank() || name.length > 253) return null
        if (labels.any { label ->
                label.length !in 1..63 ||
                    !label.first().isLetterOrDigit() ||
                    !label.last().isLetterOrDigit() ||
                    label.any { !it.isLetterOrDigit() && it != '-' }
            }) return null
        return Question(name, end)
    }
}
