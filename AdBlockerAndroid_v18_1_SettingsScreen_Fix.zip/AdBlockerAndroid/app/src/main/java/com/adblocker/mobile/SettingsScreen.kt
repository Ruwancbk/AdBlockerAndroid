package com.adblocker.mobile

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.webkit.CookieManager
import android.webkit.WebStorage
import android.webkit.WebView
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.DateFormat
import java.util.Date
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

object SearchEngines {
    val all = listOf(
        Triple("google", "Google", "https://www.google.com/search?q="),
        Triple("bing", "Bing", "https://www.bing.com/search?q="),
        Triple("duckduckgo", "DuckDuckGo", "https://duckduckgo.com/?q="),
        Triple("brave", "Brave Search", "https://search.brave.com/search?q=")
    )

    fun url(key: String): String = (all.firstOrNull { it.first == key } ?: all[0]).third
    fun label(key: String): String = (all.firstOrNull { it.first == key } ?: all[0]).second
}

// ---- reusable rows -------------------------------------------------------------------------

@Composable
fun ToggleItem(icon: @Composable () -> Unit, title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    val pal = LocalPalette.current
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
        IconBubble(44.dp) { icon() }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
            if (subtitle != null) Text(subtitle, color = Muted, fontSize = 12.5.sp, lineHeight = 16.sp)
        }
        Spacer(Modifier.width(8.dp))
        Switch(
            checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White, checkedTrackColor = pal.primary, checkedBorderColor = Color.Transparent,
                uncheckedThumbColor = Color.White, uncheckedTrackColor = Color(0xFFD3C9E6), uncheckedBorderColor = Color.Transparent
            )
        )
    }
}

@Composable
fun LinkItem(icon: @Composable () -> Unit, title: String, subtitle: String? = null, value: String? = null, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconBubble(44.dp) { icon() }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
            if (subtitle != null) Text(subtitle, color = Muted, fontSize = 12.5.sp, lineHeight = 16.sp)
        }
        if (value != null) {
            Spacer(Modifier.width(6.dp))
            Text(value, color = Muted, fontSize = 14.sp, maxLines = 1)
        }
        Icon(Icons.Default.ChevronRight, null, tint = Ink, modifier = Modifier.size(24.dp))
    }
}

@Composable
fun SectionCard(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, content: @Composable () -> Unit) {
    SoftCard(Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth().padding(bottom = 6.dp)) {
            SectionTitle(icon, title)
            content()
        }
    }
}

@Composable
fun ChoiceDialog(
    title: String, options: List<Pair<String, String>>, selected: String,
    onPick: (String) -> Unit, onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                options.forEach { (key, label) ->
                    Row(
                        Modifier.fillMaxWidth().clickable { onPick(key) },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = key == selected, onClick = { onPick(key) })
                        Text(label, fontSize = 16.sp)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(tr("Close", "වසන්න")) } }
    )
}

// ---- helpers shared with the other screens ----------------------------------------------------

/** Removes the in-app browser's history, cookies, cache and site data. Call on the main thread. */
fun clearBrowsingData(context: Context) {
    try {
        val web = WebView(context)
        web.clearCache(true)
        web.clearHistory()
        web.clearFormData()
        web.destroy()
        CookieManager.getInstance().removeAllCookies(null)
        CookieManager.getInstance().flush()
        WebStorage.getInstance().deleteAllData()
    } catch (e: Exception) {
        // Nothing more to clear if WebView is unavailable.
    }
}

/**
 * Resolves a fresh sub-domain of a well-known ad domain through the system resolver and
 * reports where the lookup ended up (blocked, reached the blocker but not blocked, or never
 * reached the blocker at all).
 */
fun runBlockingTest(vpnOn: Boolean, filters: Int): String {
    if (!vpnOn) return "Turn Ad Blocking ON first, then run the test again."
    if (filters == 0) return "The filter list is still downloading. Wait a minute and try again."
    val name = "t${System.nanoTime()}.doubleclick.net"
    try {
        java.net.InetAddress.getByName(name)
    } catch (e: Exception) {
        // NXDOMAIN is the expected answer; what matters is what the blocker saw.
    }
    Thread.sleep(300)
    return when {
        DnsActivity.wasBlocked(name) -> "Working: the blocker received the lookup and blocked it."
        DnsActivity.wasSeen(name) -> "The lookup reached the blocker but was not blocked. Update the filter list in Settings and test again."
        else -> "Not working: the lookup never reached the blocker, so this phone sends DNS around it. " +
            "Turn Private DNS off (Settings > Network), turn off Secure DNS in Chrome, and disconnect any other VPN."
    }
}

fun formatTime(millis: Long): String = DateFormat.getDateTimeInstance().format(Date(millis))

private class FilterInfo(val count: Int = 0, val lastUpdate: Long = 0L)

// ---- screen ---------------------------------------------------------------------------------

@Composable
fun SettingsScreen(
    db: AdBlockerDatabase,
    vpnOn: Boolean,
    language: String,
    theme: String,
    onBack: () -> Unit,
    onPro: () -> Unit,
    onOpen: (Screen) -> Unit,
    onLanguage: (String) -> Unit,
    onTheme: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val pal = LocalPalette.current
    val prefs = remember { context.getSharedPreferences("settings", Context.MODE_PRIVATE) }
    val updater = remember { FilterListUpdater(context) }
    val tick = rememberTick()
    var refresh by remember { mutableIntStateOf(0) }

    var blockAds by remember { mutableStateOf(AppPrefs.blockAds) }
    var blockPopups by remember { mutableStateOf(AppPrefs.blockPopups) }
    var blockTrackers by remember { mutableStateOf(AppPrefs.blockTrackers) }
    var blockAnnoying by remember { mutableStateOf(AppPrefs.blockAnnoying) }
    var faster by remember { mutableStateOf(AppPrefs.fasterBrowsing) }
    var privacy by remember { mutableStateOf(AppPrefs.enhancedPrivacy) }
    var notifications by remember { mutableStateOf(AppPrefs.notifications) }
    var engine by remember { mutableStateOf(AppPrefs.searchEngine) }
    var autoLevel by remember { mutableIntStateOf(AppPrefs.autoLevel) }
    var filterUpstream by remember { mutableStateOf(AppPrefs.filteringUpstream) }
    var startOnBoot by remember { mutableStateOf(AppPrefs.startOnBoot(context)) }
    var jsEnabled by remember { mutableStateOf(prefs.getBoolean("js", false)) }
    var browserBlock by remember { mutableStateOf(prefs.getBoolean("browser_block", true)) }
    var guardOn by remember { mutableStateOf(AppPrefs.browserGuard) }
    val isPro = remember(tick) { License.isPro }
    val proOnlyMsg = tr("This needs Ad Blocker Pro", "මේ සඳහා Ad Blocker Pro අවශ්‍යයි")
    val guardEnabled = remember(tick) { BrowserGuardService.isEnabled(context) }
    val guardClosed = remember(tick) { AppPrefs.guardClosed(context) }

    var dialog by remember { mutableStateOf<String?>(null) }
    var updating by remember { mutableStateOf(false) }
    var statusOverride by remember { mutableStateOf<String?>(null) }
    var testResult by remember { mutableStateOf<String?>(null) }
    var testing by remember { mutableStateOf(false) }

    val info by produceState(FilterInfo(), tick, refresh) {
        value = withContext(Dispatchers.IO) { FilterInfo(db.filterCount(), db.lastUpdateMillis()) }
    }
    val filterStatus = statusOverride
        ?: if (info.lastUpdate > 0L) "${info.count} domains • ${formatTime(info.lastUpdate)}"
        else tr("No filter list downloaded yet", "Filter list තවම බාගත කර නැත")
    val version = remember {
        try { context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "" } catch (e: Exception) { "" }
    }
    val clearedMsg = tr("Browsing data cleared", "බ්‍රවුස් දත්ත මකා දැමුවා")

    Column(Modifier.fillMaxSize()) {
        SubHeader(tr("Settings", "සැකසුම්"), onBack) { ProPill(onPro) }
        Column(
            Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            SectionCard(Icons.Default.VerifiedUser, tr("Ad Blocking", "දැන්වීම් අවහිර කිරීම")) {
                ToggleItem({ AdBadge(30.dp) }, tr("Block Ads", "දැන්වීම් අවහිර කරන්න"),
                    tr("Remove banner, video and display ads", "බැනර්, වීඩියෝ සහ display දැන්වීම් ඉවත් කරන්න"), blockAds) {
                    blockAds = it; AppPrefs.setFlag(context, "block_ads", it)
                }
                SoftDivider(Modifier.padding(horizontal = 14.dp))
                ToggleItem({ PopupIcon(30.dp) }, tr("Block Pop-ups", "පොප්-අප් අවහිර කරන්න"),
                    tr("Stop annoying pop-up windows", "කරදරකාරී පොප්-අප් කවුළු නවත්වන්න"), blockPopups) {
                    blockPopups = it; AppPrefs.setFlag(context, "block_popups", it)
                }
                SoftDivider(Modifier.padding(horizontal = 14.dp))
                ToggleItem({ Icon(Icons.Default.GpsFixed, null, tint = pal.primary, modifier = Modifier.size(28.dp)) },
                    tr("Block Trackers", "ට්‍රැකර් අවහිර කරන්න"),
                    tr("Prevent websites from tracking you", "වෙබ් අඩවි ඔබව ට්‍රැක් කිරීම වළක්වන්න"), blockTrackers) {
                    blockTrackers = it; AppPrefs.setFlag(context, "block_trackers", it)
                }
                SoftDivider(Modifier.padding(horizontal = 14.dp))
                ToggleItem({ Icon(Icons.Default.Layers, null, tint = pal.primary, modifier = Modifier.size(28.dp)) },
                    tr("Block Annoying Elements", "කරදරකාරී අංග අවහිර කරන්න"),
                    tr("Hide overlays, cookie notices and more", "overlay, cookie දැනුම්දීම් සහ තවත් සඟවන්න"), blockAnnoying) {
                    blockAnnoying = it; AppPrefs.setFlag(context, "block_annoying", it)
                }
            }

            SectionCard(Icons.Default.Block, tr("Phone Browser Pop-ups", "ෆෝන් බ්‍රවුසරයේ පොප්-අප්")) {
                ToggleItem({ PopupIcon(30.dp) }, tr("Browser Pop-up Guard", "බ්‍රවුසර් පොප්-අප් ආරක්ෂකය"),
                    if (!isPro) tr(
                        "Pro feature. Tap here to unlock it.",
                        "Pro අංගයකි. අගුළු හැරීමට මෙහි ඔබන්න."
                    ) else if (guardEnabled) tr(
                        "Active in Chrome, Samsung Internet, Firefox, Brave and more. Ad pages closed: $guardClosed",
                        "Chrome, Samsung Internet, Firefox, Brave ආදියේ ක්‍රියාත්මකයි. වසා දැමූ දැන්වීම් පිටු: $guardClosed"
                    ) else tr(
                        "Not active yet. Turn it on in Accessibility settings (button below).",
                        "තවම ක්‍රියාත්මක නැත. Accessibility සැකසුම්වල ක්‍රියාත්මක කරන්න (පහත බොත්තම)."
                    ), guardOn && isPro) {
                    if (!isPro) {
                        Toast.makeText(context, proOnlyMsg, Toast.LENGTH_SHORT).show()
                        onPro()
                    } else {
                        guardOn = it; AppPrefs.setFlag(context, "browser_guard", it)
                    }
                }
                SoftDivider(Modifier.padding(horizontal = 14.dp))
                LinkItem({ Icon(Icons.Default.Lock, null, tint = pal.primary, modifier = Modifier.size(28.dp)) },
                    tr("Turn on in Accessibility settings", "Accessibility සැකසුම්වල ක්‍රියාත්මක කරන්න"),
                    tr("Needed once. Tap to read what it does first.", "එක් වරක් අවශ්‍යයි. මුලින් එය කරන දේ කියවීමට ඔබන්න."),
                    value = if (guardEnabled) tr("On", "සක්‍රීයයි") else tr("Off", "අක්‍රීයයි")
                ) {
                    if (isPro) dialog = "guard" else { Toast.makeText(context, proOnlyMsg, Toast.LENGTH_SHORT).show(); onPro() }
                }
            }

            SectionCard(Icons.Default.FlashOn, tr("Browsing & Performance", "බ්‍රවුස් කිරීම සහ ක්‍රියාකාරිත්වය")) {
                ToggleItem({ Icon(Icons.Default.RocketLaunch, null, tint = pal.primary, modifier = Modifier.size(28.dp)) },
                    tr("Faster Browsing", "වේගවත් බ්‍රවුස් කිරීම"),
                    tr("Load websites faster using the page cache", "page cache භාවිතයෙන් වෙබ් අඩවි වේගයෙන් පූරණය කරන්න"), faster) {
                    faster = it; AppPrefs.setFlag(context, "faster_browsing", it)
                }
                SoftDivider(Modifier.padding(horizontal = 14.dp))
                LinkItem({ Icon(Icons.Default.FileDownload, null, tint = pal.primary, modifier = Modifier.size(28.dp)) },
                    tr("Allow Ads on Trusted Sites", "විශ්වාසදායක අඩවිවල දැන්වීම්වලට ඉඩ දෙන්න"),
                    tr("Turn off ad blocking for selected websites", "තෝරාගත් වෙබ් අඩවි සඳහා දැන්වීම් අවහිර කිරීම ක්‍රියාවිරහිත කරන්න")
                ) { onOpen(Screen.WHITELIST) }
            }

            SectionCard(Icons.Default.Lock, tr("Privacy & Security", "පෞද්ගලිකත්වය සහ ආරක්ෂාව")) {
                ToggleItem({ Icon(Icons.Default.VerifiedUser, null, tint = pal.primary, modifier = Modifier.size(28.dp)) },
                    tr("Enhanced Privacy", "වැඩිදියුණු කළ පෞද්ගලිකත්වය"),
                    tr("Protect your data and online identity", "ඔබේ දත්ත සහ ඔන්ලයින් අනන්‍යතාව ආරක්ෂා කරන්න"), privacy) {
                    privacy = it; AppPrefs.setFlag(context, "enhanced_privacy", it)
                }
                SoftDivider(Modifier.padding(horizontal = 14.dp))
                LinkItem({ Icon(Icons.Default.Delete, null, tint = pal.primary, modifier = Modifier.size(28.dp)) },
                    tr("Clear Browsing Data", "බ්‍රවුස් දත්ත මකන්න"),
                    tr("History, cookies, cache and site data", "ඉතිහාසය, cookies, cache සහ අඩවි දත්ත")
                ) { dialog = "clear" }
            }

            SectionCard(Icons.Default.Tune, tr("General", "පොදු")) {
                LinkItem({ Icon(Icons.Default.Public, null, tint = pal.primary, modifier = Modifier.size(28.dp)) },
                    tr("Default Search Engine", "පෙරනිමි සෙවුම් යන්ත්‍රය"), value = SearchEngines.label(engine)
                ) { dialog = "engine" }
                SoftDivider(Modifier.padding(horizontal = 14.dp))
                LinkItem({ Icon(Icons.Default.Palette, null, tint = pal.primary, modifier = Modifier.size(28.dp)) },
                    tr("App Theme", "යෙදුම් තේමාව"),
                    value = (Palettes[theme]?.name ?: "Purple") + if (theme == "purple") tr(" (Default)", " (පෙරනිමි)") else ""
                ) { dialog = "theme" }
                SoftDivider(Modifier.padding(horizontal = 14.dp))
                LinkItem({ Icon(Icons.Default.Language, null, tint = pal.primary, modifier = Modifier.size(28.dp)) },
                    tr("Language", "භාෂාව"), value = AppLanguages.firstOrNull { it.first == language }?.second ?: "English"
                ) { dialog = "language" }
                SoftDivider(Modifier.padding(horizontal = 14.dp))
                ToggleItem({ Icon(Icons.Default.Notifications, null, tint = pal.primary, modifier = Modifier.size(28.dp)) },
                    tr("Notifications", "දැනුම්දීම්"),
                    tr("Get important updates and alerts", "වැදගත් යාවත්කාලීන සහ ඇඟවීම් ලබා ගන්න"), notifications) {
                    notifications = it; AppPrefs.setFlag(context, "notifications", it)
                }
                SoftDivider(Modifier.padding(horizontal = 14.dp))
                LinkItem({ Icon(Icons.Default.Info, null, tint = pal.primary, modifier = Modifier.size(28.dp)) },
                    tr("About Ad Blocker", "Ad Blocker ගැන"), tr("Version ", "අනුවාදය ") + version
                ) { dialog = "about" }
            }

            // Everything below existed before the redesign and is kept as it was.
            SectionCard(Icons.Default.Settings, tr("Advanced", "උසස්")) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(tr("Automatic ad blocking", "ස්වයංක්‍රීය දැන්වීම් අවහිර කිරීම"), color = Ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(tr("Off", "නැත"), tr("Balanced", "සමතුලිත"), tr("Strong", "ශක්තිමත්")).forEachIndexed { index, label ->
                            PillChip(if (index == 2 && !isPro) "$label 🔒" else label, autoLevel == index, {
                                if (index == 2 && !isPro) {
                                    Toast.makeText(context, proOnlyMsg, Toast.LENGTH_SHORT).show()
                                    onPro()
                                } else {
                                    autoLevel = index
                                    AppPrefs.setAutoLevel(context, index)
                                }
                            })
                        }
                    }
                    Text(
                        when (autoLevel) {
                            0 -> tr("Only the downloaded lists are used.", "බාගත කළ lists පමණක් භාවිතා වේ.")
                            1 -> tr(
                                "Also blocks names that clearly look like ad servers (ads.*, adserver*, banners.*) and aliases that hide them.",
                                "දැන්වීම් සේවාදායක ලෙස පැහැදිලිව පෙනෙන නම් (ads.*, adserver*, banners.*) සහ ඒවා සඟවන aliases ද අවහිර කරයි."
                            )
                            else -> tr(
                                "Strongest: also blocks analytics/tracker names, ad networks by company name, and names that show up right after other ads from the same app. Allow a name in the DNS Log if something breaks.",
                                "ශක්තිමත්ම: analytics/ට්‍රැකර් නම්, සමාගම් නමින් දැන්වීම් ජාල සහ එකම යෙදුමෙන් වෙනත් දැන්වීම් පසුව එන නම් ද අවහිර කරයි. යමක් කැඩුනොත් DNS Log එකේ ඒ නමට ඉඩ දෙන්න."
                            )
                        },
                        color = Muted, fontSize = 12.sp, lineHeight = 16.sp
                    )
                }
                SoftDivider(Modifier.padding(horizontal = 14.dp))
                ToggleItem({ Icon(Icons.Default.Public, null, tint = pal.primary, modifier = Modifier.size(28.dp)) },
                    tr("Ask AdGuard DNS first", "AdGuard DNS මුලින් අසන්න"),
                    tr("Extra filtering: it refuses ad names the lists miss. Off = Cloudflare only.", "අමතර පෙරීම: lists මඟහරින දැන්වීම් නම් එය ප්‍රතික්ෂේප කරයි. Off = Cloudflare පමණි."), filterUpstream) {
                    filterUpstream = it; AppPrefs.setFilteringUpstream(context, it)
                }
                SoftDivider(Modifier.padding(horizontal = 14.dp))
                ToggleItem({ Icon(Icons.Default.Refresh, null, tint = pal.primary, modifier = Modifier.size(28.dp)) },
                    tr("Start on phone restart", "දුරකථනය නැවත ආරම්භ වූ විට පටන් ගන්න"),
                    tr("Switch protection back on after a reboot", "නැවත ආරම්භ වූ පසු ආරක්ෂාව නැවත ක්‍රියාත්මක කරන්න"), startOnBoot) {
                    startOnBoot = it; AppPrefs.setStartOnBoot(context, it)
                }
                SoftDivider(Modifier.padding(horizontal = 14.dp))
                ToggleItem({ Icon(Icons.Default.Layers, null, tint = pal.primary, modifier = Modifier.size(28.dp)) },
                    tr("Block ads in browser", "බ්‍රවුසරයේ දැන්වීම් අවහිර කරන්න"),
                    tr("Use the filter list inside the built-in browser", "ඇතුළත් බ්‍රවුසරයේ filter list භාවිතා කරන්න"), browserBlock) {
                    browserBlock = it; prefs.edit().putBoolean("browser_block", it).apply()
                }
                SoftDivider(Modifier.padding(horizontal = 14.dp))
                ToggleItem({ Icon(Icons.Default.FlashOn, null, tint = pal.primary, modifier = Modifier.size(28.dp)) },
                    tr("JavaScript in browser", "බ්‍රවුසරයේ JavaScript"),
                    tr("Off by default for safer browsing. Many sites need it, and cookie-notice hiding only works with it on.", "ආරක්ෂිත බ්‍රවුස් කිරීම සඳහා පෙරනිමියෙන් off. බොහෝ අඩවි වලට එය අවශ්‍යයි; cookie දැනුම්දීම් සැඟවීමටත් එය on විය යුතුයි."), jsEnabled) {
                    jsEnabled = it; prefs.edit().putBoolean("js", it).apply()
                }
                SoftDivider(Modifier.padding(horizontal = 14.dp))
                LinkItem({ Icon(Icons.Default.Layers, null, tint = pal.primary, modifier = Modifier.size(28.dp)) },
                    tr("DNS Log & Rules", "DNS Log සහ නීති"),
                    tr("See what each app contacts and block ad domains yourself", "එක් එක් යෙදුම සම්බන්ධ වන දේ බලා ඔබම දැන්වීම් domain අවහිර කරන්න")
                ) { onOpen(Screen.LOG) }
                SoftDivider(Modifier.padding(horizontal = 14.dp))
                LinkItem({ Icon(Icons.Default.VerifiedUser, null, tint = pal.primary, modifier = Modifier.size(28.dp)) },
                    if (testing) tr("Testing...", "පරීක්ෂා කරමින්...") else tr("Test ad blocking", "දැන්වීම් අවහිර කිරීම පරීක්ෂා කරන්න"),
                    testResult ?: tr("Checks that ad domains are really being blocked on this phone", "මෙම දුරකථනයේ දැන්වීම් domain සැබෑවටම අවහිර වේදැයි පරීක්ෂා කරයි")
                ) {
                    if (!testing) {
                        testing = true
                        scope.launch {
                            testResult = withContext(Dispatchers.IO) { runBlockingTest(vpnOn, info.count) }
                            testing = false
                        }
                    }
                }
                SoftDivider(Modifier.padding(horizontal = 14.dp))
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(tr("Filter list", "Filter list"), color = Ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                    Text(filterStatus, color = Muted, fontSize = 12.5.sp)
                    val shape = RoundedCornerShape(50)
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .clip(shape)
                            .background(Brush.horizontalGradient(listOf(pal.primary, pal.dark)))
                            .clickable(enabled = !updating) {
                                updating = true
                                statusOverride = "Downloading and validating filter list…"
                                updater.update { result ->
                                    updating = false
                                    statusOverride = result.fold(
                                        { count -> "$count domains • ${formatTime(System.currentTimeMillis())}" },
                                        { error -> "Update failed: ${error.message ?: "unknown error"}" }
                                    )
                                    refresh++
                                }
                            }
                            .padding(vertical = 13.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            if (updating) tr("Updating…", "යාවත්කාලීන වෙමින්…") else tr("Update Filter List Now", "Filter list දැන් යාවත්කාලීන කරන්න"),
                            color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp
                        )
                    }
                    Text(
                        tr("Automatic updates run about every 3 days when a network is available (the lists are about 15 MB).",
                            "ජාලයක් තිබෙන විට දින 3කට වරක් පමණ ස්වයංක්‍රීයව යාවත්කාලීන වේ (lists ආසන්න වශයෙන් MB 15ක්)."),
                        color = Muted, fontSize = 11.5.sp
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
        }
    }

    when (dialog) {
        "engine" -> ChoiceDialog(
            tr("Default Search Engine", "පෙරනිමි සෙවුම් යන්ත්‍රය"),
            SearchEngines.all.map { it.first to it.second }, engine,
            onPick = { engine = it; AppPrefs.setText(context, "search_engine", it); dialog = null },
            onDismiss = { dialog = null }
        )
        "theme" -> ChoiceDialog(
            tr("App Theme", "යෙදුම් තේමාව"),
            Palettes.map { (key, p) -> key to (p.name + if (key == "purple") tr(" (Default)", " (පෙරනිමි)") else "") }, theme,
            onPick = { onTheme(it); dialog = null },
            onDismiss = { dialog = null }
        )
        "language" -> ChoiceDialog(
            tr("Language", "භාෂාව"), AppLanguages, language,
            onPick = { onLanguage(it); dialog = null },
            onDismiss = { dialog = null }
        )
        "clear" -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text(tr("Clear Browsing Data", "බ්‍රවුස් දත්ත මකන්න")) },
            text = { Text(tr("History, cookies, cache and site data of the built-in browser will be deleted.", "ඇතුළත් බ්‍රවුසරයේ ඉතිහාසය, cookies, cache සහ අඩවි දත්ත මැකෙනු ඇත.")) },
            confirmButton = {
                TextButton(onClick = {
                    clearBrowsingData(context)
                    Toast.makeText(context, clearedMsg, Toast.LENGTH_SHORT).show()
                    dialog = null
                }) { Text(tr("Clear", "මකන්න")) }
            },
            dismissButton = { TextButton(onClick = { dialog = null }) { Text(tr("Cancel", "අවලංගු")) } }
        )
        "guard" -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text(tr("Browser Pop-up Guard", "බ්‍රවුසර් පොප්-අප් ආරක්ෂකය")) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(tr(
                        "When an ad tab or redirect opens an address this blocker already refuses, the guard presses Back so the pop-up tab closes (or you return to the page you were on).",
                        "දැන්වීම් tab එකක් හෝ redirect එකක් මෙම blocker දැනටමත් අවහිර කරන ලිපිනයකට ගිය විට, ආරක්ෂකය Back එබීමෙන් පොප්-අප් tab එක වසයි (නැතහොත් ඔබ සිටි පිටුවට ආපසු යයි)."
                    ))
                    Text(tr(
                        "Privacy: it reads only the address bar of the phone's browsers, in memory. Nothing is saved or sent anywhere. It cannot see page content, passwords or other apps.",
                        "පෞද්ගලිකත්වය: එය කියවන්නේ දුරකථන බ්‍රවුසරවල address bar එක පමණි, මතකයේ පමණක්. කිසිවක් ගබඩා කිරීමක් හෝ යැවීමක් නැත. පිටුවේ අන්තර්ගතය, මුරපද හෝ වෙනත් යෙදුම් එයට නොපෙනේ."
                    ))
                    Text(tr(
                        "Limit: it only catches addresses the blocker knows. A pop-up to a brand-new, unlisted address is not closed. Also keep Chrome > Settings > Site settings > Pop-ups and redirects set to Blocked.",
                        "සීමාව: blocker එක දන්නා ලිපින පමණක් අල්ලයි. ලැයිස්තුගත නොවූ අලුත් ලිපිනයකට යන පොප්-අප් වැසෙන්නේ නැත. Chrome > Settings > Site settings > Pop-ups and redirects ද Blocked ලෙස තබන්න."
                    ))
                    Text(tr(
                        "Steps: open Accessibility > Installed apps (or Downloaded apps) > Ad Blocker – Browser Pop-up Guard > On. On Android 13+ this app was installed from outside the Play Store, so first open Settings > Apps > Ad Blocker > ⋮ (top right) > Allow restricted settings.",
                        "පියවර: Accessibility > Installed apps (හෝ Downloaded apps) > Ad Blocker – Browser Pop-up Guard > On. Android 13+ හි මෙම යෙදුම Play Store එකෙන් පිටත සවි කළ නිසා, මුලින් Settings > Apps > Ad Blocker > ⋮ (ඉහළ දකුණ) > Allow restricted settings ඔබන්න."
                    ))
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    dialog = null
                    try {
                        context.startActivity(
                            Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    } catch (e: Exception) { }
                }) { Text(tr("Open settings", "සැකසුම් විවෘත කරන්න")) }
            },
            dismissButton = { TextButton(onClick = { dialog = null }) { Text(tr("Cancel", "අවලංගු")) } }
        )
        "about" -> {
            val report = remember { CrashLog.read(context) }
            AlertDialog(
                onDismissRequest = { dialog = null },
                title = { Text("Ad Blocker") },
                text = {
                    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            tr(
                                "Version $version (" + (if (isPro) "Pro" else "Free") + ")\nDNS-based ad, pop-up and tracker blocking. No account and no analytics. Blocked domains are stored only on this phone.",
                                "අනුවාදය $version (" + (if (isPro) "Pro" else "Free") + ")\nDNS මත පදනම් වූ දැන්වීම්, පොප්-අප් සහ ට්‍රැකර් අවහිර කිරීම. ගිණුමක් හෝ analytics නැත. අවහිර කළ domains ගබඩා වන්නේ මෙම දුරකථනයේ පමණි."
                            )
                        )
                        if (report != null) {
                            Text(tr("Last problem report:", "අවසාන ගැටලු වාර්තාව:"), fontWeight = FontWeight.Bold)
                            Text(report.take(1500), fontSize = 10.sp, lineHeight = 13.sp)
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { dialog = null }) { Text(tr("Close", "වසන්න")) } },
                dismissButton = {
                    if (report != null) {
                        TextButton(onClick = {
                            (context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                                .setPrimaryClip(ClipData.newPlainText("report", report))
                            CrashLog.clear(context)
                            dialog = null
                        }) { Text(tr("Copy & clear", "පිටපත් කර මකන්න")) }
                    }
                }
            )
        }
    }
}
