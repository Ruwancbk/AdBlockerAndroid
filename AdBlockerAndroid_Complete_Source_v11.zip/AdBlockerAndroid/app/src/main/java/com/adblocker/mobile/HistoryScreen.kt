package com.adblocker.mobile

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.DateFormat
import java.util.Date
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private class HistoryData(
    val events: List<BlockedEvent> = emptyList(),
    val total: Long = 0L
)

private class DayGroup(val daysAgo: Int, val total: Int, val items: List<BlockedEvent>)

private const val PER_DAY_LIMIT = 100

@Composable
private fun KindIcon(kind: String, size: androidx.compose.ui.unit.Dp) {
    val pal = LocalPalette.current
    when (kind) {
        EventKind.POPUP -> PopupIcon(size)
        EventKind.TRACKER -> Icon(Icons.Default.GpsFixed, null, tint = pal.primary, modifier = Modifier.size(size))
        EventKind.OTHER -> Icon(Icons.Default.Layers, null, tint = pal.primary, modifier = Modifier.size(size))
        else -> AdBadge(size)
    }
}

@Composable
private fun kindTitle(kind: String): String = when (kind) {
    EventKind.POPUP -> tr("Pop-up Blocked", "පොප්-අප් අවහිර කළා")
    EventKind.TRACKER -> tr("Tracker Blocked", "ට්‍රැකර් අවහිර කළා")
    EventKind.OTHER -> tr("Ad Script Blocked", "දැන්වීම් script අවහිර කළා")
    else -> tr("Ad Blocked", "දැන්වීම අවහිර කළා")
}

@Composable
fun HistoryScreen(db: AdBlockerDatabase, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val tick = rememberTick()
    var reload by remember { mutableIntStateOf(0) }
    var filter by remember { mutableIntStateOf(0) } // 0 all, 1 ads, 2 pop-ups, 3 trackers, 4 others
    var confirmClear by remember { mutableStateOf(false) }

    val data by produceState(HistoryData(), tick, reload) {
        value = withContext(Dispatchers.IO) {
            db.flushEvents()
            val events = db.eventsSince(0L)
            HistoryData(events, maxOf(db.eventCount(), events.size.toLong()))
        }
    }

    val kinds = remember(data) { data.events.map { EventKind.classify(it.domain) } }
    val popups = kinds.count { it == EventKind.POPUP }.toLong()
    val trackers = kinds.count { it == EventKind.TRACKER }.toLong()
    val otherAds = (data.total - popups - trackers).coerceAtLeast(0L)

    val wanted = when (filter) { 1 -> EventKind.AD; 2 -> EventKind.POPUP; 3 -> EventKind.TRACKER; 4 -> EventKind.OTHER; else -> null }
    val groups = remember(data, filter) {
        val filtered = data.events.filter { wanted == null || EventKind.classify(it.domain) == wanted }
        filtered.groupBy { Fmt.daysAgo(it.timestamp) }
            .toSortedMap()
            .map { (ago, list) -> DayGroup(ago, list.size, list.take(PER_DAY_LIMIT)) }
    }

    Column(Modifier.fillMaxSize()) {
        SubHeader(tr("Blocked Items History", "අවහිර කළ අයිතම ඉතිහාසය"), onBack) {
            Box(
                Modifier.size(40.dp).androidClick { confirmClear = true },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Default.Delete, "Clear", tint = Ink, modifier = Modifier.size(28.dp)) }
        }
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth().padding(horizontal = 14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(
                        tr("All", "සියල්ල"), tr("Ads", "දැන්වීම්"), tr("Pop-ups", "පොප්-අප්"),
                        tr("Trackers", "ට්‍රැකර්"), tr("Others", "වෙනත්")
                    ).forEachIndexed { i, label -> PillChip(label, filter == i, { filter = i }) }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SummaryCard(Modifier.weight(1f), { AdBadge(34.dp) }, Fmt.count(data.total), tr("Total Blocked", "මුළු\nඅවහිර"))
                    SummaryCard(Modifier.weight(1f), { PopupIcon(34.dp) }, Fmt.count(popups), tr("Pop-ups", "පොප්-අප්"))
                    SummaryCard(
                        Modifier.weight(1f),
                        { Icon(Icons.Default.GpsFixed, null, tint = LocalPalette.current.primary, modifier = Modifier.size(32.dp)) },
                        Fmt.count(trackers), tr("Trackers", "ට්‍රැකර්")
                    )
                    SummaryCard(
                        Modifier.weight(1f),
                        { Icon(Icons.Default.Layers, null, tint = LocalPalette.current.primary, modifier = Modifier.size(32.dp)) },
                        Fmt.count(otherAds), tr("Other Ads", "වෙනත්\nදැන්වීම්")
                    )
                }
            }
            if (groups.isEmpty()) {
                item {
                    SoftCard(Modifier.fillMaxWidth()) {
                        Text(
                            tr("No blocked items recorded yet. Turn Ad Blocking ON and browse.", "අවහිර කළ අයිතම තවම නැත. Ad Blocking ON කර බ්‍රවුස් කරන්න."),
                            color = Muted, fontSize = 15.sp, modifier = Modifier.padding(20.dp)
                        )
                    }
                }
            }
            items(groups) { group -> DayCard(group, db, context, onChanged = { reload++ }) }
            item { Spacer(Modifier.height(12.dp)) }
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text(tr("Clear history?", "ඉතිහාසය මකන්නද?")) },
            text = { Text(tr("All blocked items and the statistics built from them will be deleted.", "අවහිර කළ සියලු අයිතම සහ ඒවායින් ගොඩනැගූ සංඛ්‍යාලේඛන මැකෙනු ඇත.")) },
            confirmButton = {
                TextButton(onClick = {
                    confirmClear = false
                    scope.launch {
                        withContext(Dispatchers.IO) { db.clearHistory() }
                        reload++
                    }
                }) { Text(tr("Clear", "මකන්න")) }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text(tr("Cancel", "අවලංගු")) } }
        )
    }
}

@Composable
private fun SummaryCard(modifier: Modifier, icon: @Composable () -> Unit, value: String, label: String) {
    SoftCard(modifier, shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.fillMaxWidth().padding(vertical = 12.dp, horizontal = 2.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(36.dp), contentAlignment = Alignment.Center) { icon() }
            Spacer(Modifier.height(4.dp))
            Text(value, color = Ink, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, maxLines = 1)
            Text(
                label, color = Muted, fontSize = 11.5.sp, lineHeight = 14.sp, maxLines = 2,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }
    }
}

@Composable
private fun DayCard(group: DayGroup, db: AdBlockerDatabase, context: Context, onChanged: () -> Unit) {
    val sinhala = LocalLang.current == "si"
    val title = when (group.daysAgo) {
        0 -> tr("Today", "අද")
        1 -> tr("Yesterday", "ඊයේ")
        else -> DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(Fmt.startOfDay(group.daysAgo)))
    }
    val timeFormat = remember { DateFormat.getTimeInstance(DateFormat.SHORT) }
    SoftCard(Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth().padding(bottom = 6.dp)) {
            Row(Modifier.fillMaxWidth().padding(16.dp, 14.dp, 14.dp, 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(title, color = Ink, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp, modifier = Modifier.weight(1f))
                InfoPill(tr("Total: ", "මුළු: ") + Fmt.count(group.total.toLong()) + tr(" Blocked", " අවහිර"))
            }
            group.items.forEachIndexed { index, event ->
                if (index > 0) SoftDivider(Modifier.padding(horizontal = 16.dp))
                HistoryRow(event, timeFormat.format(Date(event.timestamp)), db, context, onChanged)
            }
            if (group.total > group.items.size) {
                Text(
                    if (sinhala) "අලුත්ම ${group.items.size} පමණක් පෙන්වයි" else "Showing the latest ${group.items.size}",
                    color = Muted, fontSize = 12.sp, modifier = Modifier.padding(16.dp, 8.dp)
                )
            }
        }
    }
}

@Composable
private fun HistoryRow(event: BlockedEvent, time: String, db: AdBlockerDatabase, context: Context, onChanged: () -> Unit) {
    val scope = rememberCoroutineScope()
    val allowedMsg = tr("Site allowed", "අඩවියට ඉඩ දුන්නා")
    val invalidMsg = tr("Could not add this domain", "මෙම domain එක එක් කළ නොහැක")
    val kind = remember(event.domain) { EventKind.classify(event.domain) }
    var menu by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
        IconBubble(44.dp) { KindIcon(kind, 28.dp) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(kindTitle(kind), color = Ink, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
            Text("https://" + event.domain, color = Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.width(8.dp))
        Text(time, color = Muted, fontSize = 13.sp, maxLines = 1)
        Box {
            Box(Modifier.size(36.dp).androidClick { menu = true }, contentAlignment = Alignment.Center) {
                Icon(Icons.Default.MoreVert, "More", tint = Ink, modifier = Modifier.size(22.dp))
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(
                    text = { Text(tr("Allow this site", "මෙම අඩවියට ඉඩ දෙන්න")) },
                    onClick = {
                        menu = false
                        scope.launch {
                            val ok = withContext(Dispatchers.IO) { db.addAllowedDomain(event.domain) }
                            Toast.makeText(context, if (ok) allowedMsg else invalidMsg, Toast.LENGTH_SHORT).show()
                            onChanged()
                        }
                    }
                )
                DropdownMenuItem(
                    text = { Text(tr("Copy domain", "domain පිටපත් කරන්න")) },
                    onClick = {
                        menu = false
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("domain", event.domain))
                    }
                )
            }
        }
    }
}

private fun Modifier.androidClick(onClick: () -> Unit): Modifier =
    this.then(Modifier.clip(androidx.compose.foundation.shape.CircleShape)).then(
        Modifier.clickable(onClick = onClick)
    )
