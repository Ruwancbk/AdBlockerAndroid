package com.adblocker.mobile

import android.content.ContentValues
import android.content.Context
import android.database.DatabaseUtils
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicInteger

data class BlockedEvent(val domain: String, val category: String, val timestamp: Long)

/**
 * Single shared instance (use [get]). WAL mode lets DNS lookups keep reading while a
 * large filter-list import is writing. Blocked events are queued in memory and written
 * in batches by [flushEvents], so the DNS threads never wait on a database write.
 */
class AdBlockerDatabase private constructor(context: Context) :
    SQLiteOpenHelper(context.applicationContext, "adblocker.db", null, 4) {

    private val importLock = Any()
    private val flushLock = Any()
    private val queue = ConcurrentLinkedQueue<BlockedEvent>()
    private val queued = AtomicInteger(0)

    init { setWriteAheadLoggingEnabled(true) }

    override fun onCreate(db: SQLiteDatabase) {
        createBlockedDomains(db)
        db.execSQL("CREATE TABLE allowed_domains(domain TEXT PRIMARY KEY, created_at INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE blocked_events(id INTEGER PRIMARY KEY AUTOINCREMENT, domain TEXT NOT NULL, category TEXT NOT NULL, created_at INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE metadata(key TEXT PRIMARY KEY, value TEXT NOT NULL)")
        db.execSQL("CREATE INDEX idx_events_created ON blocked_events(created_at DESC)")
        createAutoRules(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("CREATE TABLE IF NOT EXISTS allowed_domains(domain TEXT PRIMARY KEY, created_at INTEGER NOT NULL)")
        }
        if (oldVersion < 3) {
            // v3 keeps one row per (domain, list) so several filter lists can share a domain.
            // The old list is dropped and downloaded again automatically.
            db.execSQL("DROP TABLE IF EXISTS blocked_domains")
            createBlockedDomains(db)
            db.execSQL("DELETE FROM metadata WHERE key IN ('last_filter_update', 'filter_source', 'filter_count')")
        }
        if (oldVersion < 4) createAutoRules(db)
    }

    private fun createAutoRules(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS auto_rules(domain TEXT PRIMARY KEY, score INTEGER NOT NULL, " +
                "why TEXT NOT NULL, app TEXT NOT NULL, created_at INTEGER NOT NULL)"
        )
    }

    private fun createBlockedDomains(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE blocked_domains(domain TEXT NOT NULL, source TEXT NOT NULL, " +
                "updated_at INTEGER NOT NULL, PRIMARY KEY(domain, source))"
        )
        db.execSQL("CREATE INDEX idx_blocked_source ON blocked_domains(source)")
    }

    // ---- filter list -------------------------------------------------------------

    fun replaceRemoteDomains(domains: Set<String>, source: String, markUpdated: Boolean = true) {
        synchronized(importLock) {
            val db = writableDatabase
            db.beginTransaction()
            try {
                db.delete("blocked_domains", "source = ?", arrayOf(source))
                val now = System.currentTimeMillis()
                val stmt = db.compileStatement(
                    "INSERT OR REPLACE INTO blocked_domains(domain, source, updated_at) VALUES(?, ?, ?)"
                )
                try {
                    for (domain in domains) {
                        stmt.clearBindings()
                        stmt.bindString(1, domain)
                        stmt.bindString(2, source)
                        stmt.bindLong(3, now)
                        stmt.executeInsert()
                    }
                } finally { stmt.close() }
                // Totals cover every installed list, not just the one that was refreshed.
                val distinct = DatabaseUtils.longForQuery(db, "SELECT COUNT(DISTINCT domain) FROM blocked_domains", null)
                val sources = ArrayList<String>()
                db.rawQuery("SELECT DISTINCT source FROM blocked_domains ORDER BY source", null).use {
                    while (it.moveToNext()) sources.add(it.getString(0))
                }
                if (markUpdated) setMetadata("last_filter_update", now.toString())
                setMetadata("filter_source", sources.joinToString(" + "))
                setMetadata("filter_count", distinct.toString())
                db.setTransactionSuccessful()
            } finally { db.endTransaction() }
        }
    }

    /** Allowlist entries cover subdomains too (allowing example.com allows a.example.com). */
    fun isDomainAllowed(host: String): Boolean = existsIn("allowed_domains", suffixes(host))

    /**
     * True when the browser pane (or anything else without an app) should refuse this host:
     * lists, learned rules and the name detector at the level chosen in Settings.
     */
    fun isDomainBlocked(host: String): Boolean =
        judge(host, AppPrefs.autoLevel, "", "").reason != null &&
            AppPrefs.kindEnabled(EventKind.classify(host))

    /** Result of [judge]. [score] is how ad-like the name looked (also filled for allowed names). */
    class Verdict(val reason: String?, val category: String, val score: Int)

    /**
     * Decides one lookup. Order: allowlist (always wins) > filter lists > learned rules >
     * name detection. A name that the detector blocks is remembered as a learned rule, so the
     * next lookup is answered from memory and the user can review it later.
     *
     * [level]: 0 = lists only, 1 = Balanced, 2 = Strong. [appId] feeds the "ad burst" signal.
     */
    fun judge(host: String, level: Int, appId: String, appLabel: String): Verdict {
        val normalized = normalizeHost(host)
        if (!normalized.contains('.')) return CLEAN
        val candidates = suffixes(normalized)
        if (existsIn("allowed_domains", candidates)) return CLEAN
        firstSource(candidates)?.let { return Verdict(it, "DNS", 100) }
        if (level <= 0) return CLEAN

        ensureAutoRules()
        AutoBlock.match(normalized, level)?.let { return Verdict("Auto-learned: ${it.why}", "Auto", it.score) }

        val detection = AdHeuristics.analyze(normalized) ?: return CLEAN
        var score = detection.score
        var why = detection.why
        if (level >= 2 && score >= AdHeuristics.SUSPECT_MIN &&
            AutoBlock.recentAdHits(appId, System.currentTimeMillis(), BURST_WINDOW_MS) >= 2
        ) {
            score += 25
            why += " + ad burst from the same app"
        }
        if (score >= AdHeuristics.thresholdFor(level)) {
            learnBlock(normalized, score, why, appId, appLabel)
            return Verdict("$SMART: $why", "Smart", score)
        }
        return Verdict(null, "DNS", score)
    }

    // ---- learned rules -----------------------------------------------------------

    @Volatile private var autoLoaded = false
    private val autoLock = Any()

    /** Loads the saved learned rules into memory once. Safe to call from any thread. */
    fun ensureAutoRules() {
        if (autoLoaded) return
        synchronized(autoLock) {
            if (autoLoaded) return
            try {
                AutoBlock.replaceAll(autoRulesFromDisk())
            } catch (e: Exception) {
                // Learned rules are an extra; lookups work without them.
            }
            autoLoaded = true
        }
    }

    /** Remembers a name as blocked. Returns false when it was already known or the store is full. */
    fun learnBlock(host: String, score: Int, why: String, appId: String, appLabel: String): Boolean {
        val domain = normalizeHost(host)
        if (!validDomain(domain)) return false
        ensureAutoRules()
        if (AutoBlock.size() >= AutoBlock.MAX_RULES) return false
        val rule = AutoRule(domain, score, why, appLabel.ifEmpty { appId }, System.currentTimeMillis())
        if (!AutoBlock.put(rule)) return false
        try {
            val values = ContentValues().apply {
                put("domain", rule.domain); put("score", rule.score); put("why", rule.why)
                put("app", rule.app); put("created_at", rule.time)
            }
            writableDatabase.insertWithOnConflict("auto_rules", null, values, SQLiteDatabase.CONFLICT_REPLACE)
        } catch (e: Exception) {
            // Still blocked in memory for this session.
        }
        return true
    }

    private fun autoRulesFromDisk(): List<AutoRule> {
        val list = ArrayList<AutoRule>()
        readableDatabase.rawQuery(
            "SELECT domain, score, why, app, created_at FROM auto_rules ORDER BY created_at DESC", null
        ).use { c ->
            while (c.moveToNext()) {
                list.add(AutoRule(c.getString(0), c.getInt(1), c.getString(2), c.getString(3), c.getLong(4)))
            }
        }
        return list
    }

    fun autoRules(): List<AutoRule> {
        ensureAutoRules()
        return AutoBlock.all()
    }

    fun removeAutoRule(host: String) {
        val domain = normalizeHost(host)
        AutoBlock.remove(domain)
        writableDatabase.delete("auto_rules", "domain = ?", arrayOf(domain))
    }

    /** "This one is fine": drops the learned rule and puts the name on the allowlist. */
    fun allowAutoRule(host: String) {
        removeAutoRule(host)
        addAllowedDomain(host)
    }

    fun clearAutoRules() {
        AutoBlock.clear()
        writableDatabase.delete("auto_rules", null, null)
    }

    private fun firstSource(values: List<String>): String? {
        if (values.isEmpty()) return null
        val placeholders = values.joinToString(",") { "?" }
        return readableDatabase.rawQuery(
            "SELECT source FROM blocked_domains WHERE domain IN ($placeholders) " +
                "ORDER BY CASE source WHEN '$CUSTOM' THEN 0 WHEN '${BuiltInFilters.SOURCE}' THEN 1 ELSE 2 END LIMIT 1",
            values.toTypedArray()
        ).use { if (it.moveToFirst()) it.getString(0) else null }
    }

    // ---- your own rules ---------------------------------------------------------

    /** Blocks a domain and everything under it. Survives list updates. */
    fun addCustomBlock(host: String): Boolean {
        val domain = normalizeHost(host)
        if (!validDomain(domain)) return false
        removeAllowedDomain(domain)
        val values = ContentValues().apply {
            put("domain", domain)
            put("source", CUSTOM)
            put("updated_at", System.currentTimeMillis())
        }
        writableDatabase.insertWithOnConflict("blocked_domains", null, values, SQLiteDatabase.CONFLICT_REPLACE)
        return true
    }

    fun removeCustomBlock(host: String) {
        writableDatabase.delete("blocked_domains", "domain = ? AND source = ?", arrayOf(normalizeHost(host), CUSTOM))
    }

    fun customBlocked(): List<String> {
        val list = ArrayList<String>()
        readableDatabase.rawQuery(
            "SELECT domain FROM blocked_domains WHERE source = ? ORDER BY domain", arrayOf(CUSTOM)
        ).use { while (it.moveToNext()) list.add(it.getString(0)) }
        return list
    }

    private fun suffixes(host: String): List<String> {
        val out = ArrayList<String>()
        var candidate = normalizeHost(host)
        while (candidate.contains('.')) {
            out.add(candidate)
            candidate = candidate.substringAfter('.')
        }
        return out
    }

    private fun existsIn(table: String, values: List<String>): Boolean {
        if (values.isEmpty()) return false
        val placeholders = values.joinToString(",") { "?" }
        return readableDatabase.rawQuery(
            "SELECT 1 FROM $table WHERE domain IN ($placeholders) LIMIT 1",
            values.toTypedArray()
        ).use { it.moveToFirst() }
    }

    // ---- allowlist ---------------------------------------------------------------

    fun addAllowedDomain(host: String): Boolean {
        val domain = normalizeHost(host)
        if (!validDomain(domain)) return false
        val values = ContentValues().apply {
            put("domain", domain); put("created_at", System.currentTimeMillis())
        }
        writableDatabase.insertWithOnConflict("allowed_domains", null, values, SQLiteDatabase.CONFLICT_REPLACE)
        return true
    }

    fun removeAllowedDomain(host: String) {
        writableDatabase.delete("allowed_domains", "domain = ?", arrayOf(normalizeHost(host)))
    }

    fun allowedDomains(): List<String> {
        val list = ArrayList<String>()
        readableDatabase.rawQuery("SELECT domain FROM allowed_domains ORDER BY domain", null).use {
            while (it.moveToNext()) list.add(it.getString(0))
        }
        return list
    }

    // ---- blocked events ----------------------------------------------------------

    /** Non-blocking: safe to call from DNS/WebView threads. */
    fun addBlockedEvent(domain: String, category: String) {
        if (queued.get() >= MAX_QUEUE) return
        queue.add(BlockedEvent(domain, category, System.currentTimeMillis()))
        queued.incrementAndGet()
    }

    /** Writes queued events in one transaction, updates the running total, trims history. */
    fun flushEvents() {
        synchronized(flushLock) {
            val batch = ArrayList<BlockedEvent>()
            while (true) {
                val event = queue.poll() ?: break
                queued.decrementAndGet()
                batch.add(event)
            }
            if (batch.isEmpty()) return
            val db = writableDatabase
            db.beginTransaction()
            try {
                val stmt = db.compileStatement(
                    "INSERT INTO blocked_events(domain, category, created_at) VALUES(?, ?, ?)"
                )
                try {
                    for (event in batch) {
                        stmt.clearBindings()
                        stmt.bindString(1, event.domain)
                        stmt.bindString(2, event.category)
                        stmt.bindLong(3, event.timestamp)
                        stmt.executeInsert()
                    }
                } finally { stmt.close() }
                val total = (getMetadata("total_blocked")?.toLongOrNull() ?: 0L) + batch.size
                setMetadata("total_blocked", total.toString())
                db.execSQL("DELETE FROM blocked_events WHERE id <= (SELECT MAX(id) FROM blocked_events) - $MAX_EVENTS")
                db.setTransactionSuccessful()
            } finally { db.endTransaction() }
        }
    }

    fun recentEvents(limit: Int = 100): List<BlockedEvent> {
        val result = ArrayList<BlockedEvent>()
        readableDatabase.rawQuery(
            "SELECT domain, category, created_at FROM blocked_events ORDER BY created_at DESC LIMIT ?",
            arrayOf(limit.coerceIn(1, 500).toString())
        ).use { c ->
            while (c.moveToNext()) result.add(BlockedEvent(c.getString(0), c.getString(1), c.getLong(2)))
        }
        return result
    }

    /** Events newer than [since] (millis), newest first. Used by Stats and History. */
    fun eventsSince(since: Long, limit: Int = 20000): List<BlockedEvent> {
        val result = ArrayList<BlockedEvent>()
        readableDatabase.rawQuery(
            "SELECT domain, category, created_at FROM blocked_events WHERE created_at >= ? " +
                "ORDER BY created_at DESC LIMIT ?",
            arrayOf(since.toString(), limit.coerceIn(1, 20000).toString())
        ).use { c ->
            while (c.moveToNext()) result.add(BlockedEvent(c.getString(0), c.getString(1), c.getLong(2)))
        }
        return result
    }

    /** Total blocked since install or last "Clear" (history list itself keeps the latest events only). */
    fun eventCount(): Long = (getMetadata("total_blocked")?.toLongOrNull() ?: 0L) + queued.get()

    fun clearHistory() {
        synchronized(flushLock) {
            while (queue.poll() != null) queued.decrementAndGet()
            writableDatabase.delete("blocked_events", null, null)
            setMetadata("total_blocked", "0")
        }
    }

    // ---- metadata ----------------------------------------------------------------

    fun filterCount(): Int = getMetadata("filter_count")?.toIntOrNull() ?: 0
    fun lastUpdateMillis(): Long = getMetadata("last_filter_update")?.toLongOrNull() ?: 0L
    fun filterSource(): String = getMetadata("filter_source") ?: "Not configured"

    fun setMetadata(key: String, value: String) {
        val values = ContentValues().apply { put("key", key); put("value", value) }
        writableDatabase.insertWithOnConflict("metadata", null, values, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun getMetadata(key: String): String? =
        readableDatabase.rawQuery("SELECT value FROM metadata WHERE key = ?", arrayOf(key)).use {
            if (it.moveToFirst()) it.getString(0) else null
        }

    companion object {
        const val CUSTOM = "Custom"
        const val SMART = "Smart detection"
        private const val BURST_WINDOW_MS = 2000L
        private val CLEAN = Verdict(null, "DNS", 0)
        private const val MAX_EVENTS = 20000
        private const val MAX_QUEUE = 2000

        @Volatile private var instance: AdBlockerDatabase? = null

        fun get(context: Context): AdBlockerDatabase =
            instance ?: synchronized(this) {
                instance ?: AdBlockerDatabase(context.applicationContext).also { instance = it }
            }

        fun normalizeHost(value: String): String = DomainUtil.normalizeHost(value)

        fun validDomain(host: String): Boolean = DomainUtil.validDomain(host)
    }
}
