package com.adblocker.mobile

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private class StatsData(
    val current: Long = 0L,
    val previous: Long? = null,
    /** Index 0 = today, 6 = six days ago. */
    val days: List<Int> = List(7) { 0 }
)

private fun loadStats(db: AdBlockerDatabase, period: Int): StatsData {
    db.flushEvents()
    val events = db.eventsSince(0L)
    val start = when (period) { 0 -> Fmt.startOfDay(0); 1 -> Fmt.startOfDay(6); 2 -> Fmt.startOfDay(29); else -> 0L }
    val prevStart = when (period) { 0 -> Fmt.startOfDay(1); 1 -> Fmt.startOfDay(13); 2 -> Fmt.startOfDay(59); else -> -1L }
    var current = 0L
    var previous = 0L
    val days = IntArray(7)
    for (e in events) {
        if (e.timestamp >= start) current++
        else if (prevStart >= 0L && e.timestamp >= prevStart) previous++
        val ago = Fmt.daysAgo(e.timestamp)
        if (ago in 0..6) days[ago]++
    }
    if (period == 3) current = maxOf(db.eventCount(), events.size.toLong())
    return StatsData(current, if (period == 3) null else previous, days.toList())
}

@Composable
fun StatsScreen(db: AdBlockerDatabase, onPro: () -> Unit) {
    val sinhala = LocalLang.current == "si"
    val pal = LocalPalette.current
    val scope = rememberCoroutineScope()
    val tick = rememberTick()
    var period by remember { mutableIntStateOf(0) }
    var reload by remember { mutableIntStateOf(0) }
    var menu by remember { mutableStateOf(false) }
    val data by produceState(StatsData(), tick, period, reload) {
        value = withContext(Dispatchers.IO) { loadStats(db, period) }
    }

    Column(Modifier.fillMaxSize()) {
        BrandHeader(onPro = onPro) {
            Box {
                RoundIconButton(Icons.Default.MoreVert, "More") { menu = true }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text(tr("Reset statistics", "සංඛ්‍යාලේඛන යළි සකසන්න")) },
                        onClick = {
                            menu = false
                            scope.launch {
                                withContext(Dispatchers.IO) { db.clearHistory() }
                                reload++
                            }
                        }
                    )
                }
            }
        }
        Column(
            Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.BarChart, null, tint = pal.primary, modifier = Modifier.size(34.dp))
                    Spacer(Modifier.width(10.dp))
                    Text(tr("Usage Statistics", "භාවිත සංඛ්‍යාලේඛන"), color = Ink, fontWeight = FontWeight.ExtraBold, fontSize = 25.sp)
                }
                Text(
                    tr("See how Ad Blocker is protecting you", "Ad Blocker ඔබව ආරක්ෂා කරන ආකාරය බලන්න"),
                    color = Muted, fontSize = 15.sp
                )
            }

            // Period tabs
            SoftCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(50)) {
                Row(Modifier.fillMaxWidth().padding(5.dp)) {
                    listOf(
                        tr("Today", "අද"), tr("7 Days", "දින 7"), tr("30 Days", "දින 30"), tr("All Time", "සියල්ල")
                    ).forEachIndexed { i, label ->
                        val on = period == i
                        val shape = RoundedCornerShape(50)
                        val base = Modifier.weight(1f).clip(shape).clickable { period = i }
                        Box(
                            if (on) base.background(Brush.horizontalGradient(listOf(pal.primary, pal.dark))) else base,
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                label, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1,
                                color = if (on) Color.White else Ink,
                                modifier = Modifier.padding(vertical = 10.dp)
                            )
                        }
                    }
                }
            }

            // Three counters
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SoftCard(Modifier.weight(1f), shape = RoundedCornerShape(20.dp)) {
                    StatColumn(Modifier.fillMaxWidth(), { AdBadge(34.dp) }, Fmt.count(data.current), tr("Ads Blocked", "අවහිර කළ"))
                }
                SoftCard(Modifier.weight(1f), shape = RoundedCornerShape(20.dp)) {
                    StatColumn(
                        Modifier.fillMaxWidth(),
                        { Icon(Icons.Default.Storage, null, tint = pal.primary, modifier = Modifier.size(32.dp)) },
                        Fmt.bytes(data.current * EventKind.AVG_BYTES), tr("Data Saved", "ඉතිරි දත්ත")
                    )
                }
                SoftCard(Modifier.weight(1f), shape = RoundedCornerShape(20.dp)) {
                    StatColumn(
                        Modifier.fillMaxWidth(),
                        { Icon(Icons.Default.Timer, null, tint = Color(0xFF2F7BFF), modifier = Modifier.size(32.dp)) },
                        Fmt.duration(data.current * EventKind.AVG_MILLIS, sinhala), tr("Time Saved", "ඉතිරි කාලය")
                    )
                }
            }

            // Bar chart: last 7 days
            SoftCard(Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth().padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.BarChart, null, tint = pal.primary, modifier = Modifier.size(24.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            tr("Ads Blocked ", "අවහිර කළ දැන්වීම් ") + tr("(Last 7 Days)", "(පසුගිය දින 7)"),
                            color = Ink, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    WeekChart(data.days, sinhala)
                }
            }

            // Trend cards
            val caption = when (period) {
                0 -> tr("vs. yesterday", "ඊයේට සාපේක්ෂව")
                1 -> tr("vs. previous 7 days", "පෙර දින 7ට සාපේක්ෂව")
                2 -> tr("vs. previous 30 days", "පෙර දින 30ට සාපේක්ෂව")
                else -> tr("since you started", "ආරම්භයේ සිට")
            }
            val pct = data.previous?.let { Fmt.percentChange(data.current, it) }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                TrendCard(
                    Modifier.weight(1f), tr("Data Saved", "ඉතිරි දත්ත"), Fmt.bytes(data.current * EventKind.AVG_BYTES),
                    pct, caption, data.days, { Icon(Icons.Default.Storage, null, tint = pal.primary, modifier = Modifier.size(30.dp)) }
                )
                TrendCard(
                    Modifier.weight(1f), tr("Time Saved", "ඉතිරි කාලය"), Fmt.duration(data.current * EventKind.AVG_MILLIS, sinhala),
                    pct, caption, data.days, { Icon(Icons.Default.Timer, null, tint = pal.primary, modifier = Modifier.size(30.dp)) }
                )
            }

            // Protected banner
            SoftCard(Modifier.fillMaxWidth()) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .background(Brush.horizontalGradient(listOf(pal.soft, pal.glow.copy(alpha = 0.45f))))
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.VerifiedUser, null, tint = pal.primary, modifier = Modifier.size(42.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(tr("You're Protected!", "ඔබ ආරක්ෂිතයි!"), color = Ink, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                        Text(
                            tr("Enjoy a faster, cleaner and safer web.", "වඩා වේගවත්, පිරිසිදු සහ ආරක්ෂිත වෙබ් අත්දැකීමක් භුක්ති විඳින්න."),
                            color = Muted, fontSize = 13.sp
                        )
                    }
                    Box(Modifier.size(38.dp).clip(CircleShape).background(OkGreen), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(24.dp))
                    }
                }
            }
            Text(
                tr(
                    "Data and time saved are estimates based on the average size of a blocked request.",
                    "ඉතිරි දත්ත සහ කාලය යනු අවහිර කළ ඉල්ලීමක සාමාන්‍ය ප්‍රමාණය මත පදනම් වූ ඇස්තමේන්තු පමණි."
                ),
                color = Muted, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 6.dp)
            )
            Spacer(Modifier.height(6.dp))
        }
    }
}

@Composable
private fun TrendCard(
    modifier: Modifier, title: String, value: String, pct: Int?, caption: String,
    days: List<Int>, icon: @Composable () -> Unit
) {
    SoftCard(modifier, shape = RoundedCornerShape(22.dp)) {
        Box(Modifier.fillMaxWidth().height(112.dp)) {
            Sparkline(days, Modifier.align(Alignment.BottomEnd).width(110.dp).height(54.dp))
            Column(Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    icon()
                    Spacer(Modifier.width(8.dp))
                    Text(title, color = Ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
                Text(value, color = Ink, fontWeight = FontWeight.ExtraBold, fontSize = 24.sp, maxLines = 1)
                if (pct != null) {
                    Text(
                        (if (pct >= 0) "\u2191 " else "\u2193 ") + kotlin.math.abs(pct) + "%",
                        color = if (pct >= 0) OkGreen else DangerRed, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp
                    )
                }
                Text(caption, color = Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun Sparkline(days: List<Int>, modifier: Modifier) {
    val pal = LocalPalette.current
    Canvas(modifier) {
        val values = days.reversed() // oldest first
        val max = (values.maxOrNull() ?: 0).coerceAtLeast(1).toFloat()
        val step = size.width / (values.size - 1)
        val line = Path()
        values.forEachIndexed { i, v ->
            val x = i * step
            val y = size.height - (v / max) * (size.height * 0.85f) - 2.dp.toPx()
            if (i == 0) line.moveTo(x, y) else line.lineTo(x, y)
        }
        val fill = Path().apply {
            addPath(line)
            lineTo(size.width, size.height)
            lineTo(0f, size.height)
            close()
        }
        drawPath(fill, Brush.verticalGradient(listOf(pal.glow.copy(alpha = 0.45f), Color.Transparent)))
        drawPath(line, pal.glow, style = Stroke(width = 2.dp.toPx()))
    }
}

@Composable
private fun WeekChart(days: List<Int>, sinhala: Boolean) {
    val pal = LocalPalette.current
    val maxValue = (days.maxOrNull() ?: 0).toLong()
    val steps = longArrayOf(1, 2, 5, 10, 20, 25, 50, 100, 200, 250, 300, 500, 1000, 2000, 2500, 5000, 10000, 20000)
    val step = steps.firstOrNull { (maxValue + it - 1) / it <= 5 } ?: 20000L
    val parts = ((maxValue + step - 1) / step).coerceAtLeast(1L).toInt()
    val top = parts * step
    val chartHeight = 150.dp

    Row(Modifier.fillMaxWidth()) {
        Column(
            Modifier.height(chartHeight).width(46.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.End
        ) {
            for (i in parts downTo 0) {
                Text(Fmt.count(i * step), color = Ink, fontSize = 12.sp, modifier = Modifier.padding(end = 6.dp))
            }
        }
        Column(Modifier.weight(1f)) {
            Canvas(Modifier.fillMaxWidth().height(chartHeight)) {
                val h = size.height
                val w = size.width
                for (i in 0..parts) {
                    val y = h - h * i / parts
                    drawLine(Color(0xFFE6DDF7), Offset(0f, y), Offset(w, y), strokeWidth = 1.dp.toPx())
                }
                val slot = w / 7f
                val barWidth = slot * 0.74f
                for (idx in 0..6) {
                    val v = days[6 - idx]
                    val barHeight = if (top == 0L) 0f else h * v / top
                    val isToday = idx == 6
                    drawRoundRect(
                        brush = Brush.verticalGradient(
                            listOf(
                                if (isToday) pal.dark else pal.glow.copy(alpha = 0.8f),
                                if (isToday) pal.primary else pal.primary.copy(alpha = 0.85f)
                            ),
                            startY = h - barHeight, endY = h
                        ),
                        topLeft = Offset(idx * slot + (slot - barWidth) / 2f, h - barHeight),
                        size = Size(barWidth, barHeight),
                        cornerRadius = CornerRadius(8.dp.toPx())
                    )
                }
            }
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth()) {
                for (idx in 0..6) {
                    val ago = 6 - idx
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(Fmt.dayLabel(ago, sinhala), color = Ink, fontSize = 12.sp, maxLines = 1)
                        Text(Fmt.count(days[ago].toLong()), color = Ink, fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
                    }
                }
            }
        }
    }
}
