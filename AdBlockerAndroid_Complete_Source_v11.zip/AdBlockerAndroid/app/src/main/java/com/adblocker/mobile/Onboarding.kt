package com.adblocker.mobile

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val AppLanguages = listOf("en" to "English", "si" to "සිංහල")

@Composable
fun LanguageSelector(language: String, onLanguage: (String) -> Unit) {
    val pal = LocalPalette.current
    var open by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(50)
    Box {
        Row(
            Modifier
                .clip(shape)
                .background(Color.White.copy(alpha = 0.92f))
                .border(1.dp, pal.glow.copy(alpha = 0.5f), shape)
                .clickable { open = true }
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Language, null, tint = pal.primary, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
            Text(
                AppLanguages.firstOrNull { it.first == language }?.second ?: "English",
                color = Ink, fontWeight = FontWeight.Bold, fontSize = 15.sp
            )
            Icon(Icons.Default.KeyboardArrowDown, null, tint = Ink, modifier = Modifier.size(20.dp))
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            AppLanguages.forEach { (code, name) ->
                DropdownMenuItem(
                    text = { Text(name, fontWeight = if (code == language) FontWeight.Bold else FontWeight.Normal) },
                    onClick = {
                        open = false
                        onLanguage(code)
                    }
                )
            }
        }
    }
}

@Composable
private fun FeatureCard(modifier: Modifier, title: String, icon: @Composable () -> Unit) {
    SoftCard(modifier, shape = RoundedCornerShape(22.dp)) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(46.dp), contentAlignment = Alignment.Center) { icon() }
            Spacer(Modifier.width(10.dp))
            Text(title, color = Ink, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, lineHeight = 19.sp)
        }
    }
}

@Composable
private fun WindowAdIcon() {
    Box(Modifier.size(44.dp)) {
        PopupIcon(44.dp)
        Box(Modifier.align(Alignment.BottomEnd)) { AdBadge(24.dp) }
    }
}

@Composable
private fun SavePageIcon() {
    Box(Modifier.size(44.dp)) {
        Icon(Icons.Default.BarChart, null, tint = LocalPalette.current.primary, modifier = Modifier.size(42.dp))
        Text("\uD83C\uDF43", fontSize = 18.sp, modifier = Modifier.align(Alignment.BottomEnd))
    }
}

@Composable
private fun IntroPage(index: Int) {
    val pal = LocalPalette.current
    when (index) {
        0 -> Column(
            Modifier.fillMaxSize().padding(horizontal = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(4.dp))
            ShieldLogo(170.dp)
            Spacer(Modifier.height(6.dp))
            Text("Ad Blocker", color = Ink, fontWeight = FontWeight.ExtraBold, fontSize = 40.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                tr(
                    "Block ads, pop-ups and trackers for a faster, safer and cleaner browsing experience.",
                    "වඩා වේගවත්, ආරක්ෂිත සහ පිරිසිදු බ්‍රවුස් අත්දැකීමක් සඳහා දැන්වීම්, පොප්-අප් සහ ට්‍රැකර් අවහිර කරන්න."
                ),
                color = Muted, fontSize = 15.sp, textAlign = TextAlign.Center, lineHeight = 21.sp,
                modifier = Modifier.padding(horizontal = 10.dp)
            )
            Spacer(Modifier.height(20.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                FeatureCard(Modifier.weight(1f), tr("Block Ads\n& Pop-ups", "දැන්වීම් සහ\nපොප්-අප් අවහිර")) { WindowAdIcon() }
                FeatureCard(Modifier.weight(1f), tr("Protect\nYour Privacy", "ඔබේ පෞද්ගලිකත්වය\nආරක්ෂා කරන්න")) {
                    Icon(Icons.Default.VerifiedUser, null, tint = pal.primary, modifier = Modifier.size(40.dp))
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                FeatureCard(Modifier.weight(1f), tr("Browse\nFaster", "වේගවත්ව\nබ්‍රවුස් කරන්න")) {
                    Icon(Icons.Default.RocketLaunch, null, tint = pal.primary, modifier = Modifier.size(40.dp))
                }
                FeatureCard(Modifier.weight(1f), tr("Save\nData", "දත්ත\nඉතිරි කරන්න")) { SavePageIcon() }
            }
        }
        1 -> BigMessage(
            icon = { Icon(Icons.Default.VerifiedUser, null, tint = pal.primary, modifier = Modifier.size(84.dp)) },
            title = tr("Protect Your Privacy", "ඔබේ පෞද්ගලිකත්වය ආරක්ෂා කරන්න"),
            text = tr(
                "Trackers follow you from site to site. Ad Blocker stops their lookups before they leave your phone.",
                "ට්‍රැකර් ඔබව වෙබ් අඩවියෙන් වෙබ් අඩවියට අනුගමනය කරයි. Ad Blocker ඒවායේ ඉල්ලීම් ඔබේ දුරකථනයෙන් පිටවීමට පෙර නවත්වයි."
            )
        )
        else -> BigMessage(
            icon = { Icon(Icons.Default.RocketLaunch, null, tint = pal.primary, modifier = Modifier.size(84.dp)) },
            title = tr("Browse Faster, Save Data", "වේගවත්ව බ්‍රවුස් කරන්න, දත්ත ඉතිරි කරන්න"),
            text = tr(
                "Pages load without heavy ad scripts, so they open sooner and use less mobile data.",
                "බර දැන්වීම් script නොමැතිව පිටු ඉක්මනින් විවෘත වන අතර ජංගම දත්ත අඩුවෙන් භාවිතා වේ."
            )
        )
    }
}

@Composable
private fun BigMessage(icon: @Composable () -> Unit, title: String, text: String) {
    Column(
        Modifier.fillMaxSize().padding(horizontal = 30.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        SoftCard(shape = CircleShape) { Box(Modifier.size(150.dp), contentAlignment = Alignment.Center) { icon() } }
        Spacer(Modifier.height(28.dp))
        Text(title, color = Ink, fontWeight = FontWeight.ExtraBold, fontSize = 26.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(12.dp))
        Text(text, color = Muted, fontSize = 16.sp, textAlign = TextAlign.Center, lineHeight = 23.sp)
    }
}

@Composable
fun OnboardingScreen(language: String, onLanguage: (String) -> Unit, onDone: () -> Unit) {
    val pal = LocalPalette.current
    val pager = rememberPagerState(pageCount = { 3 })
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), horizontalArrangement = Arrangement.End) {
            LanguageSelector(language, onLanguage)
        }
        HorizontalPager(state = pager, modifier = Modifier.weight(1f)) { page -> IntroPage(page) }
        Row(
            Modifier.fillMaxWidth().padding(vertical = 14.dp),
            horizontalArrangement = Arrangement.Center
        ) {
            repeat(3) { i ->
                val on = pager.currentPage == i
                Box(
                    Modifier
                        .padding(horizontal = 5.dp)
                        .size(if (on) 12.dp else 10.dp)
                        .clip(CircleShape)
                        .background(if (on) pal.primary else pal.glow.copy(alpha = 0.4f))
                )
            }
        }
        GradientButton(
            tr("Get Started", "ආරම්භ කරන්න"),
            Modifier.fillMaxWidth().padding(horizontal = 34.dp).padding(bottom = 22.dp),
            onClick = onDone
        )
    }
}
