package com.adblocker.mobile

/**
 * Scores a host name by how much it looks like an ad or tracking server, so ad domains that no
 * filter list knows yet can still be caught. No Android dependencies.
 *
 * What is looked at:
 *  - the labels in front of the registrable domain (ads.*, adserver3.*, x.banners.*, ...), split
 *    at "-" and "_" and with trailing digits removed, so "ads2" and "pagead-eu" are understood;
 *  - the registrable name itself, but only against a list of known ad/tracker companies and a few
 *    unambiguous compounds, so ordinary sites that merely contain "ads" (uploads.com) are safe.
 *
 * Scores: 100 = clearly advertising, 50-99 = analytics/tracking style names, 25-49 = only
 * suspicious (shown in the log, never blocked on its own).
 */
object AdHeuristics {
    class Detection(val score: Int, val why: String)

    /** Below this a name is not even worth flagging in the log. */
    const val SUSPECT_MIN = 25

    /** Score a name needs to be blocked at the given level (0 off, 1 Balanced, 2 Strong). */
    fun thresholdFor(level: Int): Int = when (level) {
        1 -> 100
        2 -> 50
        else -> Int.MAX_VALUE
    }

    /**
     * Sites whose sub-domains must never be guessed at. Their ad dashboards (ads.google.com,
     * adsmanager.facebook.com, ads.tiktok.com, ...) are tools that a shop owner needs. Names
     * that are on a real filter list are still blocked; only the guessing stops here.
     */
    private val PROTECTED = setOf(
        "google.com", "googleapis.com", "gstatic.com", "googleusercontent.com", "youtube.com",
        "ytimg.com", "googlevideo.com", "android.com", "withgoogle.com", "gvt1.com", "gvt2.com",
        "facebook.com", "fbcdn.net", "instagram.com", "whatsapp.com", "whatsapp.net", "fb.com",
        "meta.com", "microsoft.com", "live.com", "office.com", "office365.com", "outlook.com",
        "microsoftonline.com", "windows.com", "bing.com", "apple.com", "icloud.com", "amazon.com",
        "amazonaws.com", "cloudfront.net", "cloudflare.com", "github.com", "githubusercontent.com",
        "tiktok.com", "twitter.com", "x.com", "linkedin.com", "paypal.com", "samsung.com",
        "samsungapps.com", "whatsapp.biz", "telegram.org", "t.me", "zoom.us", "dropbox.com"
    )

    /** One of these as a label (or part of a "-" separated label) in front of the domain = ads. */
    private val STRONG_TOKENS = setOf(
        "ads", "adv", "adx", "adserver", "adservers", "adservice", "adservices", "adsystem",
        "adsystems", "adtech", "adnet", "adnetwork", "adsrv", "adsdk", "adview", "adclick",
        "adlog", "adtrack", "adimg", "adserving", "adserve", "adtag", "adtags", "adcall",
        "adrequest", "adexchange", "adsense", "adstat", "adstats", "advert", "adverts",
        "advertising", "advertisement", "advertisements", "banner", "banners", "pagead",
        "admob", "admanager", "doubleclick", "prebid", "openrtb", "rtb", "vast", "vpaid",
        "interstitial", "interstitials", "rewardedvideo", "preroll", "midroll", "popunder",
        "sponsored", "programmatic", "impression", "impressions", "monetize", "monetization",
        "bidder", "adsmoloco"
    )
    private const val STRONG_SCORE = 100

    /** A bare "ad" label (ad.example.com) is nearly always an ad server. */
    private const val AD_TOKEN = "ad"
    private const val AD_TOKEN_SCORE = 80

    /** Analytics and telemetry style names. */
    private val MID_TOKENS = setOf(
        "analytics", "analytic", "telemetry", "metrics", "metric", "beacon", "beacons",
        "pixel", "pixels", "attribution", "measurement", "smetrics"
    )
    private const val MID_SCORE = 50

    /** Words that are suspicious in combination but legitimate alone (parcel tracking, logs). */
    private val WEAK_TOKENS = setOf(
        "tracking", "tracker", "trackers", "track", "stats", "stat", "events", "event",
        "collect", "collector", "log", "logs", "logging", "report", "reports", "sdk", "tag",
        "tags", "bid", "bids", "click", "clicks", "imp", "promo", "promos", "affiliate", "ping",
        "pings", "rum"
    )
    private const val WEAK_SCORE = 25

    /** Unambiguous ad compounds. Checked in the sub-domain labels. */
    private val COMPOUNDS = listOf(
        "adserver", "adservice", "adsystem", "adtech", "adnetwork", "adexchange", "adsense",
        "adsrv", "adclick", "adtrack", "doubleclick", "googlesyndication", "googleadservices",
        "googleads", "googletagservices", "adnxs", "popads"
    )

    /** The compounds that are safe to look for inside the registrable name too (myadserver.com). */
    private val SLD_COMPOUNDS = listOf(
        "adserver", "adservice", "adsystem", "adnetwork", "adexchange", "adsrv", "adtrack",
        "adclick", "doubleclick", "googlesyndication", "googleadservices", "googleads"
    )

    /** Registrable names (without the TLD) of ad networks, ad exchanges and ad SDKs. */
    private val AD_BRANDS = setOf(
        "doubleclick", "googlesyndication", "googleadservices", "googletagservices", "2mdn",
        "admob", "adcolony", "applovin", "applvn", "appnext", "adjoe", "ironsrc", "supersonicads",
        "vungle", "chartboost", "mintegral", "mtgglobals", "rayjump", "pangleglobal", "pangle",
        "inmobi", "inmobicdn", "startappservice", "startappexchange", "tapjoy", "fyber",
        "smaato", "smaatolabs", "mopub", "ogury", "presage", "bigossp", "mobvista", "bidmachine",
        "pubnative", "adnxs", "adsrvr", "rubiconproject", "pubmatic", "openx", "criteo",
        "taboola", "outbrain", "moatads", "amazon-adsystem", "casalemedia", "indexww",
        "bidswitch", "tremorhub", "spotxchange", "spotx", "adform", "smartadserver", "teads",
        "yieldmo", "sharethrough", "triplelift", "33across", "lijit", "sovrn", "contextweb",
        "adtechus", "adition", "zedo", "revcontent", "mgid", "popads", "propellerads", "exoclick",
        "juicyads", "trafficjunky", "clickadu", "adsterra", "hilltopads", "adcash", "admaven",
        "adsmoloco", "adskeeper", "richaudience", "improvedigital", "gumgum", "adroll",
        "rtbhouse", "mediavine", "adthrive", "bluekai", "krxd", "demdex", "everesttech",
        "scorecardresearch", "quantserve", "quantcount", "serving-sys", "flashtalking",
        "innovid", "tubemogul", "yieldlab", "mobfox", "mobilefuse", "appier", "samsungads",
        "samsungadhub", "adspyglass"
    )
    private const val BRAND_SCORE = 100

    /** Analytics / attribution companies. Blocked only at the Strong level. */
    private val TRACKER_BRANDS = setOf(
        "appsflyer", "adjust", "kochava", "tenjin", "app-measurement", "flurry", "mixpanel",
        "amplitude", "hotjar", "fullstory", "mouseflow", "crazyegg", "umeng", "umengcloud",
        "talkingdata"
    )
    private const val TRACKER_BRAND_SCORE = 60

    fun isProtected(host: String): Boolean {
        var candidate = host
        while (candidate.contains('.')) {
            if (candidate in PROTECTED) return true
            candidate = candidate.substringAfter('.')
        }
        return false
    }

    /** Null when nothing about the name looks like advertising or tracking. [host] is lower case. */
    fun analyze(host: String): Detection? {
        if (!host.contains('.') || host.endsWith(".arpa") || isProtected(host)) return null
        val labels = host.split('.')
        val keep = DomainUtil.registrableLabelCount(labels)
        if (labels.size < keep) return null
        val sub = labels.subList(0, labels.size - keep)
        val sld = labels[labels.size - keep]

        var best = 0
        var bestWhy = ""
        fun offer(score: Int, why: String) {
            if (score > best) { best = score; bestWhy = why }
        }

        if (sld in AD_BRANDS) offer(BRAND_SCORE, "ad network '$sld'")
        if (sld in TRACKER_BRANDS) offer(TRACKER_BRAND_SCORE, "tracker '$sld'")
        for (compound in SLD_COMPOUNDS) {
            if (sld.contains(compound)) { offer(BRAND_SCORE, "name contains '$compound'"); break }
        }
        for (part in sld.split('-')) {
            if (part == "ads" || part == "adserver" || part == "adserving") offer(90, "ad word '$part' in domain")
        }

        val scores = ArrayList<Int>()
        for (label in sub) {
            for (compound in COMPOUNDS) {
                if (label.contains(compound)) { offer(STRONG_SCORE, "name contains '$compound'"); break }
            }
            for (raw in label.split('-', '_')) {
                val token = raw.trimEnd { it.isDigit() }
                if (token.isEmpty()) continue
                val score = when {
                    token in STRONG_TOKENS -> STRONG_SCORE
                    token.startsWith("advertis") -> STRONG_SCORE
                    token == AD_TOKEN -> AD_TOKEN_SCORE
                    token in MID_TOKENS -> MID_SCORE
                    token in WEAK_TOKENS -> WEAK_SCORE
                    else -> 0
                }
                if (score > 0) {
                    scores.add(score)
                    offer(score, "'$token' in name")
                }
            }
        }
        // Several weak signs add up: the strongest counts fully, the second counts half.
        if (scores.size >= 2) {
            scores.sortDescending()
            val combined = scores[0] + scores[1] / 2
            if (combined > best) { best = combined; bestWhy = "$bestWhy + other tracking words" }
        }
        return if (best >= SUSPECT_MIN) Detection(best, bestWhy) else null
    }

    /** Backwards compatible helper: true when the name is clearly advertising (Balanced level). */
    fun looksLikeAd(host: String): Boolean = (analyze(host)?.score ?: 0) >= thresholdFor(1)
}
