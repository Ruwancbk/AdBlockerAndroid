package com.adblocker.mobile

import java.util.concurrent.ConcurrentHashMap

/** A name the blocker decided to block on its own (not from a list, not typed in by the user). */
class AutoRule(
    val domain: String,
    val score: Int,
    val why: String,
    val app: String,
    val time: Long
)

/**
 * In-memory copy of the automatically learned rules plus a tiny "ad burst" detector.
 * The database keeps the rules across restarts; this object answers lookups without any I/O.
 * No Android dependencies.
 */
object AutoBlock {
    const val MAX_RULES = 4000

    private val rules = ConcurrentHashMap<String, AutoRule>()
    private val bursts = ConcurrentHashMap<String, LongArray>()

    fun replaceAll(list: List<AutoRule>) {
        rules.clear()
        for (rule in list) rules[rule.domain] = rule
    }

    fun size(): Int = rules.size

    fun get(domain: String): AutoRule? = rules[domain]

    /** True when the rule is new. */
    fun put(rule: AutoRule): Boolean = rules.putIfAbsent(rule.domain, rule) == null

    fun remove(domain: String) {
        rules.remove(domain)
    }

    fun clear() = rules.clear()

    fun all(): List<AutoRule> = rules.values.sortedByDescending { it.time }

    /** The rule that covers [host] or one of its parent domains, if it is strong enough for [level]. */
    fun match(host: String, level: Int): AutoRule? {
        val minimum = AdHeuristics.thresholdFor(level)
        var candidate = host
        while (candidate.contains('.')) {
            val rule = rules[candidate]
            if (rule != null && rule.score >= minimum) return rule
            candidate = candidate.substringAfter('.')
        }
        return null
    }

    /** Remember that [appId] just made a lookup that was blocked as an ad. */
    fun noteAdHit(appId: String, now: Long) {
        if (appId.isEmpty()) return
        val ring = bursts.getOrPut(appId) { LongArray(3) }
        synchronized(ring) {
            ring[2] = ring[1]
            ring[1] = ring[0]
            ring[0] = now
        }
    }

    /** How many of the app's last three ad lookups happened within [windowMs] before [now]. */
    fun recentAdHits(appId: String, now: Long, windowMs: Long): Int {
        val ring = bursts[appId] ?: return 0
        synchronized(ring) {
            var count = 0
            for (t in ring) if (t != 0L && now - t in 0..windowMs) count++
            return count
        }
    }
}
