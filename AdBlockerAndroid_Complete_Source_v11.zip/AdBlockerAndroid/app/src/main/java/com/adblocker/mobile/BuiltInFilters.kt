package com.adblocker.mobile

/**
 * Ad-network and ad-SDK domains that ship inside the app, so blocking works from the first
 * second and even when the online lists cannot be downloaded. Every entry also blocks its
 * subdomains. If one of these breaks something you need, add it to the Allowlist.
 */
object BuiltInFilters {
    /** Bump when the list below changes so installed copies get refreshed. */
    const val VERSION = "2"
    const val SOURCE = "Built-in"

    val DOMAINS: Set<String> = linkedSetOf(
        // Video / in-app ad networks used by games and utility apps
        "applovin.com", "applvn.com", "unityads.unity3d.com", "config.unity3d.com",
        "supersonicads.com", "ironsrc.com", "vungle.com", "chartboost.com",
        "mintegral.com", "mintegral.net", "mtgglobals.com", "rayjump.com",
        "pangleglobal.com", "pangle.io", "inmobi.com", "inmobicdn.net",
        "adcolony.com", "startappservice.com", "startappexchange.com", "tapjoy.com",
        "fyber.com", "inner-active.mobi", "smaato.net", "mopub.com", "ogury.co",
        "presage.io", "bigossp.com", "mobvista.com", "an.facebook.com",
        // Google / Amazon ad serving
        "doubleclick.net", "googleads.g.doubleclick.net", "pagead2.googlesyndication.com",
        "googlesyndication.com", "googleadservices.com", "adservice.google.com",
        "amazon-adsystem.com",
        // Content-recommendation / banner networks
        "taboola.com", "outbrain.com", "criteo.com", "criteo.net", "adnxs.com",
        "rubiconproject.com", "pubmatic.com", "openx.net", "adsrvr.org", "moatads.com",
        // SHAREit's own servers (feed, video and ad delivery). File transfer between phones
        // is local and keeps working; allowlist these if you need SHAREit's online features.
        "wshareit.com", "ushareit.com", "shareitgames.com", "shareitpp.com",
        // More SDK / exchange / OEM ad servers (the name detector catches the rest)
        "liftoff.io", "adjoe.io", "appnext.com", "bidmachine.io", "pubnative.net",
        "adsmoloco.com", "samsungads.com", "samsungadhub.com", "adkernel.com", "adform.net",
        "smartadserver.com", "teads.tv", "yieldmo.com", "gumgum.com", "mgid.com", "adsterra.com",
        "propellerads.com", "exoclick.com", "popads.net", "clickadu.com", "hilltopads.com",
        "adsafeprotected.com", "scorecardresearch.com", "quantserve.com", "demdex.net",
        "bluekai.com", "krxd.net",
        // Firefox asks this name before it switches to DNS-over-HTTPS. An NXDOMAIN answer tells
        // it to keep using normal DNS, which is the one this blocker filters.
        "use-application-dns.net"
    )
}
