package com.adblocker.mobile

import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView

fun toBrowserUrl(input: String): String {
    val value = input.trim()
    return when {
        value.startsWith("http://") || value.startsWith("https://") -> value
        value.contains('.') && !value.contains(' ') -> "https://$value"
        else -> SearchEngines.url(AppPrefs.searchEngine) + java.net.URLEncoder.encode(value, "UTF-8")
    }
}

private const val HIDE_ANNOYING_JS =
    "(function(){var s=document.createElement('style');" +
        "s.textContent='[id*=\"cookie\" i],[class*=\"cookie\" i],[id*=\"consent\" i],[class*=\"consent\" i]," +
        "[id*=\"gdpr\" i],[class*=\"gdpr\" i],[class*=\"newsletter-popup\" i],[class*=\"modal-backdrop\" i]" +
        "{display:none !important}body{overflow:auto !important}';document.head.appendChild(s);})();"

@Composable
fun BrowserScreen(
    db: AdBlockerDatabase,
    urlInput: String,
    browserUrl: String,
    onInput: (String) -> Unit,
    onGo: (String) -> Unit,
    javaScript: Boolean,
    blockAds: Boolean,
    onPro: () -> Unit,
    onSettings: () -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        BrandHeader(onPro = onPro) { RoundIconButton(Icons.Default.Settings, "Settings", onSettings) }
        Column(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 14.dp)) {
            OutlinedTextField(
                value = urlInput, onValueChange = onInput,
                modifier = Modifier.fillMaxWidth(),
                label = { Text(tr("Search or enter website URL", "සොයන්න හෝ වෙබ් URL එක ඇතුළත් කරන්න")) },
                trailingIcon = {
                    IconButton(onClick = { onGo(toBrowserUrl(urlInput)) }) { Icon(Icons.Default.Search, contentDescription = "Go") }
                },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { onGo(toBrowserUrl(urlInput)) }),
                singleLine = true, shape = RoundedCornerShape(50)
            )
            Spacer(Modifier.height(8.dp))
            SoftCard(Modifier.weight(1f).fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
                BrowserPane(browserUrl, db, javaScript, blockAds, Modifier.fillMaxSize())
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun BrowserPane(url: String, db: AdBlockerDatabase, javaScript: Boolean, blockAds: Boolean, modifier: Modifier = Modifier) {
    val blockState = rememberUpdatedState(blockAds)
    // Remembers what was last loaded so recompositions never reload the page.
    val lastLoaded = remember { arrayOfNulls<String>(1) }
    AndroidView(
        modifier = modifier,
        factory = { context ->
            WebView(context).apply {
                settings.domStorageEnabled = false
                webViewClient = object : WebViewClient() {
                    override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                        if (!blockState.value) return null
                        val host = request?.url?.host?.lowercase() ?: return null
                        if (db.isDomainBlocked(host)) {
                            db.addBlockedEvent(host, "Browser")
                            return WebResourceResponse("text/plain", "utf-8", java.io.ByteArrayInputStream(ByteArray(0)))
                        }
                        return null
                    }

                    override fun onPageFinished(view: WebView?, pageUrl: String?) {
                        // Cosmetic hiding needs JavaScript; with it off, the network blocking above still applies.
                        if (AppPrefs.blockAnnoying) {
                            view?.let { if (it.settings.javaScriptEnabled) it.evaluateJavascript(HIDE_ANNOYING_JS, null) }
                        }
                    }
                }
            }
        },
        update = { web ->
            web.settings.javaScriptEnabled = javaScript
            // Pop-ups: scripts may not open new windows by themselves while "Block Pop-ups" is on.
            web.settings.javaScriptCanOpenWindowsAutomatically = !AppPrefs.blockPopups
            // Faster Browsing: reuse cached pages and files whenever possible.
            web.settings.cacheMode = if (AppPrefs.fasterBrowsing) WebSettings.LOAD_CACHE_ELSE_NETWORK else WebSettings.LOAD_DEFAULT
            // Enhanced Privacy: no third-party cookies and no location sharing.
            CookieManager.getInstance().setAcceptThirdPartyCookies(web, !AppPrefs.enhancedPrivacy)
            web.settings.setGeolocationEnabled(!AppPrefs.enhancedPrivacy)
            val target = url.trim()
            if (target.isNotBlank() && lastLoaded[0] != target) {
                lastLoaded[0] = target
                web.loadUrl(target)
            }
        }
    )
}
