package com.adblocker.mobile

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.VpnService
import androidx.core.content.ContextCompat

/**
 * Brings protection back after a restart and after the app has been updated (an update stops
 * the running service), as long as the user had it switched on and VPN permission is intact.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED && action != Intent.ACTION_MY_PACKAGE_REPLACED) return
        if (!AppPrefs.protectionWanted(context) || !AppPrefs.startOnBoot(context)) return
        if (VpnService.prepare(context) != null) return // permission was revoked: the user must confirm again
        try {
            ContextCompat.startForegroundService(
                context, Intent(context, DnsVpnService::class.java).setAction(DnsVpnService.ACTION_START)
            )
        } catch (e: Exception) {
            // The system refused a background start; the user can switch protection on in the app.
        }
    }
}
