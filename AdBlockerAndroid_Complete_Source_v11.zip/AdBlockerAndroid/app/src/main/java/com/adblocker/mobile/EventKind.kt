package com.adblocker.mobile

/**
 * Sorts a blocked domain into one of the four groups shown in History and Stats.
 * A DNS blocker only sees names, so this is a best-effort guess from the words in the name.
 */
object EventKind {
    const val AD = "ad"
    const val POPUP = "popup"
    const val TRACKER = "tracker"
    const val OTHER = "other"

    private val popupWords = listOf(
        "popad", "popcash", "popunder", "popup", "pop-up", "clickadu", "propeller", "onclick",
        "clickunder", "adsterra", "exoclick", "juicyads", "trafficjunky", "richpush", "pushwoosh",
        "interstitial", "redirect", "landing", "offer"
    )
    private val trackerWords = listOf(
        "track", "analytic", "telemetry", "metric", "beacon", "pixel", "insight", "measure",
        "scorecard", "segment", "mixpanel", "hotjar", "amplitude", "crashlytics", "appsflyer",
        "adjust", "kochava", "singular", "omtrdc", "quantserve", "comscore", "chartbeat",
        "newrelic", "bugsnag", "flurry", "clarity", "stats", "statcounter", "sentry", "heap"
    )
    private val otherWords = listOf(
        "script", "sdk", "widget", "overlay", "consent", "cookie", "gdpr", "notice", "banner-js",
        "tag", "cdn", "loader", "bundle"
    )

    fun classify(domain: String): String {
        val d = domain.lowercase()
        if (popupWords.any { d.contains(it) }) return POPUP
        if (trackerWords.any { d.contains(it) }) return TRACKER
        if (otherWords.any { d.contains(it) }) return OTHER
        return AD
    }

    // Average size / time of a blocked request, used for the "Data saved" and "Time saved"
    // estimates (the phone cannot see what a blocked request would have downloaded).
    const val AVG_BYTES = 42_000L
    const val AVG_MILLIS = 870L
}
