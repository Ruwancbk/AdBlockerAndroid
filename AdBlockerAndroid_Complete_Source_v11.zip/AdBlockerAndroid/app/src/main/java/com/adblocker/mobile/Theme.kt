package com.adblocker.mobile

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

// ---- colours ---------------------------------------------------------------------------

val Ink = Color(0xFF1B0F3B)
val Muted = Color(0xFF4A4166)
val OkGreen = Color(0xFF22B52E)
val DangerRed = Color(0xFFE53935)

/** One accent colour set. "App Theme" in Settings picks one; Purple is the default. */
data class Palette(val name: String, val primary: Color, val dark: Color, val soft: Color, val glow: Color)

val Palettes: Map<String, Palette> = linkedMapOf(
    "purple" to Palette("Purple", Color(0xFF7B2FF7), Color(0xFF5A12C8), Color(0xFFEFE6FF), Color(0xFFB07CFF)),
    "blue" to Palette("Blue", Color(0xFF2F6BF7), Color(0xFF1248C8), Color(0xFFE4EDFF), Color(0xFF7CA6FF)),
    "teal" to Palette("Teal", Color(0xFF0E9F8E), Color(0xFF07705F), Color(0xFFDDF6F2), Color(0xFF5FD4C4)),
    "pink" to Palette("Pink", Color(0xFFD62F9B), Color(0xFFA11275), Color(0xFFFBE4F3), Color(0xFFF07CC8))
)

val LocalPalette = compositionLocalOf { Palettes.getValue("purple") }
val LocalLang = compositionLocalOf { "en" }

/** Picks the English or Sinhala text for the language chosen in the app. */
@Composable
fun tr(en: String, si: String): String = if (LocalLang.current == "si") si else en

/** Re-runs a screen's data loading every few seconds while it is visible. */
@Composable
fun rememberTick(intervalMs: Long = 3000L): Int {
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(intervalMs)
            tick++
        }
    }
    return tick
}

// ---- background & cards -------------------------------------------------------------------

@Composable
fun AppBackground(content: @Composable () -> Unit) {
    val pal = LocalPalette.current
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFFF8F4FF), Color(0xFFEEE5FF))))
            .drawBehind {
                // purple wave in the top-left corner
                drawCircle(
                    Brush.radialGradient(
                        listOf(pal.primary.copy(alpha = 0.95f), pal.primary.copy(alpha = 0.35f), Color.Transparent),
                        center = Offset(-40.dp.toPx(), -30.dp.toPx()), radius = 250.dp.toPx()
                    ),
                    radius = 250.dp.toPx(), center = Offset(-40.dp.toPx(), -30.dp.toPx())
                )
                // soft glow bottom-right
                drawCircle(
                    Brush.radialGradient(
                        listOf(pal.glow.copy(alpha = 0.45f), Color.Transparent),
                        center = Offset(size.width, size.height), radius = 300.dp.toPx()
                    ),
                    radius = 300.dp.toPx(), center = Offset(size.width, size.height)
                )
            }
    ) { content() }
}

@Composable
fun SoftCard(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(26.dp),
    onClick: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {
    val pal = LocalPalette.current
    val base = modifier
        .shadow(10.dp, shape, ambientColor = pal.primary.copy(alpha = 0.25f), spotColor = pal.primary.copy(alpha = 0.25f))
        .clip(shape)
        .background(Color.White.copy(alpha = 0.94f))
    Box(if (onClick != null) base.clickable(onClick = onClick) else base) { content() }
}

@Composable
fun IconBubble(size: Dp = 48.dp, content: @Composable () -> Unit) {
    val pal = LocalPalette.current
    Box(
        Modifier.size(size).clip(RoundedCornerShape(size / 2.6f)).background(pal.soft),
        contentAlignment = Alignment.Center
    ) { content() }
}

@Composable
fun IconBubbleOf(icon: ImageVector, size: Dp = 48.dp) {
    val pal = LocalPalette.current
    IconBubble(size) { Icon(icon, null, tint = pal.primary, modifier = Modifier.size(size * 0.55f)) }
}

@Composable
fun InfoPill(text: String, modifier: Modifier = Modifier) {
    val pal = LocalPalette.current
    Box(
        modifier.clip(RoundedCornerShape(50)).background(pal.soft).padding(horizontal = 14.dp, vertical = 6.dp)
    ) { Text(text, color = pal.dark, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
}

@Composable
fun SectionTitle(icon: ImageVector, title: String) {
    val pal = LocalPalette.current
    Row(Modifier.padding(start = 14.dp, top = 14.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = pal.primary, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(8.dp))
        Text(title, color = Ink, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
    }
}

@Composable
fun SoftDivider(modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth().height(1.dp).background(Color(0xFFE2D8F5)))
}

// ---- buttons --------------------------------------------------------------------------------

@Composable
fun GradientButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val pal = LocalPalette.current
    val shape = RoundedCornerShape(50)
    Box(
        modifier
            .shadow(14.dp, shape, ambientColor = pal.primary, spotColor = pal.primary)
            .clip(shape)
            .background(Brush.horizontalGradient(listOf(pal.primary, pal.dark)))
            .clickable(onClick = onClick)
            .height(56.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.width(12.dp))
            Icon(Icons.Default.ArrowForward, null, tint = Color.White, modifier = Modifier.size(24.dp))
        }
    }
}

@Composable
fun RoundIconButton(icon: ImageVector, description: String, onClick: () -> Unit) {
    val pal = LocalPalette.current
    Box(
        Modifier
            .size(42.dp)
            .shadow(8.dp, CircleShape, ambientColor = pal.primary.copy(alpha = 0.3f), spotColor = pal.primary.copy(alpha = 0.3f))
            .clip(CircleShape)
            .background(Color.White)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Icon(icon, description, tint = Ink, modifier = Modifier.size(22.dp)) }
}

@Composable
fun ProPill(onClick: () -> Unit) {
    val pal = LocalPalette.current
    val shape = RoundedCornerShape(50)
    Row(
        Modifier
            .shadow(8.dp, shape, ambientColor = pal.primary, spotColor = pal.primary)
            .clip(shape)
            .background(Brush.horizontalGradient(listOf(pal.primary, pal.dark)))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("\uD83D\uDC51", fontSize = 15.sp)
        Spacer(Modifier.width(6.dp))
        Text("Pro", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
    }
}

// ---- headers ----------------------------------------------------------------------------------

/** Logo + app name + Pro pill + one round button (gear on Home, three dots on Stats). */
@Composable
fun BrandHeader(onPro: () -> Unit, trailing: @Composable () -> Unit) {
    Row(
        Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ShieldLogo(46.dp)
        Spacer(Modifier.width(10.dp))
        Text("Ad Blocker", color = Ink, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp, modifier = Modifier.weight(1f))
        ProPill(onPro)
        Spacer(Modifier.width(12.dp))
        trailing()
    }
}

/** Back arrow + logo + title + optional trailing control (History, Settings and other sub-screens). */
@Composable
fun SubHeader(title: String, onBack: () -> Unit, trailing: @Composable () -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(40.dp).clip(CircleShape).clickable(onClick = onBack), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.ArrowBack, "Back", tint = Ink, modifier = Modifier.size(24.dp))
        }
        ShieldLogo(40.dp)
        Spacer(Modifier.width(8.dp))
        Text(title, color = Ink, fontWeight = FontWeight.ExtraBold, fontSize = 21.sp, modifier = Modifier.weight(1f))
        trailing()
    }
}

// ---- bottom navigation ----------------------------------------------------------------------

class NavEntry(val label: String, val icon: ImageVector, val selected: Boolean, val onClick: () -> Unit)

@Composable
fun BottomPillNav(entries: List<NavEntry>) {
    val pal = LocalPalette.current
    val shape = RoundedCornerShape(32.dp)
    Box(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 14.dp, vertical = 10.dp)) {
        Row(
            Modifier
                .fillMaxWidth()
                .shadow(14.dp, shape, ambientColor = pal.primary.copy(alpha = 0.35f), spotColor = pal.primary.copy(alpha = 0.35f))
                .clip(shape)
                .background(Color.White)
                .padding(8.dp),
            horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(4.dp)
        ) {
            entries.forEach { e ->
                val itemShape = RoundedCornerShape(26.dp)
                val bg = if (e.selected) Modifier.background(Brush.verticalGradient(listOf(pal.primary, pal.dark))) else Modifier
                Column(
                    Modifier
                        .weight(if (e.selected) 1.25f else 1f)
                        .clip(itemShape)
                        .then(bg)
                        .clickable(onClick = e.onClick)
                        .padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(e.icon, e.label, tint = if (e.selected) Color.White else pal.dark, modifier = Modifier.size(24.dp))
                    Text(
                        e.label, fontSize = 12.5.sp, fontWeight = FontWeight.Bold, maxLines = 1,
                        color = if (e.selected) Color.White else pal.dark
                    )
                }
            }
        }
    }
}

// ---- drawn icons ----------------------------------------------------------------------------

private fun shieldPath(w: Float, h: Float): Path = Path().apply {
    moveTo(w * 0.5f, 0f)
    cubicTo(w * 0.68f, h * 0.10f, w * 0.85f, h * 0.13f, w * 0.98f, h * 0.13f)
    lineTo(w * 0.98f, h * 0.50f)
    cubicTo(w * 0.98f, h * 0.75f, w * 0.72f, h * 0.92f, w * 0.5f, h)
    cubicTo(w * 0.28f, h * 0.92f, w * 0.02f, h * 0.75f, w * 0.02f, h * 0.50f)
    lineTo(w * 0.02f, h * 0.13f)
    cubicTo(w * 0.15f, h * 0.13f, w * 0.32f, h * 0.10f, w * 0.5f, 0f)
    close()
}

/** The app logo: purple shield with a crossed-out "AD". */
@Composable
fun ShieldLogo(size: Dp) {
    val pal = LocalPalette.current
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val w = this.size.width
            val h = this.size.height
            val outer = shieldPath(w, h)
            drawPath(outer, Brush.verticalGradient(listOf(Color.White, pal.soft)))
            drawPath(outer, pal.glow.copy(alpha = 0.9f), style = Stroke(width = w * 0.035f))
            scale(0.82f, Offset(w / 2f, h * 0.5f)) {
                drawPath(
                    shieldPath(w, h),
                    Brush.horizontalGradient(
                        colorStops = arrayOf(0f to pal.dark, 0.5f to pal.dark, 0.5f to pal.primary, 1f to pal.primary)
                    )
                )
            }
        }
        Text(
            "AD", color = Color.White, fontWeight = FontWeight.ExtraBold,
            fontSize = (size.value * 0.34f).sp, modifier = Modifier.padding(bottom = size * 0.06f)
        )
        Canvas(Modifier.fillMaxSize()) {
            val w = this.size.width
            val h = this.size.height
            drawLine(
                DangerRed, Offset(w * 0.28f, h * 0.58f), Offset(w * 0.74f, h * 0.27f),
                strokeWidth = w * 0.05f, cap = StrokeCap.Round
            )
        }
    }
}

/** Red "no entry" circle with AD inside, used for ad rows and counters. */
@Composable
fun AdBadge(size: Dp) {
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = this.size.width * 0.085f
            drawCircle(DangerRed, radius = this.size.width / 2f - stroke / 2f, style = Stroke(width = stroke))
        }
        Text("AD", color = Ink, fontWeight = FontWeight.ExtraBold, fontSize = (size.value * 0.36f).sp)
        Canvas(Modifier.fillMaxSize()) {
            val w = this.size.width
            drawLine(
                DangerRed, Offset(w * 0.2f, w * 0.2f), Offset(w * 0.8f, w * 0.8f),
                strokeWidth = w * 0.085f, cap = StrokeCap.Round
            )
        }
    }
}

/** Browser window with a red cross: pop-ups. */
@Composable
fun PopupIcon(size: Dp) {
    val pal = LocalPalette.current
    Box(Modifier.size(size)) {
        Canvas(Modifier.fillMaxSize()) {
            val w = this.size.width
            val stroke = w * 0.07f
            val left = stroke
            val top = w * 0.12f
            val boxW = w * 0.84f
            val boxH = w * 0.62f
            drawRoundRect(
                pal.primary, topLeft = Offset(left, top), size = androidx.compose.ui.geometry.Size(boxW, boxH),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(w * 0.1f), style = Stroke(width = stroke)
            )
            drawLine(pal.primary, Offset(left, top + boxH * 0.28f), Offset(left + boxW, top + boxH * 0.28f), strokeWidth = stroke)
            drawCircle(pal.primary, radius = stroke * 0.55f, center = Offset(left + w * 0.12f, top + boxH * 0.14f))
            drawCircle(pal.primary, radius = stroke * 0.55f, center = Offset(left + w * 0.24f, top + boxH * 0.14f))
            val c = Offset(w * 0.78f, w * 0.74f)
            drawCircle(DangerRed, radius = w * 0.2f, center = c)
            val d = w * 0.075f
            drawLine(Color.White, Offset(c.x - d, c.y - d), Offset(c.x + d, c.y + d), strokeWidth = w * 0.045f, cap = StrokeCap.Round)
            drawLine(Color.White, Offset(c.x + d, c.y - d), Offset(c.x - d, c.y + d), strokeWidth = w * 0.045f, cap = StrokeCap.Round)
        }
    }
}

// ---- power button -------------------------------------------------------------------------------

@Composable
fun PowerButton(on: Boolean, onClick: () -> Unit) {
    val pulse = rememberInfiniteTransition(label = "pulse")
    val glow by pulse.animateFloat(
        initialValue = 0.55f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1600), RepeatMode.Reverse), label = "glow"
    )
    val ring = if (on) listOf(Color(0xFF5BEA1A), Color(0xFF1FA52C)) else listOf(Color(0xFFB9A8E8), Color(0xFF8E7BC4))
    val iconColor = if (on) OkGreen else Color(0xFF8E7BC4)
    val glowColor = if (on) Color(0xFF4CE41F) else LocalPalette.current.glow
    Box(
        Modifier
            .size(190.dp)
            .drawBehind {
                val c = center
                val a = if (on) glow else 0.35f
                drawCircle(
                    Brush.radialGradient(listOf(glowColor.copy(alpha = 0.55f * a), Color.Transparent), center = c, radius = 95.dp.toPx()),
                    radius = 95.dp.toPx(), center = c
                )
                drawCircle(glowColor.copy(alpha = 0.35f * a), radius = 84.dp.toPx(), center = c, style = Stroke(width = 1.5.dp.toPx()))
                drawCircle(glowColor.copy(alpha = 0.25f * a), radius = 74.dp.toPx(), center = c, style = Stroke(width = 1.5.dp.toPx()))
            },
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier
                .size(140.dp)
                .shadow(14.dp, CircleShape, ambientColor = glowColor, spotColor = glowColor)
                .clip(CircleShape)
                .background(Brush.verticalGradient(ring))
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            Box(
                Modifier
                    .size(100.dp)
                    .clip(CircleShape)
                    .background(Brush.verticalGradient(listOf(Color.White, Color(0xFFF1EEF7)))),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.PowerSettingsNew, "Power", tint = iconColor, modifier = Modifier.size(58.dp))
            }
        }
    }
}

/** Thin outlined chip used for the filter rows. */
@Composable
fun PillChip(text: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val pal = LocalPalette.current
    val shape = RoundedCornerShape(50)
    val base = modifier.clip(shape).clickable(onClick = onClick)
    Box(
        if (selected) base.background(Brush.horizontalGradient(listOf(pal.primary, pal.dark)))
        else base.background(Color.White.copy(alpha = 0.9f)).border(1.dp, pal.soft, shape),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1,
            color = if (selected) Color.White else Ink,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 9.dp)
        )
    }
}
