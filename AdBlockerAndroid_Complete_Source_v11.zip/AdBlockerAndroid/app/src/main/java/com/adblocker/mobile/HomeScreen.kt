package com.adblocker.mobile

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Strict Private DNS (DNS-over-TLS to a named server) sends lookups around the blocker. */
fun strictPrivateDns(context: Context): Boolean = try {
    android.provider.Settings.Global.getString(context.contentResolver, "private_dns_mode") == "hostname"
} catch (e: Exception) {
    false
}

/** One counter of the three-column stats card (Home and Stats). */
@Composable
fun StatColumn(modifier: Modifier, icon: @Composable () -> Unit, value: String, label: String) {
    Column(modifier.padding(vertical = 14.dp, horizontal = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(36.dp), contentAlignment = Alignment.Center) { icon() }
        Spacer(Modifier.height(4.dp))
        Text(value, color = Ink, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, maxLines = 1)
        Text(label, color = Muted, fontSize = 13.sp, maxLines = 1)
    }
}

@Composable
fun MenuRow(icon: @Composable () -> Unit, title: String, subtitle: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconBubble(46.dp) { icon() }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
            Text(subtitle, color = Muted, fontSize = 12.5.sp, lineHeight = 16.sp)
        }
        Icon(Icons.Default.ChevronRight, null, tint = Ink, modifier = Modifier.size(24.dp))
    }
}

@Composable
fun HomeScreen(
    vpnOn: Boolean,
    db: AdBlockerDatabase,
    onToggle: () -> Unit,
    onOpen: (Screen) -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val sinhala = LocalLang.current == "si"
    val pal = LocalPalette.current
    val tick = rememberTick()

    val data by produceState(HomeData(), tick) {
        value = withContext(Dispatchers.IO) {
            db.flushEvents()
            val today = db.eventsSince(Fmt.startOfDay(0)).size.toLong()
            HomeData(today, db.filterCount())
        }
    }

    Column(Modifier.fillMaxSize()) {
        BrandHeader(onPro = { onOpen(Screen.PREMIUM) }) {
            RoundIconButton(Icons.Default.Settings, "Settings") { onOpen(Screen.SETTINGS) }
        }
        Column(
            Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            PowerButton(on = vpnOn, onClick = onToggle)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(tr("Ad Blocking is ", "දැන්වීම් අවහිර කිරීම "), color = Ink, fontWeight = FontWeight.ExtraBold, fontSize = 24.sp)
                Text(
                    if (vpnOn) tr("ON", "සක්‍රියයි") else tr("OFF", "අක්‍රියයි"),
                    color = if (vpnOn) OkGreen else DangerRed, fontWeight = FontWeight.ExtraBold, fontSize = 24.sp
                )
            }
            Spacer(Modifier.height(2.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    if (vpnOn) tr("You are browsing without ads", "ඔබ දැන්වීම් රහිතව බ්‍රවුස් කරයි")
                    else tr("Tap the button to turn protection on", "ආරක්ෂාව ක්‍රියාත්මක කිරීමට බොත්තම ඔබන්න"),
                    color = Muted, fontSize = 15.sp
                )
                if (vpnOn) {
                    Spacer(Modifier.width(8.dp))
                    Box(Modifier.size(22.dp).clip(CircleShape).background(OkGreen), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(15.dp))
                    }
                }
            }
            Spacer(Modifier.height(14.dp))

            // Warnings only appear when something needs the user's attention.
            if (vpnOn && strictPrivateDns(context)) {
                NoticeCard(
                    tr("Private DNS is bypassing the blocker", "Private DNS මගින් අවහිර කරන්නා මඟ හැරේ"),
                    tr("Settings > Network > Private DNS: choose Off or Automatic", "Settings > Network > Private DNS: Off හෝ Automatic තෝරන්න")
                ) { onOpen(Screen.PRIVACY) }
                Spacer(Modifier.height(10.dp))
            }
            if (data.filters == 0) {
                NoticeCard(
                    tr("Filter list not downloaded yet", "Filter list තවම බාගත කර නැත"),
                    if (vpnOn) tr("Downloading now. This takes about a minute.", "දැන් බාගත වෙමින් පවතී. විනාඩියක් පමණ ගත වේ.")
                    else tr("It downloads automatically when you turn Ad Blocking ON", "Ad Blocking ON කළ විට ස්වයංක්‍රීයව බාගත වේ")
                ) { onOpen(Screen.SETTINGS) }
                Spacer(Modifier.height(10.dp))
            }

            SoftCard(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    StatColumn(Modifier.weight(1f), { AdBadge(34.dp) }, Fmt.count(data.today), tr("Ads Blocked", "අවහිර කළ"))
                    VDivider()
                    StatColumn(
                        Modifier.weight(1f),
                        { Icon(Icons.Default.Storage, null, tint = pal.primary, modifier = Modifier.size(32.dp)) },
                        Fmt.bytes(data.today * EventKind.AVG_BYTES), tr("Data Saved", "ඉතිරි දත්ත")
                    )
                    VDivider()
                    StatColumn(
                        Modifier.weight(1f),
                        { Icon(Icons.Default.Timer, null, tint = Color(0xFF2F7BFF), modifier = Modifier.size(32.dp)) },
                        Fmt.duration(data.today * EventKind.AVG_MILLIS, sinhala), tr("Time Saved", "ඉතිරි කාලය")
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            SoftCard(Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    MenuRow(
                        { Icon(Icons.Default.VerifiedUser, null, tint = pal.primary, modifier = Modifier.size(28.dp)) },
                        tr("Blocked Items", "අවහිර කළ අයිතම"),
                        tr("View blocked ads, pop-ups and trackers", "අවහිර කළ දැන්වීම්, පොප්-අප් සහ ට්‍රැකර් බලන්න")
                    ) { onOpen(Screen.HISTORY) }
                    SoftDivider(Modifier.padding(horizontal = 14.dp))
                    MenuRow(
                        { Icon(Icons.Default.BarChart, null, tint = pal.primary, modifier = Modifier.size(28.dp)) },
                        tr("Usage Statistics", "භාවිත සංඛ්‍යාලේඛන"),
                        tr("See your ad blocking performance", "ඔබේ දැන්වීම් අවහිර කිරීමේ ක්‍රියාකාරිත්වය බලන්න")
                    ) { onOpen(Screen.STATS) }
                    SoftDivider(Modifier.padding(horizontal = 14.dp))
                    MenuRow(
                        { Icon(Icons.Default.Lock, null, tint = pal.primary, modifier = Modifier.size(28.dp)) },
                        tr("Privacy Protection", "පෞද්ගලිකත්ව ආරක්ෂාව"),
                        tr("Stop tracking and keep your data safe", "ට්‍රැකින් නවත්වා ඔබේ දත්ත ආරක්ෂිතව තබා ගන්න")
                    ) { onOpen(Screen.PRIVACY) }
                    SoftDivider(Modifier.padding(horizontal = 14.dp))
                    MenuRow(
                        { Icon(Icons.Default.RocketLaunch, null, tint = pal.primary, modifier = Modifier.size(28.dp)) },
                        tr("Browser", "බ්‍රවුසරය"),
                        tr("Fast, secure and ad-free browsing", "වේගවත්, ආරක්ෂිත සහ දැන්වීම් රහිත බ්‍රවුස් කිරීම")
                    ) { onOpen(Screen.BROWSER) }
                }
            }
            Spacer(Modifier.height(10.dp))
            Text(
                tr(
                    "DNS filtering cannot remove every ad. Ads served from the same domain as content may still appear. Data and time saved are estimates.",
                    "DNS පෙරීමෙන් සියලු දැන්වීම් ඉවත් කළ නොහැක. අන්තර්ගතයේම domain එකෙන් එන දැන්වීම් තවමත් පෙනිය හැක. ඉතිරි දත්ත සහ කාලය ඇස්තමේන්තු පමණි."
                ),
                color = Muted, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
            Spacer(Modifier.height(8.dp))
        }
    }
}

private data class HomeData(val today: Long = 0L, val filters: Int = 0)

@Composable
private fun VDivider() {
    Box(Modifier.width(1.dp).height(64.dp).background(Color(0xFFE2D8F5)))
}

@Composable
fun NoticeCard(title: String, subtitle: String, onClick: () -> Unit) {
    SoftCard(Modifier.fillMaxWidth(), onClick = onClick) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = Ink, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                Text(subtitle, color = Muted, fontSize = 12.5.sp)
            }
            Icon(Icons.Default.ChevronRight, null, tint = Ink)
        }
    }
}
