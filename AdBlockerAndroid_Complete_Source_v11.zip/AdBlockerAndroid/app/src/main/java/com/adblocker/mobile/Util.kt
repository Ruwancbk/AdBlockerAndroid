package com.adblocker.mobile

import java.util.Calendar
import java.util.Locale

/** Number, size and time formatting plus day arithmetic shared by Home, Stats and History. */
object Fmt {
    fun count(n: Long): String = String.format(Locale.US, "%,d", n)

    fun bytes(b: Long): String = when {
        b < 1_000_000L -> String.format(Locale.US, "%d KB", b / 1000L)
        b < 1_000_000_000L -> String.format(Locale.US, "%.1f MB", b / 1_000_000.0)
        else -> String.format(Locale.US, "%.2f GB", b / 1_000_000_000.0)
    }

    fun duration(millis: Long, sinhala: Boolean): String {
        val secs = millis / 1000L
        val sec = if (sinhala) "තත්පර" else "sec"
        val min = if (sinhala) "විනාඩි" else "min"
        val hour = if (sinhala) "පැය" else "h"
        return when {
            secs < 60L -> "$secs $sec"
            secs < 3600L -> "${secs / 60L} $min"
            else -> "${secs / 3600L} $hour ${(secs % 3600L) / 60L} $min"
        }
    }

    /** Midnight (local time) [daysAgo] days before today. */
    fun startOfDay(daysAgo: Int): Long {
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, 0)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        c.add(Calendar.DAY_OF_YEAR, -daysAgo)
        return c.timeInMillis
    }

    /** Whole days between the day of [millis] and today (0 = today, 1 = yesterday). */
    fun daysAgo(millis: Long): Int {
        val today = startOfDay(0)
        if (millis >= today) return 0
        val day = 24L * 60L * 60L * 1000L
        return (((today - millis) + day - 1L) / day).toInt()
    }

    fun dayLabel(daysAgo: Int, sinhala: Boolean): String {
        val c = Calendar.getInstance()
        c.add(Calendar.DAY_OF_YEAR, -daysAgo)
        val names = if (sinhala) listOf("ඉරි", "සඳු", "අඟ", "බදා", "බ්‍රහ", "සිකු", "සෙන")
        else listOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
        return names[c.get(Calendar.DAY_OF_WEEK) - 1]
    }

    fun percentChange(now: Long, before: Long): Int? =
        if (before <= 0L) null else (((now - before) * 100.0) / before).toInt()
}
