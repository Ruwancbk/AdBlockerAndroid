package com.adblocker.mobile

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.DateFormat
import java.util.Date
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val BlockedRed = Color(0xFFC62828)
private val AllowedGreen = Color(0xFF2E7D32)
private val InkColor = Color(0xFF171331)
private val SuspectOrange = Color(0xFFE65100)

/**
 * Shows every DNS lookup as it happens, grouped by the app that made it, so an ad domain that no
 * list knows can be found (play the ad, look at the log) and blocked with one tap. The log lives
 * in memory only and disappears when protection is switched off.
 */
@Composable
fun DnsLogScreen(db: AdBlockerDatabase, onBack: () -> Unit, modifier: Modifier = Modifier) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val timeFormat = remember { DateFormat.getTimeInstance(DateFormat.MEDIUM) }
    var tick by remember { mutableIntStateOf(0) }
    var tab by remember { mutableIntStateOf(0) }
    var mode by remember { mutableIntStateOf(0) } // 0 = all, 1 = blocked, 2 = allowed, 3 = suspicious
    var autoRules by remember { mutableStateOf(emptyList<AutoRule>()) }
    var appFilter by remember { mutableStateOf<String?>(null) }
    var selected by remember { mutableStateOf<DnsLogEntry?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    var ruleInput by remember { mutableStateOf("") }
    var rules by remember { mutableStateOf(emptyList<String>()) }

    LaunchedEffect(Unit) {
        while (true) {
            delay(1500)
            tick++
        }
    }
    LaunchedEffect(tab, tick) {
        if (tab == 1) rules = withContext(Dispatchers.IO) { db.customBlocked() }
        if (tab == 2) autoRules = withContext(Dispatchers.IO) { db.autoRules() }
    }

    val apps = remember(tick) { DnsActivity.apps() }
    val entries = remember(tick, mode, appFilter) {
        DnsActivity.recent()
            .filter { appFilter == null || it.appLabel == appFilter }
            .filter {
                mode == 0 || (mode == 1 && it.blocked) || (mode == 2 && !it.blocked) ||
                    (mode == 3 && !it.blocked && it.score >= AdHeuristics.SUSPECT_MIN)
            }
            .take(300)
    }
    val suspicious = remember(tick) {
        DnsActivity.recent().filter { !it.blocked && it.score >= AdHeuristics.SUSPECT_MIN }
            .map { it.domain }.distinct()
    }

    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("< Back") }
            Spacer(Modifier.weight(1f))
            if (tab == 0) {
                TextButton(onClick = {
                    copyLog(context, DnsActivity.recent().take(300), timeFormat)
                    message = "Log copied. Paste it into a chat to share it."
                }) { Text("Copy log") }
                TextButton(onClick = { DnsActivity.clearLog(); tick++ }) { Text("Clear log") }
            }
        }
        Text("DNS Log & Rules", fontSize = 26.sp, color = InkColor)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pill("Live log", tab == 0) { tab = 0 }
            Pill("My rules", tab == 1) { tab = 1 }
            Pill("Auto-blocked", tab == 2) { tab = 2 }
        }

        if (tab == 0) {
            Text(
                "Play the ad, then look here: tap a domain from that app and press Block.",
                color = Color.Gray, fontSize = 12.sp
            )
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill("All apps", appFilter == null) { appFilter = null }
                apps.take(12).forEach { app ->
                    Pill("${app.label} (${app.lookups})", appFilter == app.label) { appFilter = app.label }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill("All", mode == 0) { mode = 0 }
                Pill("Blocked", mode == 1) { mode = 1 }
                Pill("Allowed", mode == 2) { mode = 2 }
                Pill("Suspicious (${suspicious.size})", mode == 3) { mode = 3 }
            }
            if (mode == 3 && suspicious.isNotEmpty()) {
                Button(
                    onClick = {
                        scope.launch {
                            val count = withContext(Dispatchers.IO) {
                                suspicious.count { db.learnBlock(it, 100, "Reviewed in log (suspicious name)", "", "You") }
                            }
                            message = "Blocked $count suspicious names"
                            tick++
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Block all ${suspicious.size} suspicious names") }
            }
            if (entries.isEmpty()) {
                Text(
                    "No lookups yet. Turn Ad Blocking ON and use an app.",
                    color = Color.Gray, modifier = Modifier.padding(top = 12.dp)
                )
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.weight(1f)) {
                items(entries) { entry ->
                    Surface(
                        color = Color.White,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().clickable { selected = entry }
                    ) {
                        Column(Modifier.padding(12.dp)) {
                            Text(
                                entry.domain, color = InkColor, fontSize = 15.sp,
                                maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                            val suspect = !entry.blocked && entry.score >= AdHeuristics.SUSPECT_MIN
                            Text(
                                (if (entry.blocked) "Blocked: ${entry.reason}"
                                else if (suspect) "Allowed - looks suspicious (score ${entry.score})"
                                else "Allowed") +
                                    "  -  ${entry.appLabel}  -  ${timeFormat.format(Date(entry.time))}",
                                color = if (entry.blocked) BlockedRed else if (suspect) SuspectOrange else AllowedGreen,
                                fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        } else if (tab == 2) {
            Text(
                "Names the blocker blocked by itself: ad-looking names, aliases that hide a tracker, and names " +
                    "you approved as suspicious. Tap Allow if one of them is wrong.",
                color = Color.Gray, fontSize = 12.sp
            )
            if (autoRules.isEmpty()) {
                Text("Nothing learned yet. Use some apps with protection on.", color = Color.Gray)
            } else {
                TextButton(onClick = {
                    scope.launch {
                        withContext(Dispatchers.IO) { db.clearAutoRules() }
                        message = "Learned rules cleared"
                        tick++
                    }
                }) { Text("Forget all learned rules") }
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                items(autoRules.take(400)) { rule ->
                    Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(rule.domain, color = InkColor, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(
                                    "${rule.why}  -  ${rule.app}  -  ${timeFormat.format(Date(rule.time))}",
                                    color = Color.Gray, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis
                                )
                            }
                            TextButton(onClick = {
                                scope.launch {
                                    withContext(Dispatchers.IO) { db.allowAutoRule(rule.domain) }
                                    message = "Allowed ${rule.domain}"
                                    tick++
                                }
                            }) { Text("Allow") }
                        }
                    }
                }
            }
        } else {
            Text(
                "Domains you block here (and everything under them) stay blocked, even after list updates.",
                color = Color.Gray, fontSize = 12.sp
            )
            OutlinedTextField(
                value = ruleInput, onValueChange = { ruleInput = it },
                modifier = Modifier.fillMaxWidth(), label = { Text("ads.example.com") },
                singleLine = true
            )
            Button(
                onClick = {
                    val domain = DomainUtil.normalizeHost(ruleInput)
                    if (DomainUtil.validDomain(domain)) {
                        scope.launch {
                            withContext(Dispatchers.IO) { db.addCustomBlock(domain) }
                            ruleInput = ""
                            message = "Blocked $domain"
                            tick++
                        }
                    } else {
                        message = "Enter a valid domain such as ads.example.com"
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Block this domain") }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                items(rules) { domain ->
                    Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(domain, modifier = Modifier.weight(1f), color = InkColor)
                            TextButton(onClick = {
                                scope.launch {
                                    withContext(Dispatchers.IO) { db.removeCustomBlock(domain) }
                                    tick++
                                }
                            }) { Text("Remove") }
                        }
                    }
                }
            }
        }

        message?.let { Text(it, color = MaterialTheme.colorScheme.primary, fontSize = 13.sp) }
    }

    selected?.let { entry ->
        AlertDialog(
            onDismissRequest = { selected = null },
            title = { Text(entry.domain, maxLines = 2, overflow = TextOverflow.Ellipsis) },
            text = {
                Column {
                    Text(
                        (if (entry.blocked) "Blocked: ${entry.reason}" else "Allowed (ad score ${entry.score})") +
                            "\nApp: ${entry.appLabel}",
                        fontSize = 13.sp
                    )
                    Spacer(Modifier.width(1.dp))
                    DomainUtil.blockChoices(entry.domain).take(3).forEach { choice ->
                        TextButton(onClick = {
                            scope.launch {
                                withContext(Dispatchers.IO) { db.addCustomBlock(choice) }
                                message = "Blocked $choice and everything under it"
                                selected = null
                            }
                        }) { Text("Block $choice", maxLines = 1, overflow = TextOverflow.Ellipsis) }
                    }
                    TextButton(onClick = {
                        scope.launch {
                            withContext(Dispatchers.IO) { db.addAllowedDomain(entry.domain) }
                            message = "Allowed ${entry.domain}"
                            selected = null
                        }
                    }) { Text("Always allow ${entry.domain}", maxLines = 1, overflow = TextOverflow.Ellipsis) }
                }
            },
            confirmButton = { TextButton(onClick = { selected = null }) { Text("Close") } }
        )
    }
}

@Composable
private fun Pill(text: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        color = if (selected) MaterialTheme.colorScheme.primary else Color.White,
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.clickable { onClick() }
    ) {
        Text(
            text,
            color = if (selected) Color.White else InkColor,
            fontSize = 13.sp, maxLines = 1,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
        )
    }
}

/** Puts the log on the clipboard as plain text so it can be pasted into a chat. */
private fun copyLog(context: Context, entries: List<DnsLogEntry>, timeFormat: DateFormat) {
    val text = buildString {
        append("time | result | domain | app | detail\n")
        for (e in entries) {
            append(timeFormat.format(Date(e.time))).append(" | ")
            append(if (e.blocked) "BLOCKED" else "ALLOWED").append(" | ")
            append(e.domain).append(" | ").append(e.appLabel).append(" | ")
            append(if (e.blocked) e.reason else "score ${e.score}").append('\n')
        }
    }
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText("DNS log", text))
}
