package com.adblocker.mobile

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat

enum class Screen { HOME, BROWSER, STATS, PREMIUM, SETTINGS, HISTORY, PRIVACY, WHITELIST, LOG }

class MainActivity : ComponentActivity() {

    private val vpnPermission = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) startVpn()
    }

    // The notification permission is optional: the VPN works either way, but without it
    // Android 13+ hides the "Ad Blocker is active" notification.
    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { requestVpnPermission() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT)
        )
        AppPrefs.load(this)
        FilterListUpdater(this).scheduleDailyUpdates()
        setContent {
            AdBlockerRoot(
                onEnableVpn = { enableVpn() },
                onDisableVpn = {
                    AppPrefs.setProtectionWanted(this, false)
                    startService(Intent(this, DnsVpnService::class.java).setAction(DnsVpnService.ACTION_STOP))
                }
            )
        }
    }

    private fun enableVpn() {
        val needsNotificationPermission = Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        if (needsNotificationPermission) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            requestVpnPermission()
        }
    }

    private fun requestVpnPermission() {
        val intent = VpnService.prepare(this)
        if (intent == null) startVpn() else vpnPermission.launch(intent)
    }

    private fun startVpn() {
        AppPrefs.setProtectionWanted(this, true)
        ContextCompat.startForegroundService(
            this, Intent(this, DnsVpnService::class.java).setAction(DnsVpnService.ACTION_START)
        )
    }
}

@Composable
private fun AdBlockerRoot(onEnableVpn: () -> Unit, onDisableVpn: () -> Unit) {
    val context = LocalContext.current
    var language by remember { mutableStateOf(AppPrefs.language) }
    var theme by remember { mutableStateOf(AppPrefs.theme) }
    var onboarding by remember { mutableStateOf(!AppPrefs.onboardingDone(context)) }
    val palette = Palettes[theme] ?: Palettes.getValue("purple")
    val onLanguage = { code: String ->
        language = code
        AppPrefs.setText(context, "language", code)
    }
    val onTheme = { key: String ->
        theme = key
        AppPrefs.setText(context, "theme", key)
    }

    CompositionLocalProvider(LocalPalette provides palette, LocalLang provides language) {
        MaterialTheme(
            colorScheme = lightColorScheme(
                primary = palette.primary, onPrimary = Color.White, secondary = palette.dark,
                background = Color.Transparent, surface = Color.White
            )
        ) {
            AppBackground {
                if (onboarding) {
                    OnboardingScreen(language, onLanguage) {
                        AppPrefs.setOnboardingDone(context)
                        onboarding = false
                    }
                } else {
                    MainShell(language, theme, onLanguage, onTheme, onEnableVpn, onDisableVpn)
                }
            }
        }
    }
}

@Composable
private fun MainShell(
    language: String,
    theme: String,
    onLanguage: (String) -> Unit,
    onTheme: (String) -> Unit,
    onEnableVpn: () -> Unit,
    onDisableVpn: () -> Unit
) {
    val context = LocalContext.current
    val db = remember { AdBlockerDatabase.get(context) }
    val prefs = remember { context.getSharedPreferences("settings", Context.MODE_PRIVATE) }
    val vpnOn by DnsVpnService.active
    val stack = remember { mutableStateListOf(Screen.HOME) }
    val screen = stack.last()
    var urlInput by remember { mutableStateOf("https://example.com") }
    var browserUrl by remember { mutableStateOf("https://example.com") }

    fun navigate(target: Screen) {
        when (target) {
            Screen.HOME, Screen.BROWSER, Screen.STATS, Screen.PREMIUM -> {
                stack.clear()
                stack.add(Screen.HOME)
                if (target != Screen.HOME) stack.add(target)
            }
            else -> if (stack.last() != target) stack.add(target)
        }
    }

    fun back() {
        if (stack.size > 1) stack.removeAt(stack.lastIndex)
    }

    BackHandler(enabled = stack.size > 1) { back() }

    val showNav = screen == Screen.HOME || screen == Screen.BROWSER || screen == Screen.STATS || screen == Screen.PREMIUM

    Column(Modifier.fillMaxSize().imePadding()) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (screen) {
                Screen.HOME -> HomeScreen(
                    vpnOn = vpnOn, db = db,
                    onToggle = { if (vpnOn) onDisableVpn() else onEnableVpn() },
                    onOpen = { navigate(it) }
                )
                Screen.BROWSER -> BrowserScreen(
                    db = db, urlInput = urlInput, browserUrl = browserUrl,
                    onInput = { urlInput = it }, onGo = { browserUrl = it },
                    javaScript = prefs.getBoolean("js", false),
                    blockAds = prefs.getBoolean("browser_block", true),
                    onPro = { navigate(Screen.PREMIUM) }, onSettings = { navigate(Screen.SETTINGS) }
                )
                Screen.STATS -> StatsScreen(db, onPro = { navigate(Screen.PREMIUM) })
                Screen.PREMIUM -> PremiumScreen(onPro = { navigate(Screen.PREMIUM) })
                Screen.HISTORY -> HistoryScreen(db, onBack = { back() })
                Screen.SETTINGS -> SettingsScreen(
                    db = db, vpnOn = vpnOn, language = language, theme = theme,
                    onBack = { back() }, onPro = { navigate(Screen.PREMIUM) }, onOpen = { navigate(it) },
                    onLanguage = onLanguage, onTheme = onTheme
                )
                Screen.PRIVACY -> PrivacyScreen(
                    db = db, vpnOn = vpnOn, onBack = { back() }, onPro = { navigate(Screen.PREMIUM) },
                    onOpen = { navigate(it) }
                )
                Screen.WHITELIST -> WhitelistScreen(db, onBack = { back() })
                Screen.LOG -> DnsLogScreen(db = db, onBack = { back() }, modifier = Modifier.statusBarsPadding())
            }
        }
        if (showNav) {
            BottomPillNav(
                listOf(
                    NavEntry(tr("Home", "මුල් පිටුව"), Icons.Default.Home, screen == Screen.HOME) { navigate(Screen.HOME) },
                    NavEntry(tr("Browser", "බ්‍රවුසරය"), Icons.Default.Language, screen == Screen.BROWSER) { navigate(Screen.BROWSER) },
                    NavEntry(tr("Stats", "සංඛ්‍යා"), Icons.Default.BarChart, screen == Screen.STATS) { navigate(Screen.STATS) },
                    NavEntry(tr("Premium", "Premium"), Icons.Default.WorkspacePremium, screen == Screen.PREMIUM) { navigate(Screen.PREMIUM) }
                )
            )
        }
    }
}
