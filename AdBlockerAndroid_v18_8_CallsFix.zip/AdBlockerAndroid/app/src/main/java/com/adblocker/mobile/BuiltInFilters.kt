package com.adblocker.mobile

/**
 * Ad-network and ad-SDK domains that ship inside the app, so blocking works from the first
 * second and even when the online lists cannot be downloaded. Every entry also blocks its
 * subdomains. If one of these breaks something you need, add it to the Allowlist.
 */
object BuiltInFilters {
    /** Bump when the list below changes so installed copies get refreshed. */
    const val VERSION = "4"
    const val SOURCE = "Built-in"

    val DOMAINS: Set<String> = linkedSetOf(
        // Video / in-app ad networks used by games and utility apps
        "applovin.com", "applvn.com", "unityads.unity3d.com", "config.unity3d.com",
        "supersonicads.com", "ironsrc.com", "vungle.com", "chartboost.com",
        "mintegral.com", "mintegral.net", "mtgglobals.com", "rayjump.com",
        "pangleglobal.com", "pangle.io", "inmobi.com", "inmobicdn.net",
        "adcolony.com", "startappservice.com", "startappexchange.com", "tapjoy.com",
        "fyber.com", "inner-active.mobi", "smaato.net", "mopub.com", "ogury.co",
        "presage.io", "bigossp.com", "mobvista.com", "an.facebook.com",
        // Google / Amazon ad serving
        "doubleclick.net", "googleads.g.doubleclick.net", "pagead2.googlesyndication.com",
        "googlesyndication.com", "googleadservices.com", "adservice.google.com",
        "amazon-adsystem.com",
        // Content-recommendation / banner networks
        "taboola.com", "outbrain.com", "criteo.com", "criteo.net", "adnxs.com",
        "rubiconproject.com", "pubmatic.com", "openx.net", "adsrvr.org", "moatads.com",
        // SHAREit's own servers (feed, video and ad delivery). File transfer between phones
        // is local and keeps working; allowlist these if you need SHAREit's online features.
        "wshareit.com", "ushareit.com", "shareitgames.com", "shareitpp.com",
        // More SDK / exchange / OEM ad servers (the name detector catches the rest)
        "liftoff.io", "adjoe.io", "appnext.com", "bidmachine.io", "pubnative.net",
        "adsmoloco.com", "samsungads.com", "samsungadhub.com", "adkernel.com", "adform.net",
        "smartadserver.com", "teads.tv", "yieldmo.com", "gumgum.com", "mgid.com", "adsterra.com",
        "propellerads.com", "exoclick.com", "popads.net", "clickadu.com", "hilltopads.com",
        "adsafeprotected.com", "scorecardresearch.com", "quantserve.com", "demdex.net",
        "bluekai.com", "krxd.net",
        // Pop-up / pop-under / redirect networks used by torrent and streaming sites
        "popcash.net", "onclickads.net", "onclkds.com", "tsyndicate.com", "monetag.com",
        "profitablecpmrate.com", "profitablegatecpm.com", "effectivegatecpm.com",
        "highperformanceformat.com", "adcash.com", "admaven.com", "ad-maven.com", "a-ads.com",
        "adtng.com", "juicyads.me", "ero-advertising.com", "trafficfactory.biz", "clkmg.com",
        "oclasrv.com", "ocmtag.com", "adsco.re", "bidvertiser.com", "revenuehits.com",
        "zeropark.com", "popmyads.com", "popunderjs.com", "hilltopads.net", "adspyglass.com",
        // More mobile ad SDKs / mediation / OEM ad servers (SHAREit-type apps use several at once)
        "anythinktech.com", "toponad.com", "toponad.net", "adshonor.com", "bigoads.com", "tapdaq.com",
        "kidoz.net", "yandexadexchange.net", "2mdn.net", "googletagservices.com", "ad-delivery.net",
        "ads-api.tiktok.com", "ads-sg.tiktok.com", "ad.xiaomi.com", "ads.heytapmobi.com",
        "adx.ads.oppomobile.com", "adsfs.oppomobile.com", "casalemedia.com", "indexww.com",
        "bidswitch.net", "tremorhub.com", "spotxchange.com", "serving-sys.com", "everesttech.net",
        "adgrx.com", "adtelligent.com", "bidr.io", "mathtag.com", "advertising.com", "adsymptotic.com",
        "sharethrough.com", "triplelift.com", "33across.com", "sovrn.com", "lijit.com", "contextweb.com",
        "rtbhouse.com", "adroll.com", "appier.net", "mobfox.com", "mobilefuse.com", "inmobi.net",
        "unityads.unity3d.com", "adservice.unity3d.com", "ads-twitter.com",
        "adsafeprotected.com", "doubleverify.com", "iasds01.com", "pagead2.googlesyndication.com",
        // Firefox asks this name before it switches to DNS-over-HTTPS. An NXDOMAIN answer tells
        // it to keep using normal DNS, which is the one this blocker filters.
        "use-application-dns.net"
    )
}

/**
 * Calling / messaging infrastructure that must never be blocked: if one of these names fails to
 * resolve, calls cannot connect or ring. Checked before every list, learned rule, CNAME check and
 * the upstream filter's veto. A listed name also covers its subdomains.
 */
object NeverBlock {
    private val DOMAINS = setOf(
        "whatsapp.net", "whatsapp.com", "wa.me", "signal.org", "whispersystems.org", "signal.me",
        "telegram.org", "t.me", "telegram.me", "zoom.us", "zoom.com", "zoomgov.com",
        "meet.google.com", "mtalk.google.com", "alt1-mtalk.google.com", "alt2-mtalk.google.com",
        "alt3-mtalk.google.com", "alt4-mtalk.google.com", "alt5-mtalk.google.com", "alt6-mtalk.google.com",
        "alt7-mtalk.google.com", "alt8-mtalk.google.com", "fcm.googleapis.com", "fcm-xmpp.googleapis.com",
        "firebaseinstallations.googleapis.com", "stun.l.google.com", "stun1.l.google.com",
        "stun2.l.google.com", "stun3.l.google.com", "stun4.l.google.com", "tachyon.googleapis.com",
        "edge-mqtt.facebook.com", "mqtt.facebook.com", "mqtt-mini.facebook.com", "star.c10r.facebook.com",
        "star-mini.c10r.facebook.com", "edge-chat.facebook.com", "skype.com", "teams.microsoft.com",
        "lync.com", "mtalk4.google.com"
    )

    fun covers(host: String): Boolean {
        var candidate = host.lowercase().trim('.')
        while (candidate.contains('.')) {
            if (candidate in DOMAINS) return true
            candidate = candidate.substringAfter('.')
        }
        return false
    }
}
