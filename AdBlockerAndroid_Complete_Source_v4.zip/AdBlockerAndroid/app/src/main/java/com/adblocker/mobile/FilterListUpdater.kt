package com.adblocker.mobile

import android.content.Context
import androidx.work.*
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.TimeUnit

class FilterListUpdater(private val context: Context) {
    companion object {
        const val FILTER_URL = "https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts"
        const val SOURCE_ID = "stevenblack_hosts"
        private const val MAX_BYTES = 15 * 1024 * 1024
    }

    fun update(onComplete: (Result<Int>) -> Unit) {
        Thread {
            val result = runCatching { downloadAndSave(context) }
            android.os.Handler(android.os.Looper.getMainLooper()).post { onComplete(result) }
        }.start()
    }

    fun scheduleDailyUpdates() {
        val request = PeriodicWorkRequestBuilder<FilterUpdateWorker>(24, TimeUnit.HOURS)
            .setConstraints(
                Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
            )
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            "adblocker_filter_update", ExistingPeriodicWorkPolicy.KEEP, request
        )
    }

    fun updateNow(): Result<Int> = downloadAndSave(context)

    private fun downloadAndSave(context: Context): Result<Int> = runCatching {
        val connection = (URL(FILTER_URL).openConnection() as HttpURLConnection).apply {
            connectTimeout = 12_000
            readTimeout = 20_000
            requestMethod = "GET"
            setRequestProperty("User-Agent", "AdBlockerAndroid/1.0")
        }
        val body = try {
            if (connection.responseCode !in 200..299) error("Filter server error: ${connection.responseCode}")
            connection.inputStream.use { input ->
                val out = java.io.ByteArrayOutputStream()
                val buffer = ByteArray(8192)
                var total = 0
                while (true) {
                    val n = input.read(buffer)
                    if (n < 0) break
                    total += n
                    require(total <= MAX_BYTES) { "Filter file exceeds size limit" }
                    out.write(buffer, 0, n)
                }
                out.toString("UTF-8")
            }
        } finally { connection.disconnect() }

        val domains = parseHosts(body)
        require(domains.size >= 100) { "Filter list validation failed" }
        AdBlockerDatabase(context).replaceRemoteDomains(domains, SOURCE_ID)
        domains.size
    }

    private fun parseHosts(text: String): Set<String> {
        val result = LinkedHashSet<String>()
        text.lineSequence().forEach { raw ->
            val line = raw.substringBefore('#').trim()
            if (line.isEmpty()) return@forEach
            val fields = line.split(Regex("\\s+"))
            if (fields.size < 2) return@forEach
            if (fields[0] !in setOf("0.0.0.0", "127.0.0.1", "::", "::1")) return@forEach
            fields.drop(1).forEach { rawHost ->
                val host = AdBlockerDatabase.normalizeHost(rawHost)
                if (AdBlockerDatabase.validDomain(host) && host != "localhost") result += host
            }
        }
        return result
    }
}

class FilterUpdateWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        val update = FilterListUpdater(applicationContext).updateNow()
        return if (update.isSuccess) Result.success()
        else if (runAttemptCount < 3) Result.retry() else Result.failure()
    }
}
