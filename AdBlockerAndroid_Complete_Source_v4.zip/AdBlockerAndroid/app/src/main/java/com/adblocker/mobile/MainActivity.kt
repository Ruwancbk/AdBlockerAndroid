package com.adblocker.mobile

import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.webkit.*
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import java.text.DateFormat
import java.util.Date

private val Purple = Color(0xFF6514D5)
private val Pale = Color(0xFFF5F0FF)
private val Ink = Color(0xFF171331)
private val Green = Color(0xFF16B84A)

class MainActivity : ComponentActivity() {
    private var pendingEnable by mutableStateOf(false)

    private val vpnPermission = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK && pendingEnable) startVpn()
        pendingEnable = false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FilterListUpdater(this).scheduleDailyUpdates()
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(
                primary = Purple, secondary = Color(0xFF8C42F5),
                background = Pale, surface = Color.White
            )) {
                AdBlockerApp(
                    onEnableVpn = {
                        val intent = VpnService.prepare(this)
                        if (intent == null) startVpn()
                        else {
                            pendingEnable = true
                            vpnPermission.launch(intent)
                        }
                    },
                    onDisableVpn = {
                        startService(Intent(this, DnsVpnService::class.java).setAction(DnsVpnService.ACTION_STOP))
                    }
                )
            }
        }
    }

    private fun startVpn() {
        ContextCompat.startForegroundService(
            this, Intent(this, DnsVpnService::class.java).setAction(DnsVpnService.ACTION_START)
        )
    }
}

private enum class Screen(val label: String) {
    HOME("Home"), BROWSER("Browser"), STATS("Stats"), HISTORY("History"),
    TOOLS("Tools"), SETTINGS("Settings"), WHITELIST("Whitelist"), PREMIUM("Premium")
}

@Composable
private fun AdBlockerApp(onEnableVpn: () -> Unit, onDisableVpn: () -> Unit) {
    val context = LocalContext.current
    val db = remember { AdBlockerDatabase(context) }
    var screen by remember { mutableStateOf(Screen.HOME) }
    var vpnOn by remember { mutableStateOf(false) }
    var popups by remember { mutableStateOf(true) }
    var trackers by remember { mutableStateOf(true) }
    var notifications by remember { mutableStateOf(true) }
    var url by remember { mutableStateOf("https://example.com") }
    var allowInput by remember { mutableStateOf("") }
    var filterStatus by remember { mutableStateOf("Checking filter status…") }
    var updating by remember { mutableStateOf(false) }
    var refresh by remember { mutableIntStateOf(0) }
    val updater = remember { FilterListUpdater(context) }

    LaunchedEffect(Unit) {
        filterStatus = if (db.lastUpdateMillis() > 0)
            "${db.filterCount()} domains • updated ${DateFormat.getDateTimeInstance().format(Date(db.lastUpdateMillis()))}"
        else "No filter list downloaded yet"
    }

    Scaffold(
        containerColor = Pale,
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                listOf(Screen.HOME, Screen.BROWSER, Screen.STATS, Screen.TOOLS, Screen.SETTINGS).forEach { item ->
                    NavigationBarItem(
                        selected = screen == item,
                        onClick = { screen = item; refresh++ },
                        icon = {
                            Icon(when (item) {
                                Screen.HOME -> Icons.Default.Home
                                Screen.BROWSER -> Icons.Default.Language
                                Screen.STATS -> Icons.Default.BarChart
                                Screen.TOOLS -> Icons.Default.Build
                                else -> Icons.Default.Settings
                            }, contentDescription = item.label)
                        },
                        label = { Text(item.label) }
                    )
                }
            }
        }
    ) { padding ->
        when (screen) {
            Screen.HOME -> LazyColumn(
                Modifier.fillMaxSize().padding(padding).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item { AppHeader(onPro = { screen = Screen.PREMIUM }) }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(28.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Button(
                                onClick = {
                                    if (vpnOn) onDisableVpn() else onEnableVpn()
                                    vpnOn = !vpnOn
                                },
                                modifier = Modifier.size(142.dp),
                                shape = RoundedCornerShape(100.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = if (vpnOn) Green else Purple)
                            ) { Icon(Icons.Default.PowerSettingsNew, null, modifier = Modifier.size(64.dp)) }
                            Spacer(Modifier.height(12.dp))
                            Text(if (vpnOn) "Ad Blocking is ON" else "Ad Blocking is OFF", fontSize = 23.sp, color = Ink)
                            Text(if (vpnOn) "DNS protection enabled" else "Tap to enable system-wide protection", color = Color.Gray)
                        }
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Metric("Blocked", db.eventCount().toString(), Modifier.weight(1f))
                        Metric("Filter domains", db.filterCount().toString(), Modifier.weight(1f))
                        Metric("Whitelist", db.allowedDomains().size.toString(), Modifier.weight(1f))
                    }
                }
                item { MenuRow("Blocked Items History", "Review recently blocked domains") { screen = Screen.HISTORY } }
                item { MenuRow("Allowed Websites", "Choose sites that should never be blocked") { screen = Screen.WHITELIST } }
                item { MenuRow("Usage Statistics", "See your protection activity") { screen = Screen.STATS } }
                item { MenuRow("Ad Blocker Pro", "Explore premium features") { screen = Screen.PREMIUM } }
                item { Text("DNS filtering cannot remove every ad. Ads served from the same domain as content may still appear.", color = Color.Gray, fontSize = 12.sp) }
            }

            Screen.BROWSER -> Column(Modifier.fillMaxSize().padding(padding).padding(12.dp)) {
                AppHeader(onPro = { screen = Screen.PREMIUM })
                OutlinedTextField(
                    value = url, onValueChange = { url = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Search or enter website URL") },
                    trailingIcon = {
                        IconButton(onClick = {
                            if (!url.startsWith("http://") && !url.startsWith("https://")) {
                                url = "https://www.google.com/search?q=${java.net.URLEncoder.encode(url, "UTF-8")}"
                            }
                        }) { Icon(Icons.Default.Search, null) }
                    },
                    singleLine = true
                )
                Spacer(Modifier.height(8.dp))
                BrowserPane(url, db, modifier = Modifier.weight(1f))
            }

            Screen.STATS -> LazyColumn(Modifier.fillMaxSize().padding(padding).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item { AppHeader(onPro = { screen = Screen.PREMIUM }) }
                item { Text("Usage Statistics", fontSize = 28.sp, color = Ink) }
                item { Metric("Blocked events", db.eventCount().toString(), Modifier.fillMaxWidth()) }
                item { Metric("Domains in filter list", db.filterCount().toString(), Modifier.fillMaxWidth()) }
                item { Metric("Allowed websites", db.allowedDomains().size.toString(), Modifier.fillMaxWidth()) }
                item { MenuRow("Filter list source", db.filterSource()) {} }
                item { MenuRow("Last filter update", if (db.lastUpdateMillis() > 0) DateFormat.getDateTimeInstance().format(Date(db.lastUpdateMillis())) else "Never") {} }
                item { Text("Data and time-saved estimates are not reported until measured reliably; this build does not invent those values.", color = Color.Gray, fontSize = 12.sp) }
            }

            Screen.HISTORY -> {
                val events = remember(refresh) { db.recentEvents(200) }
                Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Blocked Items History", fontSize = 23.sp, color = Ink, modifier = Modifier.weight(1f))
                        TextButton(onClick = { db.clearHistory(); refresh++ }) { Text("Clear") }
                    }
                    if (events.isEmpty()) Text("No blocked events recorded yet.", color = Color.Gray)
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(events) { event ->
                            MenuRow(event.domain, "${event.category} • ${DateFormat.getDateTimeInstance().format(Date(event.timestamp))}") {}
                        }
                    }
                }
            }

            Screen.WHITELIST -> {
                val allowed = remember(refresh) { db.allowedDomains() }
                Column(Modifier.fillMaxSize().padding(padding).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Allowed Websites", fontSize = 26.sp, color = Ink)
                    Text("Domains added here are excluded from the downloaded DNS block list.", color = Color.Gray)
                    OutlinedTextField(
                        value = allowInput, onValueChange = { allowInput = it },
                        modifier = Modifier.fillMaxWidth(), label = { Text("example.com") },
                        singleLine = true
                    )
                    Button(onClick = {
                        if (db.addAllowedDomain(allowInput)) {
                            allowInput = ""; refresh++
                        } else {
                            android.widget.Toast.makeText(context, "Enter a valid domain such as example.com", android.widget.Toast.LENGTH_LONG).show()
                        }
                    }, modifier = Modifier.fillMaxWidth()) { Text("Add to Allowlist") }
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(allowed) { domain ->
                            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text(domain, modifier = Modifier.weight(1f), color = Ink)
                                    TextButton(onClick = { db.removeAllowedDomain(domain); refresh++ }) { Text("Remove") }
                                }
                            }
                        }
                    }
                }
            }

            Screen.TOOLS -> LazyColumn(Modifier.fillMaxSize().padding(padding).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item { AppHeader(onPro = { screen = Screen.PREMIUM }) }
                item { Text("Tools", fontSize = 28.sp, color = Ink) }
                item { MenuRow("Privacy Check", "Review tracker filtering status") { screen = Screen.SETTINGS } }
                item { MenuRow("Filter List Manager", "Update and inspect domain filters") { screen = Screen.SETTINGS } }
                item { MenuRow("Download Manager", "Downloads are managed by Android WebView") {} }
                item { MenuRow("Speed Test", "Not included in this offline starter build") {} }
            }

            Screen.SETTINGS -> Column(Modifier.fillMaxSize().padding(padding).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)) {
                AppHeader(onPro = { screen = Screen.PREMIUM })
                Text("Settings", fontSize = 28.sp, color = Ink)
                ToggleRow("Block pop-ups in browser", popups) { popups = it }
                ToggleRow("Block known trackers", trackers) { trackers = it }
                ToggleRow("Notifications", notifications) { notifications = it }
                MenuRow("Allowed Websites", "Manage exceptions") { screen = Screen.WHITELIST }
                MenuRow("Filter list", filterStatus) {}
                Button(
                    onClick = {
                        updating = true
                        filterStatus = "Downloading and validating filter list…"
                        updater.update { result ->
                            updating = false
                            filterStatus = result.fold(
                                { "$it domains • updated ${DateFormat.getDateTimeInstance().format(Date(db.lastUpdateMillis()))}" },
                                { "Update failed: ${it.message ?: "unknown error"}" }
                            )
                            refresh++
                        }
                    },
                    enabled = !updating,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (updating) CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                    else Icon(Icons.Default.Refresh, null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (updating) "Updating…" else "Update Filter List Now")
                }
                Text("Automatic updates are scheduled approximately every 24 hours when a network is available.", color = Color.Gray, fontSize = 12.sp)
                MenuRow("About Ad Blocker", "Version 1.0.0 • DNS filtering prototype") {}
            }

            Screen.PREMIUM -> Column(Modifier.fillMaxSize().padding(padding).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                AppHeader(onPro = { screen = Screen.PREMIUM })
                Text("Ad Blocker Pro", fontSize = 30.sp, color = Purple)
                Text("More privacy. Cleaner browsing.", color = Ink)
                listOf("Advanced filter lists", "Custom allowlist controls", "Priority filter updates", "Premium support").forEach {
                    MenuRow(it, "Premium feature preview") {}
                }
                Text("Subscription and payment processing are not connected in this source build.", color = Color.Gray, fontSize = 12.sp)
                Button(onClick = { screen = Screen.HOME }) { Text("Back to Home") }
            }
        }
    }
}

@Composable
private fun AppHeader(onPro: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Surface(color = Purple, shape = RoundedCornerShape(12.dp)) {
            Text("AD", color = Color.White, modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp))
        }
        Spacer(Modifier.width(10.dp))
        Text("Ad Blocker", fontSize = 23.sp, color = Ink, modifier = Modifier.weight(1f))
        TextButton(onClick = onPro) { Text("👑 PRO", color = Purple) }
    }
}

@Composable
private fun Metric(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, color = Purple, fontSize = 21.sp)
            Text(title, color = Ink, fontSize = 11.sp)
        }
    }
}

@Composable
private fun MenuRow(title: String, subtitle: String, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = Ink, fontSize = 16.sp)
                Text(subtitle, color = Color.Gray, fontSize = 12.sp)
            }
            Icon(Icons.Default.ChevronRight, null, tint = Purple)
        }
    }
}

@Composable
private fun ToggleRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = Ink, modifier = Modifier.weight(1f))
            Switch(checked = checked, onCheckedChange = onChange)
        }
    }
}

@Composable
private fun BrowserPane(url: String, db: AdBlockerDatabase, modifier: Modifier = Modifier) {
    AndroidView(
        modifier = modifier.fillMaxWidth(),
        factory = { context ->
            WebView(context).apply {
                settings.javaScriptEnabled = false
                settings.domStorageEnabled = false
                webViewClient = object : WebViewClient() {
                    override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                        val host = request?.url?.host?.lowercase() ?: return null
                        if (db.isDomainBlocked(host)) {
                            db.addBlockedEvent(host, "Browser")
                            return WebResourceResponse(
                                "text/plain", "utf-8", 204, "Blocked",
                                emptyMap(), java.io.ByteArrayInputStream(byteArrayOf())
                            )
                        }
                        return null
                    }
                }
            }
        },
        update = { web ->
            val value = url.trim()
            if (value.isNotBlank()) {
                val target = if (value.startsWith("https://") || value.startsWith("http://")) value else "https://$value"
                if (web.url != target) web.loadUrl(target)
            }
        }
    )
}
