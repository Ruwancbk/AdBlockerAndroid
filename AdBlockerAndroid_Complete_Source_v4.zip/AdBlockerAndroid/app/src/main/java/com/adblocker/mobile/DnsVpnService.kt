package com.adblocker.mobile

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

/**
 * DNS-only local VPN:
 * - Routes only the synthetic DNS server address through TUN.
 * - Forwards allowed IPv4 DNS queries to 1.1.1.1.
 * - Returns NXDOMAIN for domains in the bundled starter list.
 *
 * This is intentionally a minimal starter implementation, not a full packet VPN.
 */
class DnsVpnService : VpnService() {
    companion object {
        const val ACTION_START = "com.adblocker.mobile.START"
        const val ACTION_STOP = "com.adblocker.mobile.STOP"
        private const val CHANNEL = "adblocker_vpn"
        private const val NOTIFICATION_ID = 42
    }

    private var tun: ParcelFileDescriptor? = null
    private val running = AtomicBoolean(false)
    private lateinit var database: AdBlockerDatabase

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopVpn()
            else -> startVpn()
        }
        return START_STICKY
    }

    private fun startVpn() {
        if (running.get()) return
        database = AdBlockerDatabase(this)
        createChannel()
        startForeground(NOTIFICATION_ID, notification())
        val descriptor = Builder()
            .setSession("Ad Blocker DNS")
            .setMtu(1500)
            .addAddress("10.10.10.2", 32)
            .addDnsServer("10.10.10.1")
            .addRoute("10.10.10.1", 32)
            .establish() ?: run { stopSelf(); return }

        tun = descriptor
        running.set(true)
        thread(name = "AdBlockerDnsTun") { packetLoop(descriptor) }
    }

    private fun packetLoop(descriptor: ParcelFileDescriptor) {
        val input = FileInputStream(descriptor.fileDescriptor)
        val output = FileOutputStream(descriptor.fileDescriptor)
        val buffer = ByteArray(32767)
        while (running.get()) {
            try {
                val length = input.read(buffer)
                if (length <= 0) continue
                val packet = buffer.copyOf(length)
                val parsed = parseDnsPacket(packet) ?: continue
                val query = parsed.dns
                val host = DnsName.readName(query, 12)?.lowercase() ?: continue
                val allowed = this::database.isInitialized && database.isDomainAllowed(host)
                val blocked = !allowed && (
                    AdDomainFilter.isBlocked(host) ||
                    (this::database.isInitialized && database.isDomainBlocked(host))
                )
                val response = if (blocked) {
                    if (this::database.isInitialized) database.addBlockedEvent(host, "DNS")
                    makeNxDomain(query)
                } else {
                    forwardDns(query) ?: continue
                }
                val reply = buildIpv4UdpReply(packet, parsed.ipHeaderLength, response)
                output.write(reply)
            } catch (_: Exception) {
                if (!running.get()) break
            }
        }
    }

    private data class Parsed(val ipHeaderLength: Int, val dns: ByteArray)

    private fun parseDnsPacket(packet: ByteArray): Parsed? {
        if (packet.size < 28) return null
        val version = (packet[0].toInt() ushr 4) and 0xF
        if (version != 4) return null
        val ihl = (packet[0].toInt() and 0xF) * 4
        if (packet.size < ihl + 8) return null
        if (packet[9].toInt() != 17) return null // UDP only
        val destPort = u16(packet, ihl + 2)
        if (destPort != 53) return null
        val udpLen = u16(packet, ihl + 4)
        if (udpLen < 8 || ihl + udpLen > packet.size) return null
        return Parsed(ihl, packet.copyOfRange(ihl + 8, ihl + udpLen))
    }

    private fun forwardDns(query: ByteArray): ByteArray? {
        return try {
            DatagramSocket().use { socket ->
                protect(socket)
                socket.soTimeout = 2500
                val address = InetAddress.getByName("1.1.1.1")
                socket.send(DatagramPacket(query, query.size, address, 53))
                val data = ByteArray(4096)
                val response = DatagramPacket(data, data.size)
                socket.receive(response)
                data.copyOf(response.length)
            }
        } catch (_: Exception) { null }
    }

    private fun makeNxDomain(query: ByteArray): ByteArray {
        val out = query.copyOf()
        if (out.size >= 12) {
            val flags = u16(out, 2) or 0x8000 or 0x0080 or 0x0003
            put16(out, 2, flags)
            put16(out, 6, 0)
            put16(out, 8, 0)
            put16(out, 10, 0)
        }
        return out
    }

    private fun buildIpv4UdpReply(original: ByteArray, ihl: Int, dns: ByteArray): ByteArray {
        val udpLength = 8 + dns.size
        val totalLength = ihl + udpLength
        val out = ByteArray(totalLength)
        System.arraycopy(original, 0, out, 0, ihl)
        // Swap IPv4 source and destination.
        for (i in 0..3) {
            out[12 + i] = original[16 + i]
            out[16 + i] = original[12 + i]
        }
        put16(out, 2, totalLength)
        out[8] = 64.toByte()
        out[10] = 0; out[11] = 0
        put16(out, 10, checksum(out, 0, ihl))
        val udp = ihl
        put16(out, udp, 53)
        put16(out, udp + 2, u16(original, ihl))
        put16(out, udp + 4, udpLength)
        put16(out, udp + 6, 0)
        System.arraycopy(dns, 0, out, udp + 8, dns.size)
        return out
    }

    private fun checksum(data: ByteArray, offset: Int, length: Int): Int {
        var sum = 0L
        var i = offset
        while (i < offset + length) {
            val high = data[i].toInt() and 0xFF
            val low = if (i + 1 < offset + length) data[i + 1].toInt() and 0xFF else 0
            sum += (high shl 8) or low
            i += 2
        }
        while ((sum shr 16) != 0L) sum = (sum and 0xFFFF) + (sum shr 16)
        return sum.inv().toInt() and 0xFFFF
    }

    private fun u16(data: ByteArray, offset: Int): Int =
        ((data[offset].toInt() and 0xFF) shl 8) or (data[offset + 1].toInt() and 0xFF)

    private fun put16(data: ByteArray, offset: Int, value: Int) {
        data[offset] = (value shr 8).toByte()
        data[offset + 1] = value.toByte()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL, "Ad Blocker VPN", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun notification(): Notification =
        NotificationCompat.Builder(this, CHANNEL)
            .setContentTitle("Ad Blocker is active")
            .setContentText("Filtering known ad and tracker domains")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setOngoing(true)
            .build()

    private fun stopVpn() {
        running.set(false)
        try { tun?.close() } catch (_: Exception) {}
        tun = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopVpn()
        super.onDestroy()
    }
}

private object DnsName {
    fun readName(message: ByteArray, start: Int): String? {
        if (message.size <= start) return null
        val labels = mutableListOf<String>()
        var pos = start
        var jumps = 0
        while (pos < message.size && jumps++ < 32) {
            val length = message[pos].toInt() and 0xFF
            if (length == 0) break
            if ((length and 0xC0) == 0xC0 || length > 63 || pos + 1 + length > message.size) return null
            labels += String(message, pos + 1, length, Charsets.US_ASCII)
            pos += length + 1
        }
        return labels.joinToString(".").takeIf { it.isNotBlank() }
    }
}
