package com.adblocker.mobile

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class BlockedEvent(val domain: String, val category: String, val timestamp: Long)

class AdBlockerDatabase(context: Context) :
    SQLiteOpenHelper(context, "adblocker.db", null, 2) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE blocked_domains(domain TEXT PRIMARY KEY, source TEXT NOT NULL, updated_at INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE allowed_domains(domain TEXT PRIMARY KEY, created_at INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE blocked_events(id INTEGER PRIMARY KEY AUTOINCREMENT, domain TEXT NOT NULL, category TEXT NOT NULL, created_at INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE metadata(key TEXT PRIMARY KEY, value TEXT NOT NULL)")
        db.execSQL("CREATE INDEX idx_events_created ON blocked_events(created_at DESC)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("CREATE TABLE IF NOT EXISTS allowed_domains(domain TEXT PRIMARY KEY, created_at INTEGER NOT NULL)")
        }
    }

    @Synchronized
    fun replaceRemoteDomains(domains: Set<String>, source: String) {
        writableDatabase.beginTransaction()
        try {
            writableDatabase.delete("blocked_domains", "source = ?", arrayOf(source))
            val now = System.currentTimeMillis()
            domains.forEach { domain ->
                val values = ContentValues().apply {
                    put("domain", domain); put("source", source); put("updated_at", now)
                }
                writableDatabase.insertWithOnConflict("blocked_domains", null, values, SQLiteDatabase.CONFLICT_REPLACE)
            }
            setMetadata("last_filter_update", now.toString())
            setMetadata("filter_source", source)
            setMetadata("filter_count", domains.size.toString())
            writableDatabase.setTransactionSuccessful()
        } finally { writableDatabase.endTransaction() }
    }

    @Synchronized
    fun isDomainAllowed(host: String): Boolean {
        var candidate = normalizeHost(host)
        while (candidate.isNotEmpty()) {
            readableDatabase.rawQuery(
                "SELECT 1 FROM allowed_domains WHERE domain = ? LIMIT 1", arrayOf(candidate)
            ).use { if (it.moveToFirst()) return true }
            candidate = candidate.substringAfter('.', "")
        }
        return false
    }

    @Synchronized
    fun isDomainBlocked(host: String): Boolean {
        if (isDomainAllowed(host)) return false
        var candidate = normalizeHost(host)
        while (candidate.isNotEmpty()) {
            readableDatabase.rawQuery(
                "SELECT 1 FROM blocked_domains WHERE domain = ? LIMIT 1", arrayOf(candidate)
            ).use { if (it.moveToFirst()) return true }
            candidate = candidate.substringAfter('.', "")
        }
        return false
    }

    @Synchronized
    fun addAllowedDomain(host: String): Boolean {
        val domain = normalizeHost(host)
        if (!validDomain(domain)) return false
        val values = ContentValues().apply {
            put("domain", domain); put("created_at", System.currentTimeMillis())
        }
        writableDatabase.insertWithOnConflict("allowed_domains", null, values, SQLiteDatabase.CONFLICT_REPLACE)
        return true
    }

    @Synchronized
    fun removeAllowedDomain(host: String) {
        writableDatabase.delete("allowed_domains", "domain = ?", arrayOf(normalizeHost(host)))
    }

    fun allowedDomains(): List<String> {
        val list = mutableListOf<String>()
        readableDatabase.rawQuery("SELECT domain FROM allowed_domains ORDER BY domain", null).use {
            while (it.moveToNext()) list += it.getString(0)
        }
        return list
    }

    fun addBlockedEvent(domain: String, category: String) {
        val values = ContentValues().apply {
            put("domain", domain); put("category", category); put("created_at", System.currentTimeMillis())
        }
        writableDatabase.insert("blocked_events", null, values)
    }

    fun recentEvents(limit: Int = 100): List<BlockedEvent> {
        val result = mutableListOf<BlockedEvent>()
        readableDatabase.rawQuery(
            "SELECT domain, category, created_at FROM blocked_events ORDER BY created_at DESC LIMIT ?",
            arrayOf(limit.coerceIn(1, 500).toString())
        ).use { c ->
            while (c.moveToNext()) result += BlockedEvent(c.getString(0), c.getString(1), c.getLong(2))
        }
        return result
    }

    fun eventCount(): Int {
        readableDatabase.rawQuery("SELECT COUNT(*) FROM blocked_events", null).use {
            return if (it.moveToFirst()) it.getInt(0) else 0
        }
    }

    fun clearHistory() { writableDatabase.delete("blocked_events", null, null) }
    fun filterCount(): Int = readableDatabase.rawQuery("SELECT COUNT(*) FROM blocked_domains", null).use {
        if (it.moveToFirst()) it.getInt(0) else 0
    }
    fun lastUpdateMillis(): Long = getMetadata("last_filter_update")?.toLongOrNull() ?: 0L
    fun filterSource(): String = getMetadata("filter_source") ?: "Not configured"

    private fun setMetadata(key: String, value: String) {
        val values = ContentValues().apply { put("key", key); put("value", value) }
        writableDatabase.insertWithOnConflict("metadata", null, values, SQLiteDatabase.CONFLICT_REPLACE)
    }
    private fun getMetadata(key: String): String? {
        readableDatabase.rawQuery("SELECT value FROM metadata WHERE key = ?", arrayOf(key)).use {
            return if (it.moveToFirst()) it.getString(0) else null
        }
    }

    companion object {
        fun normalizeHost(value: String): String =
            value.trim().lowercase().removePrefix("https://").removePrefix("http://")
                .substringBefore('/').substringBefore(':').trim('.')

        fun validDomain(host: String): Boolean {
            if (host.length !in 1..253 || !host.contains('.')) return false
            return host.split('.').all { label ->
                label.length in 1..63 && label.first().isLetterOrDigit() &&
                    label.last().isLetterOrDigit() && label.all { it.isLetterOrDigit() || it == '-' }
            }
        }
    }
}
